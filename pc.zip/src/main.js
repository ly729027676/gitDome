import * as urls from '@/config/env'
import website from '@/config/website'
import WebHost from './core'
import modules from './modules'

WebHost.registerModule(modules)
WebHost.use({urls,website})

  
