﻿<template>
    <div class="l-rblock l-form-viewer" style="padding:8px;">
        <el-form
            :model="formData"
            :rules="rules"
            size="mini"
            labelPosition="left"
            labelWidth="80px"
            ref="form"
            >
            <div class="l-auto-window only-tabs">
                <el-tabs v-model="activeName" type="card">
                    <el-tab-pane class="l-tabs-container" :label="$t('新增采购申请单')" name="tab0">
                        <el-row :gutter="5">
                            <div class="l-rblock">
                                <el-col v-if="lr_formLookAuth('f_PurchaseNo')" :span="6" >
                                    <el-form-item 
                                        label="单据编码" 
                                        prop="f_PurchaseNo"
                                        > 
                                        <el-input v-model="formData.f_PurchaseNo" :placeholder="$t('请输入')"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_Theme')" :span="6" >
                                    <el-form-item 
                                        label="主题" 
                                        prop="f_Theme"
                                        :required="true"
                                        > 
                                        <el-input v-model="formData.f_Theme" :placeholder="$t('请输入')" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_PurchaseType')" :span="6" >
                                    <el-form-item 
                                        label="报价类别" 
                                        prop="f_PurchaseType"
                                        :required="true"
                                        > 
                                        <l-select :options="f_PurchaseTypeOptions" v-model="formData.f_PurchaseType" ></l-select>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_ApplyDate')" :span="6" >
                                    <el-form-item 
                                        label="报价日期" 
                                        prop="f_ApplyDate"
                                        :required="true"
                                        > 
                                        <l-date format="yyyy-MM-dd HH:mm:ss" dateType="datetime" :clearable="true" v-model="formData.f_ApplyDate" :placeholder="$t('请选择')" >
                                        </l-date>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_Appler')" :span="6" >
                                    <el-form-item 
                                        label="报价人" 
                                        prop="f_Appler"
                                        :required="true"
                                        > 
                                        <l-user-select 
                                            v-model="formData.f_Appler" 
                                        ></l-user-select>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_Department')" :span="6" >
                                    <el-form-item 
                                        label="报价单位" 
                                        prop="f_Department"
                                        :required="true"
                                        > 
                                        <l-company-select v-model="formData.f_Department" ></l-company-select>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_PaymentType')" :span="6" >
                                    <el-form-item 
                                        label="支付方式" 
                                        prop="f_PaymentType"
                                        :required="true"
                                        > 
                                        <l-select :options="f_PaymentTypeOptions" v-model="formData.f_PaymentType" ></l-select>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_Total')" :span="6" >
                                    <el-form-item 
                                        label="总价" 
                                        prop="f_Total"
                                        :required="true"
                                        > 
                                        <el-input v-model="formData.f_Total" :placeholder="$t('请输入')" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_Your')" :span="6" >
                                    <el-form-item 
                                        label="对方代表" 
                                        prop="f_Your"
                                        :required="true"
                                        > 
                                        <el-input v-model="formData.f_Your" :placeholder="$t('请输入')" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_DeliveryDate')" :span="8" >
                                    <el-form-item 
                                        label="出库日期" 
                                        prop="f_DeliveryDate"
                                        :required="true"
                                        > 
                                        <l-date format="yyyy-MM-dd HH:mm:ss" dateType="datetime" :clearable="true" v-model="formData.f_DeliveryDate" :placeholder="$t('请选择')" >
                                        </l-date>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_File')" :span="24" >
                                    <el-form-item 
                                        label="附件上传" 
                                        prop="f_File"
                                        > 
                                        <l-upload 
                                            v-model="formData.f_File" 
                                            :chunkedUpload="lr_chunkedUpload"
                                            :getFileList="lr_getFileList"
                                            :deleteFile="lr_deleteFile"
                                        ></l-upload>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_Description')" :span="24" >
                                    <el-form-item 
                                        label="备注" 
                                        prop="f_Description"
                                        > 
                                        <el-input type="textarea" :rows="3" v-model="formData.f_Description" :placeholder="$t('请输入')" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="24" >
                                    <div class="l-title" >{{$t('商品信息')}}</div>
                                    <l-edit-table
                                        ref="lr_erp_salesorderdetail_table"
                                        addBtnText="新增"
                                        :isAddBtn="true"
                                        :isRemoveBtn="true"
                                        :isShowNum="true"
                                        :dataSource="lr_erp_salesorderdetail_data"
                                        :columns="lr_erp_salesorderdetail_columns"
                                        @addRow="handleLr_erp_salesorderdetailAddRow"
                                        @deleteRow="handleLr_erp_salesorderdetailDeleteRow"
                                        >
                                        <template v-slot:f_Code="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Code" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Name="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Name" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_BarCode="scope" >
                                            <el-input size="mini" v-model="scope.row.f_BarCode" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Place="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Place" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Specification="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Specification" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Type="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Type" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Number="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Number" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Unit="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Unit" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Count="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Count" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Price="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Price" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                        <template v-slot:f_Amount="scope" >
                                            <el-input size="mini" v-model="scope.row.f_Amount" :placeholder="$t('请输入')" >
                                            </el-input>
                                        </template>
                                    </l-edit-table>
                                </el-col>

                            </div>
                        </el-row>
                    </el-tab-pane>

                </el-tabs>
            </div>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            activeName: 'tab0',
            formData: {
                f_PurchaseNo:"", // 单据编码
                f_Theme:"", // 主题
                f_PurchaseType:"", // 报价类别
                f_ApplyDate:"", // 报价日期
                f_Appler:"", // 报价人
                f_Department:"", // 报价单位
                f_PaymentType:"", // 支付方式
                f_Total:"", // 总价
                f_Your:"", // 对方代表
                f_DeliveryDate:"", // 出库日期
                f_File:"", // 附件上传
                f_Description:"", // 备注
                f_ModifyDate:"", // 修改时间

            },
            rules: {
                 f_PurchaseNo: [
                    { required: true, message: '请输入单据编码' }
                ],
                f_Theme: [
                    { required: true, message: '请输入主题'}
                ],
                f_PurchaseType: [
                    { required: true, message: '请选择报价类别'}
                ],
                f_ApplyDate: [
                    { required: true, message: '请选择报价日期' }
                ],
                f_Appler: [
                    { required: true, message: '请选择报价人' }
                ],
                f_Department: [
                    { required: true, message: '请选择报价单位' }
                ],
                f_PaymentType: [
                    { required: true, message: '请选择支付方式' }
                ],
                f_Total: [
                    { required: true, message: '请输入总价' },
                    { pattern:/^\d+(\.\d+)?$/, message: '请输入数字' }
                ],
                f_Your: [
                    { required: true, message: '请输入对方代表' }
                ],
                f_DeliveryDate: [
                    { required: true, message: '请选择出库日期' }
                ]
            },
            lr_erp_salesorderdetail_columns:[
                {id:'lr_erp_salesorderdetail_F_Code',prop:'f_Code',label:'商品编号',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Name',prop:'f_Name',label:'商品名称',width:undefined},
                {id:'lr_erp_salesorderdetail_F_BarCode',prop:'f_BarCode',label:'条码',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Place',prop:'f_Place',label:'产地',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Specification',prop:'f_Specification',label:'规格',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Type',prop:'f_Type',label:'型号',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Number',prop:'f_Number',label:'批次号',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Unit',prop:'f_Unit',label:'单位',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Count',prop:'f_Count',label:'数量',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Price',prop:'f_Price',label:'单价',width:undefined},
                {id:'lr_erp_salesorderdetail_F_Amount',prop:'f_Amount',label:'金额',width:undefined},
            ],
            lr_erp_salesorderdetail_data:[]            
        };
    },
    computed: {
        f_PurchaseTypeOptions(){
            return [{"value":"2","label":"新闻类"},{"value":"3","label":"产品类"},{"label":"信息类","value":'4'}]
        },
        f_PaymentTypeOptions(){
            return [{"value":"0","label":"现金"},{"value":"1","label":"票汇"},{"label":"信汇","value":"2"},{"label":"电汇","value":"3"},{"label":"承兑","value":"4"},{"label":"信用证","value":"5"}]
        }
    },
    mounted() {
    },
    methods: {
        handleLr_erp_salesorderdetailAddRow(){
            let point = {}
            point.f_Code = ""
            point.f_Name = ""
            point.f_BarCode = ""
            point.f_Place = ""
            point.f_Specification = ""
            point.f_Type = ""
            point.f_Number = ""
            point.f_Unit = ""
            point.f_Count = ""
            point.f_Price = ""
            point.f_Amount = ""
            this.lr_erp_salesorderdetail_data.push(point)
        },
        handleLr_erp_salesorderdetailDeleteRow(event){
            this.lr_erp_salesorderdetail_data.splice(event.index,1)
        },

        // 重置表单
        resetForm() {
            this.formData.f_Id = ''
            this.$formClear(this.$refs.form)
            this.lr_erp_salesorderdetail_data = []

        },
        // 校验表单
        validateForm() {
            return new Promise((resolve) => {
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        if(!this.$refs.lr_erp_salesorderdetail_table.validate())
                        {
                            resolve(false)
                            return
                        }

                        resolve(true)
                    }
                    else {
                        resolve(false)
                    }
                })
            })
            
        },
        // 设置表单数据
        setForm(data) {
            this.formData = data.erp_sales_orderEntity
            this.lr_erp_salesorderdetail_data = data.erp_sales_order_detailList

        },
        // 获取表单数据
        getForm() {
            let formData = {}
            formData.erp_sales_orderEntity = this.$deepClone(this.formData)
            formData.erp_sales_order_detailList = this.$deepClone(this.lr_erp_salesorderdetail_data)
            return formData
        }
    }
}
</script>