﻿﻿import module from '../module'
window.$api = window.$api || {}
window.$api[module.code] = {}
const requireComponent = require.context('./', true, /\.*\.js$/)
requireComponent.keys().map(fileName => {
    const name = fileName.replace('./', '').replace('.js', '')
    if (name != 'index') {
        const func = requireComponent(fileName).default
        window.$api[module.code][name] = func(`${module.code.toLowerCase()}/${name.toLowerCase()}`)
    }
})