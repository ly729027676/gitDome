const modules = []
const requireComponent = require.context('./', true, /index.js$/)
requireComponent.keys().map(fileName => {
  const name = fileName.replace('./', '').replace('.js', '')
  const nameList = name.split('/')
  if(nameList.length == 2){
    const func = requireComponent(fileName).default
    modules.push(func)
  }
})

export default modules