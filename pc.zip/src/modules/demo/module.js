export default {
    name: '案例演示模块',
    code: 'demo',
    version: '1.0.0',
    description: '一些案例演示'
  }