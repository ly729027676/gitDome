
import Layout from '@/core/page/index'
import module from '../module'
const pageViews = [  
  {name:'移动图标',path:`/${module.code}/appIcon`},
  {name:'图标查看',path:`/${module.code}/pcIcon`},
  {name:'查询表格',path:`/${module.code}/querylist`},
  {name:'采购管理',path:`/${module.code}/procurement`},
  {name:'主子表',path:`/${module.code}/moreTable`}
]

export default pageViews.map(t=>{
const componentName = t.path.replace(`/${module.code}`,'')
return {
  path:t.path,
  component:Layout,
  redirect:`${t.path}/index`,
  children:[{
    path: 'index',
    name:t.name,
    meta:t.meta,
    component:() => import(/* webpackChunkName: "[request]" */ `../views${componentName}/index`)
  }]
}})



