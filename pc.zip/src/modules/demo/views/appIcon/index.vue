<template>
<l-layout >
    <l-panel>
        <div style="padding:16px;" >
            <ul class="iconlist" >
                <li v-for="(item,index) in lr_appIcons" :key="index" ><span><i :class="item"></i><span class="icon-name">{{item}}</span></span></li>
            </ul>
        </div>
    </l-panel>
</l-layout>
</template>

<script>
export default {
  name:'appicon-index',
  props: {
  },
  data () {
    return {
    }
  },
  mounted () {
  },
  methods:{
  }

}
</script>



<style lang="scss" scoped>
.iconlist {
    overflow: hidden;
    list-style: none;
    padding: 0!important;
    border: 1px solid #eaeefb;
    border-radius: 4px;
    font-size: 14px;
    color: #5e6d82;
    line-height: 2em;
    margin: 0;

    span {
        line-height: normal;
        font-family: Helvetica Neue,Helvetica,PingFang SC,Hiragino Sans GB,Microsoft YaHei,SimSun,sans-serif;
        color: #99a9bf;
        transition: color .15s linear;

        display: inline-block;
        vertical-align: middle;
    }
    i {
        display: block;
        font-size: 32px;
        margin-bottom: 15px;
        color: #606266;
        transition: color .15s linear;
    }
    .icon-name {
        display: inline-block;
        padding: 0 3px;
        height: 1em;
    }
}
.iconlist li {
    float: left;
    width: 16.66%;
    text-align: center;
    height: 120px;
    line-height: 120px;
    color: #666;
    font-size: 13px;
    border-right: 1px solid #eee;
    border-bottom: 1px solid #eee;
    margin-right: -1px;
    margin-bottom: -1px;
}

.iconlist li:hover i, .iconlist li:hover span {
    color: #5cb6ff;
}
</style>