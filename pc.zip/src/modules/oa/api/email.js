export default url => {
    const crud = window.$crud(url)
    crud.remove = (id,type)=> window.$axios({
        url: `${url}/${id}/${type}`,
        method: 'delete'
    })
    crud.cremove = (id,type)=> window.$axios({
        url: `${url}/remove/${id}/${type}`,
        method: 'delete'
    })

    
    return {
        ...crud
    }
}