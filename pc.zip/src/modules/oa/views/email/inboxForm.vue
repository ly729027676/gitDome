<template>
    <div class="l-rblock l-form-viewer" style="padding:16px;">
        <el-form
            :model="formData"
            size="mini"
            labelPosition="right"
            labelWidth="80px"
            ref="form"
            >
            <div class="l-auto-window only-tabs">
                <el-tabs v-model="activeName" type="card">
                    <el-tab-pane class="l-tabs-container" :label="$t('主表信息')" name="tab0">
                        <el-row :gutter="0">
                            <div class="l-rblock">

                                <el-col :span="24" >
                                    <el-form-item 
                                        label="发送人" 
                                        prop="f_SenderName"
                                        > 
                                        <el-input
                                        v-model="formData.f_SenderName"
                                        disabled
                                        ></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="24" >
                                    <el-form-item 
                                        label="收件人" 
                                        prop="f_AddresssHtml"
                                        > 
                                        <l-user-select 
                                            v-model="formData.f_AddresssHtml"
                                            multiple
                                            disabled
                                         ></l-user-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="24" >
                                    <el-form-item 
                                        label="主题" 
                                        prop="f_Theme"
                                        > 
                                        <el-input disabled  v-model="formData.f_Theme" :placeholder="$t('请输入')" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="6" >
                                    <el-form-item 
                                        label="附件" 
                                        prop="f_Files"
                                        > 
                                        <l-upload disabled v-model="formData.f_Files" ></l-upload>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="24" >
                                    <el-form-item 
                                        label="邮件内容" 
                                        prop="f_EmailContent"
                                        > 
                                        <l-editor disabled v-model="formData.f_EmailContent" :options="{ theme:'snow',placeholder: $t('请输入内容...')}"  style="height:200px;"></l-editor>
                                    </el-form-item>
                                </el-col>
                            </div>
                        </el-row>
                    </el-tab-pane>

                </el-tabs>
            </div>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            activeName: 'tab0',
            formData: {
                f_AddresssHtml:"", // 收件人
                f_SenderName:"", // 抄送人
                f_Theme:"", // 主题
                f_Files:"", // 附件
                f_EmailContent:"", // 邮件内容
            }
        };
    },
    computed: {
    
    },
    mounted() {
        this.init()
    },
    methods: {
        init() {
        },
        // 重置表单
        resetForm() {
            this.$refs.form.resetFields()        
        },
        // 设置表单数据
        setForm(data) {
            this.formData = data 
        }
    }
}
</script>