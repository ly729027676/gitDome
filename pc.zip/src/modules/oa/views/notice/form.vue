﻿<template>
    <div class="l-rblock l-form-viewer" style="padding:8px;">
        <el-form
            :model="formData"
            :rules="rules"
            size="mini"
            labelPosition="right"
            labelWidth="80px"
            ref="form"
            >
            <div class="l-auto-window only-tabs">
                <el-tabs v-model="activeName" type="card">
                    <el-tab-pane class="l-tabs-container" :label="$t('主表信息')" name="tab0">
                        <el-row :gutter="0">
                            <div class="l-rblock">
                                <el-col v-if="lr_formLookAuth('f_FullHead')" :span="24" >
                                    <el-form-item 
                                        label="公告标题" 
                                        prop="f_FullHead"
                                        :required="true"
                                        > 
                                        <el-input v-model="formData.f_FullHead" :placeholder="$t('请输入')" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_CategoryId')" :span="12" >
                                    <el-form-item 
                                        label="公告类别" 
                                        prop="f_CategoryId"
                                        :required="true"
                                        > 
                                        <l-select :options="f_CategoryOptions" v-model="formData.f_CategoryId" ></l-select>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_ReleaseTime')" :span="12" >
                                    <el-form-item 
                                        label="发布时间" 
                                        prop="f_ReleaseTime"
                                        :required="true"
                                        > 
                                        <l-date format="yyyy-MM-dd HH:mm:ss" dateType="datetime" :clearable="true" v-model="formData.f_ReleaseTime" :placeholder="$t('请选择')" >
                                        </l-date>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_SourceName')" :span="12" >
                                    <el-form-item 
                                        label="信息来源" 
                                        prop="f_SourceName"
                                        > 
                                        <el-input v-model="formData.f_SourceName" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_SourceAddress')" :span="12" >
                                    <el-form-item 
                                        label="来源地址" 
                                        prop="f_SourceAddress"
                                        > 
                                        <el-input v-model="formData.f_SourceAddress" >
                                        </el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col v-if="lr_formLookAuth('f_NewsContent')" :span="24" >
                                    <el-form-item 
                                        label="内容" 
                                        prop="f_NewsContent"
                                        > 
                                        <l-editor style="height:250px;" v-model="formData.f_NewsContent" :options="{ theme:'snow',placeholder: $t('请输入内容...')}" :rows="15" ></l-editor>
                                    </el-form-item>
                                </el-col>
                            </div>
                        </el-row>
                    </el-tab-pane>
                </el-tabs>
            </div>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            activeName: 'tab0',
            formData: {
                f_CategoryId:"", // 公告栏目
                f_FullHead:"", // 公告标题
                f_ReleaseTime:"", // 发布时间
                f_SourceName:"", // 
                f_SourceAddress:"", // 
                f_NewsContent:"", // 内容
            },
            rules: {
                 f_FullHead: [{ required: true, message: '请输入新闻名称' },],
                 f_CategoryId: [{ required: true, message: '请输入新闻栏目' },],
                 f_ReleaseTime: [{ required: true, message: '请输入发布时间'},],
                 f_AuthorName: [{ required: true, message: '请输入作者'},],
                 f_CompileName: [{ required: true, message: '请输入编辑人员' },],
            },
        };
    },
    computed: {
        f_CategoryOptions(){
            return [
                {"value":"1","label":"会议通知1"},
                {"value":"2","label":"活动公告"},
                {"value":"3","label":"社会公告"},
                {"label":"内部公告","value":'4'},
                {"label":"其他公告","value":'5'}]
        },
    },
    mounted() {
    },
    methods: {        
        // 重置表单
        resetForm() {
            this.$refs.form.resetFields()
        },
        // 校验表单
        validateForm() {
            return new Promise((resolve) => {
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        
                        resolve(true)
                    }
                    else {
                        resolve(false)
                    }
                })
            })
            
        },
        // 设置表单数据
        setForm(data) {
            this.formData = data 
        },
        // 获取表单数据
        getForm() {
            return this.$deepClone(this.formData)
        }
    }
}
</script>