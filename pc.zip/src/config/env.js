// 配置编译环境和线上环境之间的切换
const rootUrl = process.env.VUE_APP_ROOT_URL
const apiUrl = process.env.VUE_APP_BASE_API
const imUrl = process.env.VUE_APP_BASE_IM

const env = process.env

 export {
  apiUrl,
  rootUrl,
  imUrl,
  env
}