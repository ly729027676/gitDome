

import config from '../../package.json'
/**
 * 全局配置文件
 */
export default {
  title: "中孚恒升科技",
  version:config.version,
  subVersion:config.subVersion,
  company:'Copyright 2020  深圳市中孚恒升科技有限公司',
  url:'https://aitrais.com',

  key: 'learun_core',
  //配置首页不可关闭
  isDynamicHome:true,// 
  fistPage: {
    label: "首页",
    value: "/system/home/index"
  },

  language:{
    mainType:'chinese',
    type:'chinese',
  },
  theme:{
    nav:'side' // side 侧边导航栏 mix 混合导航栏
  },
  imOpen:true, // 默认关闭 false
  online: process.env.VUE_APP_ONLINE == 'true'? true : false // 生产环境为线上体验版本
}