<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "app",
  computed:{
  },
  methods: {
  },

};
</script>
<style lang="scss">
#app {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.l-load-page{
  position: fixed;
  top: 0;
  left: 0;
  z-index:999999;
  background: #f0f0f0;
}
</style>