<template>
<div class="l-from-body" >
    <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="60px" >
        <el-col :span="24">
            <el-form-item label="名称" prop="f_Name">
                <el-input v-model="formData.f_Name"></el-input>
            </el-form-item>
        </el-col>
        <el-col :span="24">
            <el-form-item label="编码" prop="f_Code">
                <el-input v-model="formData.f_Code" :readonly="isEdit" ></el-input>
            </el-form-item>
        </el-col>
    </el-form>
</div>
</template>
<script>
export default {
    props:{
        isEdit:Boolean
    },
    data(){
        return {
            formData:{
                f_Name:'',
                f_Code:'',
            },
            rules: {
                f_Code: [
                    { required: true, message: '请输入编码'},
                    { validator: this.lr_existDbFiled,isEditIgnore:true,tableName:'lr_lg_type',keyName:'f_Id',trigger: 'null'}
                ],
                f_Name: [
                    { required: true, message: '请输入名称'}
                ]
            }
        }
    },
    created () {
    },
    methods:{
        // 重置表单
        resetForm(){
            this.formData.f_Id = ''
            this.$refs.form && this.$refs.form.resetFields()
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                callback(valid)
            })
        },
        // 设置表单数据
        setForm(data){
            this.formData = data
        },
        // 获取表单数据
        getForm(){
            return this.$deepClone(this.formData)
        }
    }
}
</script>