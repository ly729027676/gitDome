<template>
    <l-layout class="l-tab-page" v-show="!lr_loadPage" >
        <l-panel>
            <template #toolLeft >
                <div class="l-panel--item" >
                    <el-input placeholder="请输入名称/编码" @keyup.enter.native="hanleSearch" v-model="searchWord" size="mini" >
                        <el-button @click="hanleSearch" slot="append" icon="el-icon-search"></el-button>
                    </el-input>
                </div>
            </template>
            <template #toolRight >
                <l-tool-btns @click="handleAdd()" >
                    <l-excel-btns></l-excel-btns>
                </l-tool-btns>
            </template>
            <l-table 
                :loading="tableLoading"
                :columns="columns" 
                :dataSource="tableData" 
                row-key="f_Id"
                >
                <l-table-btns :filterBtns="filterBtns" :btns="tableBtns" @click="lr_handleTableBtnClick" ></l-table-btns>
            </l-table>
        </l-panel>
        <l-dialog   
            :width="400"
            :height="176"
            :title="formTitle"
            :visible.sync="formVisible"
            @ok="handleSave"
            @close="handleCloseForm"
            @opened="handleOpenedForm"
            >
            <my-form 
                ref="form"
                :isEdit="formEdit"
                ></my-form>
        </l-dialog>
    </l-layout>
</template>

<script>
import MyForm from './form'
export default {
    components: {
        MyForm
    },
    data () {
        return {
            lr_isPage:true,
            searchWord:'',
            columns: [
                {label:'名称',prop:'f_Name',width:'200'},
                {label:'编码',prop:'f_Code',minWidth:'200'}
            ],
            tableBtns:[
                {prop:'Edit',label:'编辑'},
                {prop:'Delete',label:'删除'}
            ],
            tableLoading:false,
            searchTableData:null,

            formTitle:'',
            formVisible:false,
            formEdit:false,
            formEditRow:null,
        }
    },
    computed:{
        list(){
            return this.$store.state.language.type.list
        },
        tableData(){
            return this.searchTableData || this.list
        }
    },
    mounted () {
        this.$nextTick(()=>{
            this.tableInitData()
        })
    },
    methods:{
        // 表格操作
        tableInitData(){
            this.tableLoading = true
            this.$store.dispatch("language/type/getList").then(()=> {
                this.tableLoading = false
            }).catch(() => {
                this.tableLoading = false
            })
        },
        hanleSearch(){
            if(this.searchWord){
                this.searchTableData = this.list.filter(item => item.f_Name.indexOf(this.searchWord) >-1 || item.f_Code.indexOf(this.searchWord)>-1)
            }
            else{
                this.searchTableData = null
            }
        },
        // 按钮方法
        handleAdd(){
            this.formEdit = false
            this.showForm('新增语言类型')
        },
        handleEdit($index,row){
            this.formEdit = true
            this.formEditRow = row
            this.showForm('编辑语言类型')
        },
        handleDelete($index,row){
            this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$store.dispatch("language/type/remove",row.f_Id).then(()=> {
                    this.$message({
                        type: 'success',
                        message: '删除成功!'
                    })
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })        
            })
        },

        handleSave(showLoading,hideLoading){
            this.$refs.form.validateForm((valid)=>{
                if(valid){
                    const formData = this.$refs.form.getForm()
                    showLoading()
                    if(this.formEdit){// 修改数据
                        this.$store.dispatch("language/type/update",{id:formData.f_Id,formData}).then(()=> {
                            hideLoading()
                            this.formVisible = false
                        }).catch(() => {
                            hideLoading()
                        })
                    }
                    else{// 新增数据
                        this.$store.dispatch("language/type/add",formData).then(()=> {
                            hideLoading()
                            this.formVisible = false
                        }).catch(() => {
                            hideLoading()
                        })
                    }
                }
            })
        },

        handleOpenedForm(){
            if(this.formEdit){
                this.$refs.form.setForm(this.$deepClone(this.formEditRow))
            }
        },
        handleCloseForm(){
            this.$refs.form.resetForm()
        },
        showForm(text){
            this.formTitle = text
            this.formVisible = true
        },
        filterBtns(row,btns){
            if(row.f_Code != this.appConfig.language.mainType){
                return btns
            }
            else{
                return btns.filter(t=>t.prop != 'Delete')
            }
        }
    }
}
</script>