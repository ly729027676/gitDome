<template>
<div class="l-from-body" >
    <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="100px" >
        <el-col :span="24" v-for="(item,index) in typeList" :key="index" >
            <el-form-item :label="item.f_Name" :prop="item.f_Code">
                <el-input v-model="formData[item.f_Code]"></el-input>
            </el-form-item>

        </el-col>
    </el-form>
</div>
</template>
<script>
export default {
    data(){
        return {
            formData:{
            },
            rules: {
            }
        }
    },
    computed:{
        typeList(){
            return this.$store.state.language.type.list
        },
        mainType(){
            return this.typeList.find(t=>t.f_IsMain == 1) || {}
        }
    },
    created () {
    },
    methods:{
        // 重置表单
        resetForm(){
            this.formData.f_code = ''
            this.$refs.form && this.$refs.form.resetFields()
        },
        // 校验表单
        validateForm(){
            if(this.$validatenull(this.formData[this.mainType.f_Code])){
                this.$message({
                    type: 'error',
                    message: `请输入${this.mainType.f_Name}`
                })     
                return false
            }
            return true
        },
        // 设置表单数据
        setForm(data){
            this.formData = data
        },
        // 获取表单数据
        getForm(){
            const formData = []
            this.typeList.forEach(item => {
                if(!this.$validatenull(this.formData[item.f_Code])){
                    formData.push({f_Name:this.formData[item.f_Code],f_TypeCode:item.f_Code})
                }
            })
            return formData
        }
    }
}
</script>