export default {
  name: '多语言模块',
  code: 'language',
  version: '1.0.0',
  description: '实现多国语言的切换，统一管理语言翻译'
}
  