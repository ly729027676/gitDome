export default url => {
    const crud = window.$crud(url)
    crud.getList = () => window.$axios({
        url: `language/types`,
        method: 'get',
        meta:{
            isToken:false
        }
    })
    return {
        ...crud
    }
}