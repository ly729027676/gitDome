export default url => {
    const crud = window.$crud(url)
    crud.getList = (mainCode,code) => window.$axios({
        url: `${url}/${mainCode}/${code}`,
        method: 'get',
        meta:{
            isToken:false
        }
    })

    const getModuleList = (moduleId,isParent) => window.$axios({
        url: `${url}/modules/${moduleId}/${isParent}`,
        method: 'get'
    })

    const getDataItemList = (code) => window.$axios({
        url: `${url}/dataitems/${code}`,
        method: 'get'
    })
    return {
        ...crud,
        getModuleList,
        getDataItemList
    }
}