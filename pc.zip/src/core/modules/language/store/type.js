
import module from '../module'
const api = window.$api[module.code].type
export default {
    namespaced: true,
    state:{
        list:[]
    },
    actions:{
        getList({commit}){
            return new Promise((resolve,reject) => {
                api.getList().then(res => {
                    const list = res.data.data
                    commit('SET_TYPES', list)
                    resolve(list)
                }).catch(err => {
                    reject(err)
                })
            })
        },
        add({commit},formData){
            return new Promise((resolve,reject) => {
                api.add(formData).then(res => {
                    const data = res.data.data
                    formData.f_Id = data
                    commit('ADD_TYPE', formData)
                    resolve(formData)
                }).catch(err => {
                    reject(err)
                })
            })
        },
        update({commit},{id,formData}){
            return new Promise((resolve,reject) => {
                api.update(id,formData).then(() => {
                    commit('UPDATE_TYPE', formData)
                    resolve()
                }).catch(err => {
                    reject(err)
                })
            })
        },
        remove({commit},id){
            return new Promise((resolve,reject) => {
                api.remove(id).then(() => {
                    commit('REMOVE_TYPE', id)
                    resolve()
                }).catch(err => {
                    reject(err)
                })
            })
        }
    },
    mutations:{
        SET_TYPES: (state, payload) => {
            state.list = payload
        },
        ADD_TYPE:(state, payload) =>{
            state.list.push(payload)
        },
        UPDATE_TYPE:(state,payload) =>{
            window.$extend(state.list.find(t => t.f_Id ==payload.f_Id ),payload)
        },
        REMOVE_TYPE:(state,payload) =>{
            state.list.splice(state.list.findIndex(t => t.f_Id ==payload ),1)
        }
    }
}