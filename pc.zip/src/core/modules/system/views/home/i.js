export default {
    close:false,
    isNotMenu:true
}