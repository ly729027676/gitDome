const api = window.$api.system.module

const modules = {
    namespaced: true,
    state:{
        list:[],
        group:{},
        map:{},
        menu:[]
    },
    actions:{
        getList({ commit }){
            return new Promise(resolve => {
                api.getList().then(res => {
                    const data = res.data.data
                    let modules = window.$deepClone(data)
                    let modulesGroup = {}
                    let modulesMap = {}

                    modules.forEach(ele => {
                        modulesGroup[ele.f_ParentId] = modulesGroup[ele.f_ParentId] || []
                        modulesGroup[ele.f_ParentId].push(ele)
                        modulesMap[ele.f_ModuleId] = ele
                    })

                    commit('SET_MODULES', modules)
                    commit('SET_MODULESGROUP', modulesGroup)
                    commit('SET_MODULESMAP', modulesMap)
                    resolve(modules)
                })
            })
        },
        add({dispatch},formData){
            return new Promise((resolve,reject) => {
                api.add(formData).then( () => {
                    dispatch('getList').then(()=>{
                        resolve()
                    })
                }).catch(err => {
                    reject(err)
                })
            })
        },
        update({dispatch},{id,formData}){
            return new Promise((resolve,reject) => {
                api.update(id,formData).then(() => {
                    dispatch('getList').then(()=>{
                        resolve()
                    })
                }).catch(err => {
                    reject(err)
                })
            })
        },
        updateState({dispatch},data){
            return new Promise((resolve,reject) => {
                api.updateState(data.id,data.state).then(() => {
                    dispatch('getList').then(()=>{
                        resolve()
                    })
                }).catch(err => {
                    reject(err)
                })
            })
        },
        remove({dispatch},id){
            return new Promise((resolve,reject) => {
                api.remove(id).then(() => {
                    dispatch('getList').then(()=>{
                        resolve()
                    })
                }).catch(err => {
                    reject(err)
                })
            })
        },
        get({commit},id){
            return new Promise((resolve,reject) => {
                api.get(id).then(res => {
                    const data = res.data.data;
                    let module = window.$deepClone(data);
                    commit('UPDATE_MODULE', module.baseInfo);
                    resolve(module);
                }).catch(err => {
                    reject(err);
                })
            })
        }
    },
    mutations:{
        SET_MODULES: (state, modules) => {
            state.list = modules;
        },
        SET_MODULESGROUP: (state, modulesGroup) => {
            state.group = modulesGroup;
        },
        SET_MODULESMAP: (state, modulesMap) => {
            state.map = modulesMap;
        },
        UPDATE_MODULE: (state, module) => {
            window.$extend(state.map[module.f_ModuleId],module)
        },
        setMenu: (state, menu) => {
            state.menu = menu
        }
    }
}

export default modules;