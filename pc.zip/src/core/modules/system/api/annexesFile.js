export default url => {
    const merge = (formData) => window.$axios({
        url: `${url}/merge`,
        method: 'post',
        data:formData
    })
    
    const remove = (fileId) => window.$axios({
        url: `${url}/${fileId}`,
        method: 'delete'
    })
    
    const getList = (folderId) => window.$axios({
        url: `${url}/${folderId}/list`,
        method: 'get'
    })
    
    return {
        merge,
        remove,
        getList
    }
}