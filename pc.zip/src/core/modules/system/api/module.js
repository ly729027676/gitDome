export default url => {
    const crud = window.$crud(url)

    const updateState = (id,state) => window.$axios({
        url: `${url}/state/${id}/${state}`,
        method: 'put'
    })

    const getButtons = (id) => window.$axios({
        url: `${url}/${id}/buttons`,
        method: 'get'
    })

    const getColumns = (id) => window.$axios({
        url: `${url}/${id}/columns`,
        method: 'get'
    })

    const getForms = (id) => window.$axios({
        url: `${url}/${id}/forms`,
        method: 'get'
    })
    return {
        ...crud,
        updateState,
        getButtons,
        getColumns,
        getForms
    }
}