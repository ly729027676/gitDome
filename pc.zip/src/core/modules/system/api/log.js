

export default url => {
    const getPage = (req) => window.$axios({
        url: `${url}/page`,
        method: 'get',
        params:req
    })
    
    const remove = (categoryId,keepTime) => window.$axios({
        url: `${url}/${categoryId}/${keepTime}`,
        method: 'delete',
    })

    const visit = (data) => window.$axios({
        url: `${url}`,
        method: 'post',
        data
    })
    
    return {
        getPage,
        remove,
        visit
    }
}