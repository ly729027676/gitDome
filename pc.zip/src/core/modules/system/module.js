export default {
    name: '系统管理模块',
    code: 'system',
    version: '1.0.0',
    description: '菜单,配置信息管理'
}