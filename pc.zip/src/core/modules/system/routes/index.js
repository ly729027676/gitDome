
import Layout from '@/core/page/index'
import module from '../module'
const pageViews = []
const requireComponent = require.context('../views', true, /i\.js$/)
requireComponent.keys().map(fileName => {
  const nameList = fileName.split('/')
  if(nameList.length == 3 && nameList[2] == 'i.js'){
    const name = nameList[1]
    pageViews.push({name:'',path:`/${module.code}/${name}`,meta:requireComponent(fileName).default})
  }
})
export default pageViews.map(t=>{
  const componentName = t.path.replace(`/${module.code}`,'')
  return {
    path:t.path,
    component:Layout,
    redirect:`${t.path}/index`,
    children:[{
      path: 'index',
      name:t.name,
      meta:t.meta,
      component:() => import(/* webpackChunkName: "[request]" */ `../views${componentName}/index`)
    }]
}})