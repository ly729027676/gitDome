


export default url => {
    const getList = (id,type,parentId) => window.$axios({
        url: `${url}/${type}/${parentId}/${id}`,
        method: 'get'
    })
    
    
    const save = (id,data) => window.$axios({
        url: `${url}/${id}`,
        method: 'post',
        data:data
    })
    
    const get = (id) => window.$axios({
        url: `${url}/${id}`,
        method: 'get'
    })
    
    
    return {
        getList,
        save,
        get
    }
}