export default {
    name: '权限管理',
    code: 'permission',
    version: '1.0.0',
    description: '权限管理'
}