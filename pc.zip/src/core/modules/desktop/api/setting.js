export default url => {
    const crud = window.$crud(url)
    const getHistoryPage = (id,qureyData) => window.$axios({
        url: `${url}/history/page/${id}`,
        method: 'get',
        params:qureyData
    })
    
    const updateHistory = (id,schemeId) => window.$axios({
        url: `${url}/history/${id}`,
        method: 'put',
        params:{schemeId:schemeId}
    })


    const getHistory = (id) => window.$axios({
        url: `${url}/history/${id}`,
        method: 'get'
    })

    const getByCode = (code) => window.$axios({
        url: `${url}/bycode/${code}`,
        method: 'get'
    })

    const getByModuleId = (moduleId) => window.$axios({
        url: `${url}/module/${moduleId}`,
        method: 'get'
    })


    const updateState = (id,enabledMark) => window.$axios({
        url: `${url}/state/${id}`,
        method: 'put',
        params:{enabledMark:enabledMark}
    })

    const updateStateByModuleId = (id,enabledMark) => window.$axios({
        url: `${url}/state/module/${id}`,
        method: 'put',
        params:{enabledMark:enabledMark}
    })

    const removeByModuleId =  (id) => window.$axios({
        url: `${url}/module/${id}`,
        method: 'delete'
    })

    return {
        ...crud,
        getHistoryPage,
        updateHistory,
        getHistory,
        getByCode,

        updateState,
        updateStateByModuleId,
        removeByModuleId,
        getByModuleId

    }
}