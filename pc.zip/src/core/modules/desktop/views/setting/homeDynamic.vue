<template>
    <div class="l-rblock l-quick-bi-viewer" >
        <l-quick-bi-viewer v-show="settingData.length >0"  ref="quickViewer" ></l-quick-bi-viewer>
        <el-empty v-show="settingData.length == 0" description="请配置动态首页"></el-empty>
    </div>
</template>

<script>
const api = window.$api.desktop.setting
import './components/view'

export default {
    data () {
        return {
            name:'',
            moduleId:'',
            // 配置信息
            isInit:false,
            settingData:[],
        };
    },
    computed:{
    },
    watch: {
        $route:{
            handler(){
                this.init()
            },
            immediate: true
        }
    },
    methods:{
        // 页面初始化
        async init(){
            this.$refs.quickViewer && this.$refs.quickViewer.reset()
            const code = this.$route.query.src
            if(code != 'learun_desktop_nosetting'){
                const {lr_desktop_schemeEntity} = await this.$awaitWraper(api.getByCode(this.$route.query.src))
                this.settingData = JSON.parse(lr_desktop_schemeEntity.f_Content)
                this.$nextTick(()=>{
                    this.$refs.quickViewer.set(this.settingData)
                })
            }
            else{
                this.settingData.length = 0
            }
        }
    }
}
</script>
<style lang="scss">
.l-quick-bi-viewer .el-empty{
    position: absolute;
    margin-top: -145px;
    top: 50%;
    left: 0;
    width: 100%;
}
</style>
