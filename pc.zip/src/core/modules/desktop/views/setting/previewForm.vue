<template>
    <l-quick-bi-viewer ref="quickViewer" :isPreview="true" ></l-quick-bi-viewer>
</template>
<script>


export default {
    mounted () {
    },
    methods:{
        resetForm(){
            this.$refs.quickViewer.reset()
        },
        setForm(data){
            this.$refs.quickViewer.set(data)
        }
    }
}
</script>

