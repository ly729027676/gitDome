<template>
  <div >
    <el-form-item label="最大行数">
        <el-input-number v-model="config.maxRows"
            controls-position="right"
            placeholder="请输入"></el-input-number>
    </el-form-item>
  </div>
</template>
<script>
export default {
    props: ['data'],
    data () {
        return {
        }
    },
    computed:{
      config(){
          return this.data
      }
    }
}
</script>

