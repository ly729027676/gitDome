<template>
    <l-data-panel 
        :label="data.label"
        >
        <l-echarts ref="main" :option="option" ></l-echarts>
    </l-data-panel>
</template>
<script>
import mixin from '../chart'
export default {
    mixins:[mixin()],
    data () {
        return {
            option:{
                xAxis: {
                    type: 'category',
                    data: []
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    data: [],
                    type: 'line'
                }]
            }
        }
    },
    methods:{
        async getOption(){
            if(this.data.dataType == 'Y'){
                this.option.xAxis = {
                    type: 'category',
                    data: []
                }
                this.option.yAxis = {
                    type: 'value'
                }
            }
            else{
                this.option.xAxis = {
                    type: 'value'
                }
                this.option.yAxis = {
                    type: 'category',
                    data: []
                }
            }
            
            // 加载数据
            if(this.data.dataCode){
                await this.lr_loadDataSourceData(this.data.dataCode,!!this.isPreview)
            }
           
            const data = this.lr_dataSourceData[this.data.dataCode] || []

            if(this.data.XKey && this.data.YKey){
                const xList = []
                const yList = []
                
                data.forEach(item=>{
                    xList.push(item[this.data.XKey])
                    yList.push(item[this.data.YKey])
                })

                if(this.data.dataType == 'Y'){
                    this.option.series[0].data = yList
                    this.option.xAxis.data = xList
                }
                else{
                    this.option.series[0].data = xList
                    this.option.yAxis.data = yList
                }

            }
            return this.option
        }
    }
}
</script>

