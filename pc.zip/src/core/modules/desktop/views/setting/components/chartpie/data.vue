<template>
  <div>
    <el-form-item label="数据源">
        <l-select  
                v-model="config.dataCode"
                placeholder="请选择数据源" 
                size="mini" 
                :options="lr_dataSource" 
                labelKey="f_Name" 
                valueKey="f_Code"
                filterable

                @change="handleDataSourceChange"
            >
        </l-select>
    </el-form-item>
    <el-form-item label="名称值" >
        <l-select
                v-model="config.nameKey"
                placeholder="请选择" 
                size="mini" 
                :options="myColNameList"

                filterable
            >
        </l-select>
    </el-form-item>
    <el-form-item label="显示值" >
        <l-select
                v-model="config.valueKey"
                placeholder="请选择" 
                size="mini" 
                :options="myColNameList"

                filterable
            >
        </l-select>
    </el-form-item>
  </div>
</template>
<script>
export default {
    props: ['data'],
    computed:{
        config(){
            return this.data
        },
        myColNameList(){
            if(this.lr_dataSourceCol && this.config.dataCode){
                const colNameList = this.lr_dataSourceCol[this.config.dataCode] || []
                return colNameList.map(t=>{return {value:t,label:t}})
            }
            else{
                return []
            }
        }
    },
    created(){
        if(this.config.dataCode){
            this.lr_loadDataSourceColNames(this.config.dataCode)
        }
    },
    methods: {
        handleDataSourceChange(){
            this.config.nameKey = ''
            this.config.valueKey = ''
            if(!this.$validatenull(this.config.dataCode)){
                this.lr_loadDataSourceData(this.config.dataCode)
                this.lr_loadDataSourceColNames(this.config.dataCode)
            }
        }
    }
}
</script>

