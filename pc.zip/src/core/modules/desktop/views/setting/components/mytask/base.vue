<template>
  <div >
  </div>
</template>
<script>
export default {
    props: ['data'],
    data () {
        return {
        }
    }
}
</script>

