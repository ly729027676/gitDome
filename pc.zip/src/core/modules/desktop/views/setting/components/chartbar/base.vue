<template>
    <div>
        <el-form-item label="显示背景">
            <el-switch v-model="config.showBackground" ></el-switch>
        </el-form-item>
        <el-form-item v-if="config.showBackground" label="背景颜色">
            <l-input-color v-model="config.backgroundColor"
                            placeholder="请输入"></l-input-color>
        </el-form-item>
    </div>
</template>
<script>
export default {
    props: ['data'],
    data () {
        return {
        }
    },
    computed:{
        config(){
            return this.data
        },
    }
}
</script>

