<template>
    <l-data-panel 
        :label="data.label"
        >
        <l-echarts ref="main" :option="option" ></l-echarts>
    </l-data-panel>
</template>
<script>
import mixin from '../chart'
export default {
    mixins:[mixin()],
    data () {
        return {
            option: {
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                },
                series: [
                    {
                        name: '',
                        type: 'pie',
                        radius: '50%',
                        data: [
                        ],
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            }
        }
    },
    methods:{
        async getOption(){
            this.option.series[0].name = this.data.label
            // 加载数据
            if(this.data.dataCode){
                await this.lr_loadDataSourceData(this.data.dataCode,!!this.isPreview)
            }
           
            const data = this.lr_dataSourceData[this.data.dataCode] || []

            if(this.data.nameKey && this.data.valueKey){
                this.option.series[0].data = data.map(t=>{ return {name:t[this.data.nameKey],value:t[this.data.valueKey]} })
            }

            return this.option
        }
    }
}
</script>

