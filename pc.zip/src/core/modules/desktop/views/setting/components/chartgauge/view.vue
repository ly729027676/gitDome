<template>
    <l-data-panel 
        :label="data.label"
        >
        <l-echarts ref="main" :option="option" ></l-echarts>
    </l-data-panel>
</template>
<script>
import mixin from '../chart'
export default {
    mixins:[mixin()],
    data () {
        return {
            option: {
                tooltip: {
                    formatter: '{a}: {c}'
                },
                series: [{
                    name: '',
                    type: 'gauge',
                    detail: {
                        formatter: '{value}'
                    },
                    data: []
                }]
            },
        }
    },
    methods:{
        async getOption(){
            this.option.series[0].name = this.data.label
            // 加载数据
            if(this.data.dataCode){
                await this.lr_loadDataSourceData(this.data.dataCode,!!this.isPreview)
            }
           
            const data = this.lr_dataSourceData[this.data.dataCode] || []

            if(this.data.dataValueKey && data.length > 0){
                this.option.series[0].data.push({value:data[0][this.data.dataValueKey]})
            }
            return this.option
        }
    }
}
</script>

