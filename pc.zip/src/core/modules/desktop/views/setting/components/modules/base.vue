<template>
  <div >
    <el-divider>功能列表</el-divider>
    <div class="reg-item" :key="item.id" v-for="(item,index) in config.list" >
        <el-form-item label="绑定功能" style="margin-bottom:8px;" >
            <l-tree-select :options="modulesTree"  v-model="item.moduleId" >
            </l-tree-select>
        </el-form-item>
        <el-form-item label="图标颜色" style="margin-bottom:0;" >
            <l-input-color v-model="item.color"
                       placeholder="请输入"></l-input-color>
        </el-form-item>
        <el-button title="删除"
                    @click="handleRemoveCol(index)"
                    class="reg-item-delete"
                    circle
                    plain
                    size="mini"
                    type="danger">
            <i class="el-icon-close"></i>
        </el-button>
    </div>
    <div class="mt-8" >
        <el-button class="ml-8" type="primary" size="mini" @click="handleAddCol" >添加功能</el-button>
    </div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
export default {
    props: ['data'],
    data () {
        return {
        }
    },
    computed:{
        config(){
          return this.data
        },
        ...mapGetters(["modules"]),
        myModules(){
            //if(this.loginInfo.f_SecurityLevel == 1){
                return this.modules.filter(t=>t.f_EnabledMark == 1)
            /*}
            return this.modules.filter(item =>{
                if(item.f_EnabledMark == 1){
                    const moduleAuthIds = this.loginInfo.moduleAuthIds || []
                    if(moduleAuthIds.indexOf(item.f_ModuleId) > -1){
                        return true
                    }
                    else{
                        return false
                    }
                }
                else{
                    return false
                }
            })*/
        },
        modulesTree(){
            const res = this.$toTree(this.myModules,"f_ModuleId","f_ParentId","f_ModuleId","f_FullName")
            return res.filter(t=>t.f_ParentId == '0')
        }
    },
    methods:{
      handleAddCol(){
          this.config.list.push({
              id:this.$uuid(),
              moduleId:'',
              color:'#409eff',
          })
      },
      handleRemoveCol(index){
          this.config.list.splice(index,1)
      }
    }
}
</script>

