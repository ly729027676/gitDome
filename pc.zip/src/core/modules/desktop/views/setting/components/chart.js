import { mapGetters } from "vuex"
export default function () {
    return{
        props: ['data','isPreview','isShow'],
        data(){
            return {
                timer:null
            }
        },
        computed:{
            ...mapGetters(["isCollapse","screen"])
        },
        watch:{
            isShow(){
                setTimeout(() => {
                    this.$refs.main.updateChart()
                }, 100);
            },
            data:{
                handler(){
                    this.refresh()
                },
                deep: true
            },
            isCollapse(){
                setTimeout(() => {      
                    this.$refs.main.updateChart()
                }, 100)
            },
            screen(){
                setTimeout(() => {      
                    this.$refs.main.updateChart()
                }, 100)
            }            
        },
    
        mounted(){
            this.refresh()
        },
        methods:{
            refresh(){
                if(this.timer == null){
                    this.timer = setTimeout(async ()=>{
                        const option = await this.getOption()
                        this.$refs.main.updateChart(option)
                        this.timer = null
                    },100)
                }
            }
        }
        
    }
}