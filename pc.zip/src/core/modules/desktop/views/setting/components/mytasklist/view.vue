<template>
    <div class="l-rblock" >
        <l-data-list 
                :columns="columns"
                :isMore="true" 
                :label="data.label"

                :data="dataSource"
                @more="handleMore" 
                @itemClick="handleClick" >
        </l-data-list>
        <component ref="messageBox"  :is="'handleWF'"></component>
    </div>
</template>
<script>
import { mapGetters } from "vuex";
const api = window.$api.workflow.process
export default {
    props: ['data','isPreview'],
    data () {
        return {
            dataSource:[],
            columns:[
                {label:'标题',prop:'f_ProcessTitle',width:70},
                {label:'时间',prop:'f_CreateDate',width:30,dataType:'datetime',align:'right'}
            ]
        }
    },
    computed:{
        ...mapGetters(["modules"]),
    },
    mounted(){
        this.loadData()
    },
    methods:{
        handleMore(){
            if(!this.isPreview){
                const module = this.modules.find(t=>t.f_EnCode == 'NWFProcess')
                if(module){
                    this.$router.$lrRouter.goto(module)
                }
            }
        },
        handleClick(item){
            this.openMessageBox({
                f_Content:`【审核】${item.f_ProcessTitle},${item.f_UnitName}`,
                f_ContentId:item.f_Token
            },()=>{
                this.loadData()
            },0)
        },
        openMessageBox(item,callback,num){
            if(this.$refs.messageBox){
                this.$nextTick(async ()=>{
                    this.$refs.messageBox.open(item,callback)
                })
            }
            else if(num < 100){
                setTimeout(async ()=>{
                    num++
                    this.openMessageBox(item,callback,num)    
                },100)
            }
        },
        async loadData(){
            const queryData = {
                rows:this.data.maxRows,
                page:1,
                sidx:'F_CreateDate DESC'
            }
            // 加载代办任务
            const unCompletedData = await this.$awaitWraper(api.getUnCompletedMyPage(queryData))
            this.dataSource = unCompletedData.rows

        },
    }
}
</script>

