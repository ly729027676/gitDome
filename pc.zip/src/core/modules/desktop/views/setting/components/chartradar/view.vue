<template>
    <l-data-panel 
        :label="data.label"
        >
        <l-echarts ref="main" :option="option" ></l-echarts>
    </l-data-panel>
</template>
<script>
import mixin from '../chart'
export default {
    mixins:[mixin()],
    data () {
        return {
            option: {
                legend: {
                    data: ['预算分配（Allocated Budget）', '实际开销（Actual Spending）']
                },
                radar: {
                    indicator: [
                        /*{ name: '销售（Sales）', max: 6500},
                        { name: '管理（Administration）', max: 16000},
                        { name: '信息技术（Information Technology）', max: 30000},
                        { name: '客服（Customer Support）', max: 38000},
                        { name: '研发（Development）', max: 52000},
                        { name: '市场（Marketing）', max: 25000},
                        { name: '研发1（Development）', max: 52000},
                        { name: '市场2（Marketing）', max: 25000}*/
                    ]
                },
                series: [{
                    type: 'radar',
                    data: [

                    ]
                }]
            },
            timer:null
        }
    },
    methods:{
        async getOption(){
            this.option.radar.indicator = this.$deepClone(this.data.indicator)
            // 加载数据
            if(this.data.dataCode){
                await this.lr_loadDataSourceData(this.data.dataCode,!!this.isPreview)
            }
            const data = this.lr_dataSourceData[this.data.dataCode] || []

            const legend = []
            const series = []

            data.forEach(item => {
                legend.push(item[this.data.nameKey])
                const point = {
                    name:item[this.data.nameKey],
                    value:[]
                }
                series.push(point)
                this.data.indicator.forEach(indicatorItem=>{
                    point.value.push(item[this.data.indicatorKey[indicatorItem.id]])
                })

            });

            this.option.legend.data = legend

            this.option.series[0].data = series



            //console.log(data)

            return this.option
        }
    }
}
</script>

