<template>
    <l-data-board v-bind="data" :value="value" @click.native="handleClick" ></l-data-board>
</template>
<script>
import { mapGetters } from "vuex";
export default {
    props: ['data','isPreview'],
    data () {
        return {
        }
    },
    computed:{
         ...mapGetters(["modules"]),
        value(){
            if(this.data.dataCode && this.lr_dataSourceData && this.data.dataValueKey){
                const data = this.lr_dataSourceData[this.data.dataCode]
                if(data){
                    return data[0][this.data.dataValueKey]
                }
                else{
                    return 0
                }
                
            }
            else{
                return 0
            }
        }
    },

    mounted(){
        if(this.data.dataCode){
            this.lr_loadDataSourceData(this.data.dataCode,!!this.isPreview)
        }
    },
    
    methods:{
        handleClick(){
            if(!this.isPreview && this.data.moduleId){
                const module = this.$deepClone(this.modules.find(t=>t.f_ModuleId == this.data.moduleId))
                if(module){
                    if(this.data.conditionInfo){
                        const code = this.$route.query.src
                        window.$ldparam = `${code}|${this.data.i}`
                        this.$router.$lrRouter.goto(module)
                    }
                    else{
                        this.$router.$lrRouter.goto(module)
                    }
                }
            }
        }
    }
}
</script>

