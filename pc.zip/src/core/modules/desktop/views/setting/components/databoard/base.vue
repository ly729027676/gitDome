<template>
  <div>
    <el-form-item label="图标">
        <l-input-icon :iconList="iconList"  v-model="config.icon" >
        </l-input-icon>
    </el-form-item>
    <el-form-item label="主题">
        <l-select :options="options"  v-model="config.theme" >
        </l-select>
    </el-form-item>
    <el-form-item label="跳转功能">
        <l-tree-select :options="modulesTree"  v-model="config.moduleId" >
        </l-tree-select>
    </el-form-item>
    <div class="mt-8" >
        <el-button class="ml-8" type="primary" size="mini" @click="handleSettingCondition"  >设置跳转条件</el-button>
    </div>



    <l-dialog 
        title="设置跳转条件"
        :visible.sync="formVisible"
        :height="528"
        :width="720"
        @ok="handleSave"
        @close="handleCloseForm"
        @opened="handleOpenedForm"
        >
        <my-form ref="form" ></my-form>       
    </l-dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import MyForm from '../conditionForm.vue'
export default {
    props: ['data'],
    components:{
        MyForm
    },
    data () {
        return {
            options:[{value:0,label:'主题1'},{value:1,label:'主题2'},{value:2,label:'主题3'},{value:3,label:'主题4'}],
            formVisible:false
        }
    },
    computed:{
        config(){
            return this.data
        },
        iconList(){
            if(this.lr_icons){
                return this.lr_icons
            }
            else{
                return []
            }
        },
        ...mapGetters(["modules"]),
        myModules(){
            //if(this.loginInfo.f_SecurityLevel == 1){
                return this.modules.filter(t=>t.f_EnabledMark == 1 && t.f_Target.indexOf('desktop') == -1)
            //}
            /*return this.modules.filter(item =>{
                if(item.f_EnabledMark == 1 && item.f_Target.indexOf('desktop') == -1){
                    const moduleAuthIds = this.loginInfo.moduleAuthIds || []
                    if(moduleAuthIds.indexOf(item.f_ModuleId) > -1){
                        return true
                    }
                    else{
                        return false
                    }
                }
                else{
                    return false
                }
            })*/
        },
        modulesTree(){
            const res = this.$toTree(this.myModules,"f_ModuleId","f_ParentId","f_ModuleId","f_FullName")
            return res.filter(t=>t.f_ParentId == '0')
        }
    },
    methods:{
        handleSettingCondition(){
            if(this.config.moduleId){
                const module = this.modules.find(t=>t.f_ModuleId == this.config.moduleId)
                if(module.f_Target == 'custmerForm'){
                    this.formVisible = true
                }
                else{
                    this.$message({
                        type: 'warning',
                        message: '目前只支持自定义表单功能设置条件!'
                    })
                }
            }
            else{
                this.$message({
                    type: 'warning',
                    message: '请设置跳转功能!'
                })
            }
        },
        async handleSave(){
            if(this.$refs.form.validateForm()){
                this.config.conditionInfo = this.$refs.form.getForm()
                this.formVisible = false
            }
        },
        handleCloseForm(){
            this.$refs.form.resetForm()
        },
        handleOpenedForm(){
            this.$refs.form.setForm(this.config.moduleId,this.config.conditionInfo)
        }
    }
}
</script>

