export default {
    name: '桌面模块',
    code: 'desktop',
    version: '1.0.0',
    description: '配置动态桌面'
}