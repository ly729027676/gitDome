import md5 from 'js-md5'
import Vue from 'vue'
const api = window.$api.organization.user

let UserLoadTimer = null // 加载用户信息定时器
const UserLoadings = []  // 需要加载的用户信息
export default {
    namespaced: true,
    state: {
        loginInfo: {},
        token: window.$getStore({ name: 'token' }) || '',

        updateList:{},
        map:{},
    },
    actions: {
        //根据用户账号登录
        login ({ commit }, {account,password}) {
            password = md5(password)
            return new Promise((resolve,reject) => {
                api.login(account, password).then(res => {
                    const data = res.data.data
                    commit('SET_TOKEN', data.token)
                    commit('DEL_ALL_TAG','',{ root: true })
                    resolve()
                }).catch(err => {
                    reject(err)
                })
            })
        },
        getLoginInfo ({ commit }) {
            return new Promise((resolve, reject) => {
                api.getLoginInfo().then((res) => {
                    const data = res.data.data
                    commit('SET_USERIFNO', data)
                    resolve(data)
                }).catch(err => {
                    reject(err)
                })
            })
        },
        //注销session
        fedLogOut ({ commit }) {
          return new Promise(resolve => {
              commit('SET_TOKEN', '')
              commit('SET_TAG_LIST', [],{ root: true })
              commit('DEL_ALL_TAG','',{ root: true })
              commit('system/module/setMenu', [],{ root: true })
              resolve()
          })
        },

        async load({ commit,state },{userIds,isCache}){
          userIds.forEach(userId => {
            if(!state.updateList[userId] || !isCache){
              state.updateList[userId] = true
              UserLoadings.push(userId)
            }
          })


          // 50ms 内只执行一次
          if(UserLoadings.length > 0 && !UserLoadTimer){
            UserLoadTimer = setTimeout(async ()=>{
                const req = String(UserLoadings)
                UserLoadings.length = 0
                UserLoadTimer = null
                const res = await api.getUsers(req)
                const data = res.data.data
                data.forEach(item=>{
                    commit('SET_USER_MAP', {entity:item,userId:item.f_UserId})
                })
            }, 50);
          }
        },
        update({ commit},user){
            commit('SET_USER_MAP', {entity:user,userId:user.f_UserId})
        }
    },
    mutations: {
        SET_TOKEN: (state, token) => {
            state.token = token
            window.$setStore({ name: 'token', content: state.token })
        },
        SET_USERIFNO: (state, loginInfo) => {
            state.loginInfo = loginInfo
        },
        SET_USER_MAP:(state, payload) => {
            Vue.set(state.map,payload.userId,payload.entity)
        },
    }
}