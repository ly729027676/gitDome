const api = window.$api.organization.company
const Company = {
    namespaced: true,
    state:{
        isLoad:false,
        list:[]
    },
    actions:{
        async load({ commit,state},isCache = true){
            if(!state.isLoad || !isCache){
                state.isLoad = true
                const res = await api.getList()
                const data = res.data.data
                commit('SET_LIST', data)
            }
        }
    },
    mutations:{
        SET_LIST: (state, payload) => {
            state.list = payload
        }
    }
}

export default Company