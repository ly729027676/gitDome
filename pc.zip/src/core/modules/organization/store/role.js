import Vue from 'vue'
const api = window.$api.organization.role
const Role = {
    namespaced: true,
    state:{
        updateList:{},
        map:{},
        list:[],
        updateState:false
    },
    actions:{
        async loadList({ commit,state},isCache){
            if(!state.updateState || !isCache){
                state.updateState = true
                var res = await api.getList()
                const data = res.data.data
                commit('SET_ROLE_LIST', data)
            }
        },
        async load({ commit,state},{roleId,isCache}){
            if(!state.updateList[roleId] || !isCache){
                state.updateList[roleId] = true
                var res = await api.get(roleId)
                const data = res.data.data
                commit('SET_ROLE_MAP', {roleId,entity:data})
            }
        }
    },
    mutations:{
        SET_ROLE_MAP:(state, payload) => {
            Vue.set(state.map,payload.roleId,payload.entity)
        },
        SET_ROLE_LIST:(state, payload) => {
            state.list = payload
        },
    }
}

export default Role