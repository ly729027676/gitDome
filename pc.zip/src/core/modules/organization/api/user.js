export default url => {
    const crud = window.$crud(url)

    const getUsers = (ids) => window.$axios({
        url: `${url}s`,
        method: 'post',
        data:{ids}
    })

    const updateState = (id,state) => window.$axios({
        url: `${url}/state/${id}`,
        method: 'put',
        params:{
            state
        }
    })

    const resetPassword = (id) => window.$axios({
        url: `${url}/resetpsw/${id}`,
        method: 'put'
    })

    const validatorPassword = (psw) => window.$axios({
        url: `${url}/validator/${psw}`,
        method: 'get'
    })
    
    const updatePassword = (req) => window.$axios({
        url: `${url}/password`,
        method: 'put',
        data:req
    })

    const login = (account, password) => window.$axios({
        url: 'login',
        method: 'post',
        meta: {
            isToken: false
        },
        data: {
            account,
            password
        }
    })
    
    const getLoginInfo = () => window.$axios({
        url: 'login/pc',
        method: 'get'
    })

    const removeCache = () => window.$axios({
        url: 'login/cache',
        method: 'post'
    })


    return {
        ...crud,
        getUsers,
        updateState,
        resetPassword,
        validatorPassword,
        updatePassword,

        login,
        getLoginInfo,

        removeCache
    }
}