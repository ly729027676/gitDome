export default url => {
    const crud = window.$crud(url)
    crud.getList = (companyId) => window.$axios({
        url: `${url}s/${companyId}`,
        method: 'get'
    })

    const getDepartments = (ids) => window.$axios({
        url: `${url}s`,
        method: 'post',
        data:{ids}
    })
    return {
        ...crud,
        getDepartments
    }
}