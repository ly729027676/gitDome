export default url => {
    const crud = window.$crud(url)
    const gets = (ids) => window.$axios({
        url: `${url}s`,
        method: 'post',
        data:{ids}
    })
    return {
        ...crud,
        gets
    }
}