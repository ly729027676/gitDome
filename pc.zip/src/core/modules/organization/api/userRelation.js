


export default url => {
    const getList = (id) => window.$axios({
        url: `${url}/${id}`,
        method: 'get'
    })
    
    const save = (id,type,data) => window.$axios({
        url: `${url}/${type}/${id}`,
        method: 'post',
        data:data
    })
    
    return {
        getList,
        save
    }
}

