export default {
    name: '组织机构',
    code: 'organization',
    version: '1.0.0',
    description: '帐号，组织架构'
}