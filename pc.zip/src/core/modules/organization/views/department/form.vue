<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="88px" >
            <el-col :span="12" v-if="lr_hasPageAuth('f_FullName')">
                <el-form-item label="名称" prop="f_FullName">
                    <el-input v-model="formData.f_FullName"></el-input>
                </el-form-item>
            </el-col>
            
            <el-col :span="12" v-if="lr_hasPageAuth('f_EnCode')">
                <el-form-item label="编码" prop="f_EnCode">
                    <el-input v-model="formData.f_EnCode"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_ShortName')">
                <el-form-item label="简称" prop="f_ShortName">
                    <el-input v-model="formData.f_ShortName"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Nature')">
                <el-form-item label="性质" prop="f_Nature">
                    <l-select 
                        :options="lr_dataItem['DepartmentNature']"
                        labelKey="f_ItemName"
                        valueKey="f_ItemValue"
                        v-model="formData.f_Nature" ></l-select>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_ParentId')">
                <el-form-item label="上级" prop="f_ParentId">
                    <l-tree-select
                        v-model="formData.f_ParentId"
                        :options="departmentTree"
                        >
                    </l-tree-select>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Manager')">
                <el-form-item label="管理人" prop="f_Manager">
                    <l-user-select v-model="formData.f_Manager"></l-user-select>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_OuterPhone')">
                <el-form-item label="电话" prop="f_OuterPhone">
                    <el-input v-model="formData.f_OuterPhone"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_InnerPhone')">
                <el-form-item label="分机号" prop="f_InnerPhone">
                    <el-input v-model="formData.f_InnerPhone"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Email')">
                <el-form-item label="邮箱" prop="f_Email">
                    <el-input v-model="formData.f_Email"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Fax')">
                <el-form-item label="传真" prop="f_Fax">
                    <el-input v-model="formData.f_Fax"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24" v-if="lr_hasPageAuth('f_Description')">
                <el-form-item label="描述" prop="f_Description">
                    <el-input type="textarea" v-model="formData.f_Description"></el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            formData:{
                f_CompanyId:'',
                f_FullName:'',
                f_ShortName:'',
                f_EnCode:'',
                f_Nature:'',
                f_ParentId:'0',
                f_Manager:'',
                f_OuterPhone:'',
                f_InnerPhone:'',
                f_Email:'',
                f_Fax:'',
                f_Description:''
            },
            rules: {
                f_FullName: [
                    { required: true, message: '请输入部门名称' }
                ],
                f_EnCode: [
                    { required: true, message: '请输入部门编号' },
                    { pattern: /^[-+]?\d+$/, message: '部门编号需要为数字' },
                    { validator: this.lr_existDbFiled,keyValue:() => { return this.formData.f_DepartmentId },tableName:'lr_base_department',keyName:'f_DepartmentId',trigger: 'null'}
                ]
            }
        }
    },
    computed:{
        departmentTree(){
            return this.$toTree(this.lr_departments[this.formData.f_CompanyId] || [],"f_DepartmentId","f_ParentId","f_DepartmentId","f_FullName",[this.formData.f_DepartmentId])
        }
        
    },
    created () {
         this.lr_loadDataItem('DepartmentNature')
    },
    methods:{
        resetForm(){
            this.formData.f_DepartmentId = ''
            this.$refs.form && this.$refs.form.resetFields()
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback()
                }
            })
        },
        setForm(data){
            this.formData = this.$deepClone(data)
        },
        getForm(){
            return this.$deepClone(this.formData)
        }
    }
}
</script>