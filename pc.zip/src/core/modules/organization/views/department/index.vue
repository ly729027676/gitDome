<template>
    <l-layout class="l-tab-page" v-show="!lr_loadPage" :left="240" >
        <template #left>
            <l-panel :title="$t('公司信息')" style="padding-right:0;" >
                <el-tree 
                    ref="mytree"
                    v-loading="treeLoading" 
                    node-key="value"
                    :data="lr_companyTree" 
                    default-expand-all 
                    :expand-on-click-node="false"  
                    :current-node-key="companyId"
                    @node-click="handleNodeClick">
                    <span class="lr-tree-node"  slot-scope="{ node}">
                        <i class="fa fa-sitemap"></i>
                        {{ $t(node.label) }}
                    </span>
                </el-tree>
            </l-panel>
        </template>
        <l-panel style="padding-left:0;" >
            <template #toolLeft >
                <div class="l-panel--item" >
                    <el-input :placeholder="$t('请输入关键字')"  @keyup.enter.native="hanleSearch" v-model="searchWord" size="mini" >
                        <el-button @click="hanleSearch" slot="append" icon="el-icon-search"></el-button>
                    </el-input>
                </div>
            </template>
            <template #toolRight >
                <l-tool-btns @click="handleAdd()" >
                    <l-excel-btns></l-excel-btns>
                </l-tool-btns>
            </template>
            <l-table 
                :columns="lr_getPageColumns(columns)" 
                :dataSource="tableData" 
                :loading="loading" 
                row-key="f_DepartmentId"
                default-expand-all
                >
                <template v-slot:f_EnabledMark="scope" >
                    <el-switch
                        :active-value="1"
                        :inactive-value="0"
                        v-model="scope.row.f_EnabledMark"
                        @change="handleEnableChange(scope.row)"
                        >
                    </el-switch>
                </template>
                <l-table-btns :btns="tableBtns" @click="lr_handleTableBtnClick" ></l-table-btns>
            </l-table>
        </l-panel>

        <l-dialog 
            :title="formTitle"
            :visible.sync="formVisible"
            @ok="handleSave"
            @close="handleCloseForm"
            @opened="handleOpenedForm"
            >
            <my-form ref="form" ></my-form>       
        </l-dialog>
    </l-layout>
</template>

<script>
const api = window.$api.organization.department

import MyForm from './form'
export default {
    components: {
        MyForm
    },
    data () {
        return {
            lr_isPage:true,
            //查询
            searchWord:'',
            searchTableData:null,

            loading:false,
            columns: [
                {label:'名称',prop:'f_FullName',minWidth:'150'},
                {label:'编码',prop:'f_EnCode',width:'100'},
                {label:'性质',prop:'f_Nature',width:'80',align:'center'},
                {label:'负责人',prop:'f_Manager',width:'80',align:'center',dataType:'user'},
                {label:'电话号',prop:'f_OuterPhone',width:'100'},
                {label:'分机号',prop:'f_InnerPhone',width:'60',align:'center'},
            ],
            tableBtns:[
                {prop:'Edit',label:'编辑'},
                {prop:'Delete',label:'删除'}
            ],

            treeLoading:false,
            companyId:'',

            formVisible:false,
            formTitle:'',
            formEditRow:null,
            formEdit:false
        }
    },
    computed:{
        list(){
            return this.lr_departments[this.companyId] || []
        },
        tableData(){
            if( this.loading){
                return []
            }

            if(this.searchTableData){
                return this.lr_departmentTree(this.searchTableData)
            }
            else{
                return this.lr_departmentTree(this.list)
            }
        }
    },
    mounted () {
        this.init()
    },
    methods:{
        async init(){
            this.lr_loadDataItem('DepartmentNature')

            this.companyId = '53298b7a-404c-4337-aa7f-80b2a4ca6681'
            this.loadTableData()

            this.treeLoading = true
            await this.lr_loadCompanys()
            this.$refs["mytree"].setCurrentKey('53298b7a-404c-4337-aa7f-80b2a4ca6681')
            this.treeLoading = false
        },

        async loadTableData(){
            this.loading = true
            await this.lr_loadDepartments(this.companyId,false)
            this.searchWord = ''
            this.searchTableData = null
            this.loading = false
        },
        hanleSearch(){
            if(this.searchWord){
                this.searchTableData = this.list.filter(item => item.f_FullName.indexOf(this.searchWord) >-1 || item.f_EnCode.indexOf(this.searchWord)>-1)
            }
            else{
                this.searchTableData = null
            }
        },
        handleNodeClick(node) {
            this.loading = true
            this.companyId = node.f_CompanyId
            this.loadTableData()
        },

        handleAdd(){
            if(this.companyId){
                this.formEdit = false
                this.showForm('新增部门')
            }
            else{
                this.$message({
                    type: 'warning',
                    message: '请选择左侧公司!'
                })
            }
        },
        handleEdit($index,row){
            this.formEdit = true
            this.formEditRow = row
            this.showForm('编辑部门')
        },
        handleDelete($index,row){
            this.$confirm(this.$t('此操作将永久删除该数据, 是否继续?'), this.$t('提示'), {
                confirmButtonText: this.$t('确定'),
                cancelButtonText: this.$t('取消'),
                type: 'warning'
            }).then(() => {
                api.remove(row.f_DepartmentId).then(()=> {
                    this.$message({
                        type: 'success',
                        message: '删除成功!'
                    })
                    this.loadTableData()
                }).catch(() => {})
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })        
            })
        },
        handleSave(showLoading,hideLoading){
            this.$refs.form.validateForm(()=>{
                showLoading()
                const formData = this.$refs.form.getForm()
                if(this.formEdit){// 修改数据
                    api.update(formData.f_DepartmentId,formData).then(()=> {
                        hideLoading()
                        this.formVisible = false
                        this.$message({
                            type: 'success',
                            message: '更新成功!'
                        })
                        this.loadTableData()
                    }).catch(() => {
                        hideLoading()
                    })
                }
                else{// 新增数据
                    api.add(formData).then(()=> {
                        hideLoading()
                        this.formVisible = false
                        this.$message({
                            type: 'success',
                            message: '添加成功!'
                        })
                        this.loadTableData()
                    }).catch(() => {
                        hideLoading()
                    })
                }
            })
        },
        handleOpenedForm(){
            if(this.formEdit){
                this.$refs.form.setForm(this.formEditRow)
            }
            else{
                const formData = this.$refs.form.getForm()
                formData.f_CompanyId = this.companyId
                this.$refs.form.setForm(formData)
            }
        },
        handleCloseForm(){
            this.$refs.form.resetForm()
        },
        showForm(text){
            this.formTitle = text
            this.formVisible = true
        }
    }
}
</script>
