<template>
  <div class="l-tab-page" style="padding:8px;" >
      <div class="l-rblock l-my-page" >
        <el-tabs tab-position="left" :stretch="true">
            <el-tab-pane label="基本信息"><user-baseinfo></user-baseinfo></el-tab-pane>
            <el-tab-pane label="联系方式"><user-contact></user-contact></el-tab-pane>
            <el-tab-pane label="我的头像"><user-head></user-head></el-tab-pane>
            <el-tab-pane label="修改密码"><user-password></user-password></el-tab-pane>
            <el-tab-pane label="我的日志"><user-log></user-log></el-tab-pane>
        </el-tabs>
      </div>
  </div>
</template>

<script>
import userBaseinfo from './baseinfo'
import userContact from './contact'
import userHead from './headForm'
import userPassword from './password'
import userLog from './log'
export default {
    components: {
        userBaseinfo,
        userContact,
        userHead,
        userPassword,
        userLog
    },
    data () {
        return {
        };
    },
    created () {
    },
    mounted () {
    },
    computed:{
    },
    methods:{
    }
}
</script>