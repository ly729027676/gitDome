<template>
    <div class="l-from-body" style="padding:8px 48px 8px 48px;" >
      <el-form label-position="left"  size="mini"  ref="form" label-width="60px">
          <el-divider content-position="left">联系方式</el-divider>
          <el-col :span="24">
              <el-form-item label="手机">
                  <el-input v-model="loginInfo.f_Mobile" readonly="readonly" ></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="电话">
                  <el-input v-model="loginInfo.f_Telephone" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="邮箱">
                  <el-input v-model="loginInfo.f_Email" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="微信">
                  <el-input v-model="loginInfo.f_WeChat" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="QQ">
                  <el-input v-model="loginInfo.f_OICQ" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
      </el-form>
    </div>
</template>

<script>
export default {
  name: "user-contact",
  data () {
    return {
    };
  },
  computed: {
  },
  created () { 
  },
  methods: {
  }
};
</script>