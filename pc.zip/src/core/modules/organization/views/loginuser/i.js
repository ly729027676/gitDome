export default {
    name:'个人信息',
    isNotMenu:true
}