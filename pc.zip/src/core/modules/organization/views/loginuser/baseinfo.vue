<template>
    <div class="l-from-body" style="padding:8px 48px 8px 48px;" >
      <el-form label-position="left"  size="mini"  ref="form" label-width="60px">
          <el-divider content-position="left">基本信息</el-divider>
          <el-col :span="24">
              <el-form-item label="账号" prop="f_Account">
                  <el-input v-model="loginInfo.f_Account" readonly="readonly" ></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="姓名" prop="f_RealName">
                  <el-input v-model="loginInfo.f_RealName" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="性别" prop="f_Gender">
                <el-radio v-model="loginInfo.f_Gender" disabled="disabled" :label="1">男</el-radio>
                <el-radio v-model="loginInfo.f_Gender" disabled="disabled" :label="0">女</el-radio>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="公司" prop="f_CompanyId">
                  <l-company :value="this.loginInfo.f_CompanyId" ></l-company>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="部门" prop="f_DepartmentId">
                  <l-department :value="this.loginInfo.f_DepartmentId" ></l-department>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="岗位" prop="postIds">
                  <el-input :value="lr_postName(loginInfo.postIds)" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="角色" prop="roleIds">
                  <el-input :value="lr_roleName(loginInfo.roleIds)" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
          <el-col :span="24">
              <el-form-item label="备注" prop="f_Description">
                  <el-input type="textarea" v-model="loginInfo.f_Description" readonly="readonly"></el-input>
              </el-form-item>
          </el-col>
      </el-form>
    </div>
</template>

<script>
export default {
  name: "user-baseinfo",
  data () {
    return {
    };
  },
  computed: {
  },
  methods: {
  }
};
</script>