<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="80px" >
            <el-col :span="12" v-if="lr_hasPageAuth('f_FullName')">
                <el-form-item label="名称" prop="f_FullName">
                    <el-input v-model="formData.f_FullName"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_ShortName')">
                <el-form-item label="简称" prop="f_ShortName">
                    <el-input v-model="formData.f_ShortName"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_EnCode')">
                <el-form-item label="编码" prop="f_EnCode">
                    <el-input v-model="formData.f_EnCode"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Nature')">
                <el-form-item label="性质" prop="f_Nature">
                    <l-select
                        :options="lr_dataItem['CompanyNature']"
                        labelKey="f_ItemName"
                        valueKey="f_ItemValue"
                        v-model="formData.f_Nature" ></l-select>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_ParentId')">
                <el-form-item label="上级" prop="f_ParentId">
                    <l-tree-select
                        v-model="formData.f_ParentId"
                        :options="companyTree">
                    </l-tree-select>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_FoundedTime')">
                <el-form-item label="成立" prop="f_FoundedTime">
                    <l-date v-model="formData.f_FoundedTime" dateType="date"  ></l-date>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Manager')">
                <el-form-item label="管理人" prop="f_Manager">
                    <l-user-select v-model="formData.f_Manager"></l-user-select>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_OuterPhone')">
                <el-form-item label="电话" prop="f_OuterPhone">
                    <el-input v-model="formData.f_OuterPhone"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Email')">
                <el-form-item label="邮箱" prop="f_Email">
                    <el-input v-model="formData.f_Email"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Fax')">
                <el-form-item label="传真" prop="f_Fax">
                    <el-input v-model="formData.f_Fax"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24" v-if="lr_hasPageAuth('f_Address')">
                <el-form-item label="地点" prop="f_Area">
                    <div class="l-fleft-block" style="width:50%;padding-right:8px;" >
                        <l-area-select v-model="formData.f_Area"></l-area-select>
                    </div>
                    <div class="l-fleft-block" style="width:50%;"  >
                        <el-input v-model="formData.f_Address" :placeholder="$t('请输入详细地址')" >
                        </el-input>
                    </div>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_Postalcode')">
                <el-form-item label="邮编" prop="f_Postalcode">
                    <el-input v-model="formData.f_Postalcode"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="lr_hasPageAuth('f_WebAddress')">
                <el-form-item label="官网" prop="f_WebAddress">
                    <el-input v-model="formData.f_WebAddress"></el-input>
                </el-form-item>
            </el-col>
            <!--<el-col :span="24">
                <el-form-item label="经营范围" prop="f_BusinessScope">
                    <el-input v-model="formData.f_BusinessScope"></el-input>
                </el-form-item>
            </el-col>-->
           
            <el-col :span="24" v-if="lr_hasPageAuth('f_Description')">
                <el-form-item label="描述" prop="f_Description">
                    <el-input type="textarea" v-model="formData.f_Description"></el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            formData:{
                f_FullName:'',
                f_ShortName:'',
                f_EnCode:'',
                f_Nature:'',
                f_ParentId:'0',
                f_FoundedTime:null,
                f_Manager:'',
                f_OuterPhone:'',
                f_Email:'',
                f_Fax:'',
                f_ProvinceId:'',
                f_CityId:'',
                f_CountyId:'',
                f_Address:'',
                f_Postalcode:'',
                f_WebAddress:'',
                f_Description:'',

                f_Area:''
            },
            rules: {
                f_FullName: [
                    { required: true, message: '请输入公司名称' }
                ],
                f_ShortName: [
                    { required: true, message: '请输入公司简称' }
                ],
                f_Nature: [
                    { required: true, message: '请选择公司性质' }
                ],
                f_EnCode: [
                    { required: true, message: '请输入公司编号' },
                    { pattern: /^[-+]?\d+$/, message: '公司编号需要为数字' },
                    { validator: this.lr_existDbFiled,keyValue:() => { return this.formData.f_CompanyId },tableName:'lr_base_company',keyName:'f_CompanyId',trigger: 'null'}
                ]
            }
        };
    },
    created () {
        this.lr_loadDataItem('CompanyNature')
    },
    computed:{
        companyTree(){
            return this.$toTree(this.lr_companyList,"f_CompanyId","f_ParentId","f_CompanyId","f_FullName",[this.formData.f_CompanyId])
        },
    },
    methods:{
        resetForm(){
            this.formData.f_ProvinceId = ''
            this.formData.F_CityId = ''
            this.formData.F_CountyId = ''
            this.formData.f_CompanyId = ''
            this.$refs.form && this.$refs.form.resetFields()
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback()
                }
            })
        },
        setForm(data){
            const formData = this.$deepClone(data)
            formData.children && delete formData.children
            if(!this.$validatenull(formData.f_ProvinceId)
               &&!this.$validatenull(formData.f_CityId)
               &&!this.$validatenull(formData.f_CountyId)){
                formData.f_Area = `${formData.f_ProvinceId},${formData.f_CityId},${formData.f_CountyId}`
            }
            this.formData = formData
        },
        getForm(){
            if(!this.$validatenull(this.formData.f_Area)){
                const areaList = this.formData.f_Area.split(",")
                this.formData.f_ProvinceId = areaList[0]
                this.formData.f_CityId = areaList[1]
                this.formData.f_CountyId = areaList[2]
            }
            return this.$deepClone(this.formData)
        }
    }
}
</script>