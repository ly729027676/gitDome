<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="60px" >
            <el-col :span="24" v-if="lr_hasPageAuth('f_EnCode')">
                <el-form-item label="编号" prop="f_EnCode" >
                    <el-input v-model="formData.f_EnCode"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24" v-if="lr_hasPageAuth('f_FullName')">
                <el-form-item label="名称" prop="f_FullName" >
                    <el-input v-model="formData.f_FullName"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24" v-if="lr_hasPageAuth('f_Category')">
                <el-form-item label="分类" prop="f_Category" >
                    <el-select v-model="formData.f_Category" placeholder="请选择">
                        <el-option
                        v-for="item in lr_dataItemOptions(lr_dataItem['rolecategory'])"
                        :key="item.f_ItemValue"
                        :label="item.f_ItemName"
                        :value="item.f_ItemValue">
                        </el-option>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="24" v-if="lr_hasPageAuth('f_EnabledMark')" >
                <el-form-item label="状态" prop="f_EnabledMark" >
                        <el-switch
                        :active-value="1"
                        :inactive-value="0"
                        v-model="formData.f_EnabledMark"
                        >
                    </el-switch>
                </el-form-item>
            </el-col>
            <el-col :span="24" v-if="lr_hasPageAuth('f_Description')">
                <el-form-item label="描述" prop="f_Description" >
                    <el-input type="textarea" v-model="formData.f_Description"></el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            formData:{
                f_EnCode:'',
                f_FullName:'',
                f_Category:'',
                f_EnabledMark:1,
                f_Description:''
            },
            rules: {
                f_EnCode: [
                    { required: true, message: '请输入编号' },
                    { validator: this.lr_existDbFiled,keyValue:() => { return this.formData.f_RoleId },tableName:'lr_base_role',keyName:'f_RoleId',trigger: 'blur'}
                ],
                f_FullName: [
                    { required: true, message: '请输入名称' }
                ],
                f_Category: [
                    { required: true, message: '请选择分类' }
                ]
            }
        };
    },
    created () {
    },
    methods:{
        resetForm(){
            this.formData.f_RoleId = '';
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        setForm(data){
            this.formData = this.$deepClone(data);
        },
        getForm(){
            return this.$deepClone(this.formData);
        }
    }
}
</script>