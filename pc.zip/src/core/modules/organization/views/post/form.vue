<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="88px" >
            <el-col :span="24">
                <el-form-item label="编号" prop="f_EnCode" v-if="lr_hasPageAuth('f_EnCode')">
                    <el-input v-model="formData.f_EnCode" placeholder="请输入" ></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="名称" prop="f_Name" v-if="lr_hasPageAuth('f_Name')">
                    <el-input v-model="formData.f_Name" placeholder="请输入"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="部门" prop="f_DepartmentId" v-if="lr_hasPageAuth('f_DepartmentId')">
                    <l-tree-select
                        v-model="formData.f_DepartmentId"
                        :options="lr_departmentTree(lr_departments[formData.f_CompanyId] || [])"
                        >
                    </l-tree-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="上级" prop="f_ParentId" v-if="lr_hasPageAuth('f_ParentId')">
                    <l-tree-select
                        v-model="formData.f_ParentId"
                        :options="postTree"
                        >
                    </l-tree-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="描述" prop="f_Description" v-if="lr_hasPageAuth('f_Description')">
                    <el-input type="textarea" v-model="formData.f_Description" rows="4" ></el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    props:{
        postlist:{
            type:Array,
            default:()=>[]
        },
        departmentsTree:{
            type:Array,
            default:()=>[]
        },
    },
    data(){
        return {
            formData:{
                f_CompanyId:'',
                f_ParentId:'0',
                f_EnCode:'',
                f_Name:'',
                f_DepartmentId:'',
                f_Description:''
            },
            rules: {
                f_EnCode: [
                    { required: true, message: '请输入编号' },
                    { pattern: /^[-+]?\d+$/, message: '岗位编号需要为数字' },
                    { validator: this.lr_existDbFiled,keyValue:() => { return this.formData.f_PostId },tableName:'lr_base_post',keyName:'f_PostId',trigger: 'null'}
                ],
                f_Name: [
                    { required: true, message: '请输入名称' }
                ],
                f_DepartmentId: [
                    { required: true, message: '请选择所属部门' }
                ]
            }
        };
    },
    computed:{
        postTree(){
            return this.$toTree(this.lr_posts[this.formData.f_CompanyId] || [],"f_PostId","f_ParentId","f_PostId","f_Name",[this.formData.f_PostId])
        }
    },


    created () {
    },
    methods:{
        resetForm(){
            this.formData.f_PostId = ''
            this.$formClear(this.$refs.form)
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        setForm(data){
            this.formData = this.$deepClone(data);
           
        },
        getForm(){
            return this.$deepClone(this.formData);
        }
    }
}
</script>