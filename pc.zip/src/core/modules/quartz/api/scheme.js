export default url => {
    const crud = window.$crud(url)

    const pauseJob = (id) => window.$axios({
        url: `${url}/job/pause/${id}`,
        method: 'post'
    })

    const resumeJob = (id) => window.$axios({
        url: `${url}/job/resume/${id}`,
        method: 'post'
    })

    return {
        ...crud,
        pauseJob,
        resumeJob
    }
}