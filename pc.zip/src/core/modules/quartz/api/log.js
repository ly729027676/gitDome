export default url => {
    const getPage = (params) => window.$axios({
        url: `${url}/page`,
        method: 'get',
        params:params
    })
    return {
        getPage
    }
}