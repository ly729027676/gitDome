export default {
    name: '任务调度模块',
    code: 'quartz',
    version: '1.0.0',
    description: '任务调度设计，任务执行日志'
  }