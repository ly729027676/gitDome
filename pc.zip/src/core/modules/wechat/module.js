export default {
    name: '企业微信模块',
    code: 'wechat',
    version: '1.0.0',
    description: '单位组织同步，人员同步'
  }