<template>
    <l-layout class="l-tab-page" v-show="!lr_loadPage" :left="240" >
        <template #left>
            <l-panel :title="$t('公司信息')" style="padding-right:0;" >
                <el-tree v-loading="treeLoading" :data="lr_companyTree" default-expand-all :expand-on-click-node="false"  @node-click="handleNodeClick">
                    <span class="lr-tree-node"  slot-scope="{node}">
                        <i class="fa fa-sitemap"></i>
                        {{ $t(node.label) }}
                    </span>
                </el-tree>
            </l-panel>
        </template>
        <l-panel style="padding-left:0;" >
            <template #toolLeft >
                <div class="l-panel--item" >
                    <l-tree-select
                        v-model="departmentId"
                        :placeholder="$t('请选择部门')"
                        :options="lr_departmentTree(lr_departments[companyId])"
                        size="mini"

                        @change="handleChangeDept"
                        >
                    </l-tree-select>
                </div>
                <div class="l-panel--item" >
                    <el-input :placeholder="$t('请输入姓名/账号/电话')"  @keyup.enter.native="hanleSearch" v-model="searchWord" size="mini" >
                        <el-button @click="hanleSearch" slot="append" icon="el-icon-search"></el-button>
                    </el-input>
                </div>
            </template>
            <template #toolRight >
                <l-tool-btns @click="handleAdd()" btnText="同步" >
                    <l-excel-btns></l-excel-btns>
                </l-tool-btns>
            </template>
            <l-table 
                :columns="lr_getPageColumns(columns)" 
                :dataSource="tableData" 
                :loading="tableLoading"
                row-key="f_UserId"
                :isPage="true"
                :pageTotal="tableTotal"
                :tablePage.sync="tableCurrentPage"
                @loadPageData="turnTablePage"
                >
                <template v-slot:f_Gender="scope" >
                    <el-tag v-if="scope.row.f_Gender == 1" size="mini" type="success">男</el-tag>
                    <el-tag v-else size="mini" type="danger">女</el-tag>
                </template>
                <template v-slot:f_CompanyId="scope" >
                    {{(lr_companyList.find(t=>t.f_CompanyId == scope.row.f_CompanyId) || {}).f_FullName || ''}}
                </template>
                <template v-slot:f_DepartmentId="scope" >
                    {{lr_departmentName(lr_departments[scope.row.f_CompanyId] || [],scope.row.f_DepartmentId)}}
                </template>
            </l-table>
        </l-panel>
    </l-layout>
</template>

<script>
const api = window.$api.wechat.user
export default {
    data () {
         return {
            lr_isPage:true,

            treeLoading:false,

            //查询
            searchWord:'',
            searchTableData:null,

            tableLoading:false,
            columns: [
                {label:'姓名',prop:'f_RealName',minWidth:'110'},
                {label:'账号',prop:'f_Account',width:'110'},
                {label:'手机',prop:'f_Mobile',width:'108'},
                {label:'公司',prop:'f_CompanyId',width:'120'},
                {label:'部门',prop:'f_DepartmentId',width:'88'},
                {label:'性别',prop:'f_Gender',width:'56',align:'center'}
            ],
            tableData:[],
            tableTotal:0,
            tablePageSize:50,
            tableCurrentPage:1,
            companyId:'',
            departmentId:'',
            departmentLoading:false
        }
    },
    computed:{
    },
    mounted () {
        this.init()
    },
    methods:{
        async init(){
            this.loadTableData()
            this.treeLoading = true
            await this.lr_loadCompanys()
            this.treeLoading = false
        },
        loadTableData(isNotFirst){
            if(!isNotFirst){
                this.tableCurrentPage = 1;
            }
            this.tableLoading = true;
            let queryData = {
                rows:this.tablePageSize,
                page:this.tableCurrentPage,
                sidx:'F_CreateDate DESC',
                keyword:this.searchWord,
                companyId:this.companyId,
                departmentId:this.departmentId,
                code:'xxx'
            }
            api.getPage(queryData).then(res=>{
                const data = this.$deepClone(res.data.data)
                data.rows.forEach(item => {
                    this.lr_loadDepartments(item.f_CompanyId)
                })
                this.tableData = data.rows
                this.tableTotal = data.records
                this.tableLoading = false
            }).catch(()=>{
                this.tableData = []
                this.tableLoading = false
            })
        },
        turnTablePage({rows}){
            this.tablePageSize = rows
            this.loadTableData(true)
        },
        handleNodeClick(data) {
            this.companyId = data.value
            this.departmentId = ''
            this.lr_loadDepartments(this.companyId)
            this.loadTableData()
        },
        handleChangeDept(){
            this.loadTableData()
        },
        hanleSearch(){
            this.loadTableData()
        },
        handleAdd(){

        }
    }

}
</script>
