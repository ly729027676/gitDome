export default url => {
    const getList = (params) => window.$axios({
        url: `${url}s`,
        method: 'get',
        params:params
    })
    
    const syncData = () => window.$axios({
        url: `${url}s`,
        method: 'post'
    })
    
    return {
        getList,
        syncData
    }
}