



export default url => {
    const getPage = (params) => window.$axios({
        url: `${url}/page`,
        method: 'get',
        params:params
    })
    
    const syncData = (id) => window.$axios({
        url: `${url}/${id}`,
        method: 'post'
    })
    
    return {
        getPage,
        syncData
    }
}