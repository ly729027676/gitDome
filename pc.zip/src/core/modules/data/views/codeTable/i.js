export default {
    name:'配置实体'
}