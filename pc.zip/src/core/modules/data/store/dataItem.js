import Vue from 'vue'
const api = window.$api.data.dataItem
export default {
    namespaced: true,
    state:{
        loadState:{},
        details:{},

        loadClassifysState:false,
        classifys:[]
    },
    actions:{
        async loadDetails({commit,state},{code,isCache}){
            if(!state.loadState[code] || !isCache){
                state.loadState[code] = true
                const res = await api.getDetailList(code)
                const data = res.data.data
                commit('SET_DETAILS', {code,data})
            }
        },
        async loadClassifys({commit,state},isCache = true){
            if(!state.loadClassifysState || !isCache){
                state.loadClassifysState = true
                const res =await api.getClassifyList()
                const data = res.data.data
                commit('SET_CLASSIFYS',data)
            }
        },
        async addClassify({dispatch},data){
            await api.addClassify(data)
            await dispatch('loadClassifys',false)
        },
        async updateClassify({dispatch},data){
            await api.updateClassify(data.f_ItemId,data)
            await dispatch('loadClassifys',false)
        },
        async removeClassify({commit},id){
            commit('REMOVE_CLASSIFY',id)
            await api.removeClassify(id)
        }
    },
    mutations:{
        SET_DETAILS: (state, payload) => {
            Vue.set(state.details,payload.code,payload.data)
        },
        SET_CLASSIFYS: (state, payload) => {
            state.classifys= payload
        },
        REMOVE_CLASSIFY: (state, id) => {
            state.classifys.splice(state.classifys.findIndex(t=>t.f_ItemId == id),1)
        },
    }
}

