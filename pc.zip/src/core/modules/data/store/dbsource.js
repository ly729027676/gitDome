import Vue from 'vue'
const api = window.$api.data.dbsource
const dataSource = {
    namespaced: true,
    state:{
        list:[],
        isUpdate:false,

        dataGroup:{},
        colNameGroup:{},
        dataByParamterGroup:{},

        updateStateList:{},
        updateStateListForCol:{},
        updateStateListForParam:{}
    },
    actions:{
        async loadList({commit,state},isCache){
            if(!state.isUpdate || !isCache){
                state.isUpdate = true
                const res = await api.getList()
                const data = res.data.data
                commit('SET_DATASOURCE_LIST', data)
            }
        },
        async loadDataCol({ commit,state},{code,isCache}){
            if(!state.updateStateListForCol[code] || !isCache){
                state.updateStateListForCol[code] = true
                const res = await api.getColNameList(code)
                const data = res.data.data
                commit('SET_DATASOURCE_COLNAMEGROUP', {code,data})
            }
        },
        async loadDataList({ commit,state},{code,isCache}){
            if(!state.updateStateList[code] || !isCache){
                state.updateStateList[code] = true
                const res = await api.getDataList(code)
                const data = res.data.data
                commit('SET_DATASOURCE_DATAGROUP', {code,data})
            }
        },
        async loadDataListByParamter({ commit,state},{code,param,isCache}){
            const codeParam = `${code}_${param}`
            if(!state.updateStateListForParam[codeParam] || !isCache){
                state.updateStateListForParam[codeParam] = true
                const res = await api.getDataListByParamter(code,param)
                const data = res.data.data
                commit('SET_DATASOURCE_DATABYPARAMTERGROUP', {codeParam,data})
            }
        }
    },
    mutations:{
        SET_DATASOURCE_LIST: (state, payload) => {
            state.list = payload;
        },
        SET_DATASOURCE_DATAGROUP: (state, payload) => {
            Vue.set(state.dataGroup,payload.code,payload.data)
        },
        SET_DATASOURCE_COLNAMEGROUP: (state, payload) => {
            Vue.set(state.colNameGroup,payload.code,payload.data)
        },
        SET_DATASOURCE_DATABYPARAMTERGROUP: (state, payload) => {
            Vue.set(state.dataByParamterGroup,payload.codeParam,payload.data)
        },
    }
}

export default dataSource;