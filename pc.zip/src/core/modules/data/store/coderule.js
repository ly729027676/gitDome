const api = window.$api.data.coderule
export default {
    namespaced: true,
    state:{
        list:[],
        isUpdate:false
    },
    actions:{
        async loadList({commit,state},isCache){
            if(!state.isUpdate || !isCache){
                state.isUpdate = true
                const res = await api.getList()
                commit('SET_LIST', res.data.data)
            }
        }
    },
    mutations:{
        SET_LIST: (state, payload) => {
            state.list= payload
        }
    }
}

