const api = window.$api.data.dblink
const db = {
    namespaced: true,
    state:{
        isUpdate:false,
        list:[]
    },
    actions:{
        async load({ commit,state},isCache){
            if(!state.isUpdate || !isCache){
                state.isUpdate = true
                const res =await api.getList()
                const data = res.data.data
                commit('SET_DB_LIST', data)
            }
            
        }
    },
    mutations:{
        SET_DB_LIST: (state, payload) => {
            state.list = payload
        }
    }
}

export default db;