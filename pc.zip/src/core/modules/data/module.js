export default {
    name: '数据模块',
    code: 'data',
    version: '1.0.0',
    description: '数据库管理，数据字典，省市数据，单号编码'
  }