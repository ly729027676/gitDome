export default url => {
    const crud = window.$crud(url)
    return {
        ...crud
    }
}