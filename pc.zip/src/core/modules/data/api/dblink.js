export default url => {
    const crud = window.$crud(url)

    const test = (params) => window.$axios({
        url:`${url}/test`,
        method: 'get',
        params:params
    })
    return {
        ...crud,
        test
    }
}