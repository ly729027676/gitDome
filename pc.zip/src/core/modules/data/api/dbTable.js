export default url => {
    const getList = (code) => window.$axios({
        url:`${url}s/${code}`,
        method: 'get'
    })
    const getColumns = (code,table) => window.$axios({
        url:`${url}/columns/${code}/${table}`,
        method: 'get'
    })
    const getDataPage = (params) => window.$axios({
        url:`${url}/data/page`,
        method: 'get',
        params:params
    })
    
    const existFiled = (params) => window.$axios({
        url:`${url}/exist/filed`,
        method: 'get',
        params:params
    })
    
    return {
        getColumns,
        getList,
        getDataPage,
        existFiled
    }
}