export default url => {
    const crud = window.$crud(url)
    crud.getList = (pid) => window.$axios({
        url: `${url}s/${pid}`,
        method: 'get'
    })

    return {
        ...crud,
    }
}

