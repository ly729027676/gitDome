export default url => {
    const crud = window.$crud(url)


    const getColNameList = (code) => window.$axios({
        url:`${url}/${code}/colnames`,
        method: 'get'
    })
    
    const getDataList = (code) => window.$axios({
        url:`${url}/${code}/list`,
        method: 'get'
    })

        
    const getDataListByParamter = (code,param) => window.$axios({
        url:`${url}/${code}/listbyparam`,
        method: 'get',
        params:{param}
    })
    
    const getDataPage = (code,pagination) => window.$axios({
        url:`${url}/${code}/page`,
        method: 'get',
        params:pagination
    })

    return {
        ...crud,
        getColNameList,
        getDataList,
        getDataListByParamter,
        getDataPage
    }
}