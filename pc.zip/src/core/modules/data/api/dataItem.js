

export default url => {
    const getDetailList = (code) => window.$axios({
        url: `${url}/details/${code}`,
        method: 'get'
    })
    
    const addDetail = (code,formData) => window.$axios({
        url: `${url}/detail/${code}`,
        method: 'post',
        data:formData
    })
    
    const updateDetail = (id,formData) => window.$axios({
        url: `${url}/detail/${id}`,
        method: 'put',
        data:formData
    })
    
    const removeDetail = (id) => window.$axios({
        url: `${url}/detail/${id}`,
        method: 'delete'
    })
    
    
    
    
    const getClassifyList = () => window.$axios({
        url: `${url}/classifys`,
        method: 'get'
    })
    
    const getClassify = (id) => window.$axios({
        url: `${url}/classify/${id}`,
        method: 'get'
    })
    
    
    const addClassify = (formData) => window.$axios({
        url: `${url}/classify`,
        method: 'post',
        data:formData
    })
    
    const updateClassify = (id,formData) => window.$axios({
        url: `${url}/classify/${id}`,
        method: 'put',
        data:formData
    })
    
    const removeClassify = (id) => window.$axios({
        url: `${url}/classify/${id}`,
        method: 'delete'
    })
    
    return {
        getDetailList,
        addDetail,
        updateDetail,
        removeDetail,
        getClassifyList,
        getClassify,
        addClassify,
        updateClassify,
        removeClassify
    }
}