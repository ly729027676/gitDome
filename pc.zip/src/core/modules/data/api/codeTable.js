export default url => {
    const crud = window.$crud(url,true)
    const importTable = (dbCode,data) => window.$axios({
        url:`${url}/importTable/${dbCode}`,
        method: 'post',
        data:data,
        meta: {
            hasProjectId:true
        }
    })

    const createOrUpdateTable = (tableid,dbcode,dbName) => window.$axios({
        url:`${url}/table/${tableid}/${dbcode}`,
        method: 'put',
        params:{dbName},
        meta: {
            hasProjectId:true
        }
    })

    crud.getList = (dbcode,tableNames) => window.$axios({
        url:`${url}s/${dbcode}`,
        method: 'get',
        params:{tableNames},
        meta: {
            hasProjectId:true
        }
    })

    return {
        ...crud,
        importTable,
        createOrUpdateTable
    }
}