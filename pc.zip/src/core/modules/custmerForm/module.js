export default {
    name: '自定义表单模块',
    code: 'custmerForm',
    version: '1.0.0',
    description: '自定义表单设计，功能开发'
  }