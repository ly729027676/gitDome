<template>
<div>
    <!--表单区域-->
    <l-dialog v-if="isDialog" 
        :title="$t(formTitle)"
        :visible.sync="formVisible"
        :height="dialogHeight"
        :width="dialogWidth"

        :hasBtns="!isDetails"
                
        @ok="handleSave"
        @closed="handleCloseForm"
        @opened="handleOpenedForm">
        <l-form-viewer 
            ref="form"
            :formInfo="formInfo" 
            :isAuth="true"
            :isRead="isDetails"
            ></l-form-viewer>
    </l-dialog>
    <l-drawer v-else
        :title="$t(formTitle)"
        :visible.sync="formVisible"
        :width="drawerWidth"
        :showOk="!isDetails"
        :showClose="!isDetails"

        @ok="handleSave"
        @closed="handleCloseForm"
        @opened="handleOpenedForm"
        >
        <l-form-viewer 
            ref="form"
            :formInfo="formInfo"
            :isAuth="true"
            :isRead="isDetails"
            ></l-form-viewer>
    </l-drawer>

    <l-drawer 
        :title="$t('分类管理')"
        :visible.sync="classifysVisible"
        :showOk="false"
        :showClose="false"
        size="800px"
        >
        <l-dataitem-index :classifyCode="classifyCode"></l-dataitem-index>
    </l-drawer>

    <create-wf ref="wfform" :code="wfcode" @refresh="this.loadTableData(true)" :isDraftBtn="false" :title="name" :visible.sync="wfVisible" ></create-wf>

</div>
</template>

<script>
import CreateWf from '../../../workflow/views/create/create.vue'
export default {
    components:{
        CreateWf
    },
    props:{
        isDialog:Boolean,
        
        dialogHeight:Number,
        dialogWidth:Number,
        

        handleSave:Function,
        handleOpenedForm:Function,
        loadTableData:Function,

        formInfo:{
            type:Object,
            default:()=>{}
        },

        classifyCode:String,

        wfcode:String,
        name:String,


    },
    data () {
        return {
            formVisible:false,
            classifysVisible:false,
            wfVisible:false,
            formTitle:'',
            isDetails:false,
        };
    },
    methods:{
        // 打开表单
        openForm(title,isDetails = false){
            this.formTitle = title
            this.isDetails = isDetails
            this.formVisible = true
        },
        closeForm(){
            this.formVisible = false
        },
        handleCloseForm(){
            this.$refs.form.resetFormData()
        },
        validateForm(){
            return this.$refs.form.validateForm()
        },
        getForm(){
            return this.$refs.form.getForm()
        },
        init(data){
            return this.$refs.form.init(data)
        },
        getDiffFormData(){
            return this.$refs.form.getDiffFormData()
        },
        afterSaveEvent(res,formEdit){
            return this.$refs.form.afterSaveEvent(res,formEdit)
        },
        // 打开分类管理
        openClassify(){
            this.classifysVisible = true
        },
        // 打开流程
        openWf(){
            this.wfVisible = true
        }

    }
}
</script>
