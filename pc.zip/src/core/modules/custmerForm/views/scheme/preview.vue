<template>
    <div class="l-rblock"
        v-loading="loading"
        :element-loading-text="$t('加载数据中...')"
    >
        <l-form-viewer 
            ref="formViewer"
            :formInfo="formInfo"
            :isRead="isRead"
            ></l-form-viewer>
    </div>
</template>
<script>
export default {
    name:'form-preview',
    props:{
        loading:{
            type:Boolean,
            default:false
        }
    },
    data(){
        return {
            formInfo:{
                size:'mini',
                labelPosition:'right',
                labelWidth:80,
                gutter:0,
                tabList:[{ components:[],text:'主表信息'}]
            },
            isRead:false
        };
    },
    computed:{
    },
    methods:{
        resetForm(){
            this.$refs.formViewer.resetFormData() 
        },
        setForm(data){
            const scheme = JSON.parse(data.f_Scheme)
            if(scheme.formType == 1){
                this.isRead = true
            }
            else{
                this.isRead = false
            }
            this.formInfo = scheme.formInfo
            
            this.$nextTick(async ()=>{
                await this.$refs.formViewer.init()
            })
        }
    }
}
</script>