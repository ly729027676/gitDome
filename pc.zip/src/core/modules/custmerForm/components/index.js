let components = []
const requireComponent = require.context('./', true, /index\.vue$/)
requireComponent.keys().map(fileName => {
  components.push({
    name: `l-${fileName.split('/')[1]}`,
    component: requireComponent(fileName).default
  })
})
export default components