const requireComponent = require.context('./', true, /\.*\.js$/)
const modules = {}
requireComponent.keys().map(fileName => {
    const name = fileName.replace('./', '').replace('.js', '')
    if(name != 'index'){
        const func = requireComponent(fileName).default
        modules[`${name}`] = func
    }
})
export default {
    namespaced: true,
    modules
}