import Vue from 'vue'
const api = window.$api.custmerForm.scheme
export default {
    namespaced: true,
    state:{
        group:{},
        updateState:{}
    },
    actions:{
        async load({ commit,state},{id,isCache}){
            if(!state.updateState[id] || !isCache){
                state.updateState[id] = true
                const res =await api.getHistory()
                const data = res.data.data
                commit('SET_FORM_SCHEME', {id,data})
            }
            
        }
    },
    mutations:{
        SET_FORM_SCHEME: (state, payload) => {
            Vue.set(state.group,payload.id,payload.data)
        }
    }
}