export default url => {
    const crud = window.$crud(url)

    const updateState = (id,state) => window.$axios({
        url: `${url}/state/${id}/${state}`,
        method: 'put'
    })

    const updateState2 = (id,state) => window.$axios({
        url: `${url}/state2/${id}/${state}`,
        method: 'put'
    })
    
    const getScheme = (code) => window.$axios({
        url: `${url}/scheme/${code}`,
        method: 'get'
    })



    const removeByModuleId = (id) => window.$axios({
        url: `${url}/bymoduleId/${id}`,
        method: 'delete'
    })

    const getByModuleId = (id) => window.$axios({
        url: `${url}/bymoduleId/${id}`,
        method: 'get'
    })

    
    return {
        ...crud,
        getScheme,
        updateState,
        updateState2,
        removeByModuleId,
        getByModuleId
    }
}