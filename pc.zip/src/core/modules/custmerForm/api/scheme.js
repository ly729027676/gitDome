export default url => {
    const crud = window.$crud(url)

    const getInfo = (id) => window.$axios({
        url: `${url}/info/${id}`,
        method: 'get'
    })


    const updateState = (id,state) => window.$axios({
        url: `${url}/state/${id}`,
        method: 'put',
        params:{state:state}
    })


    const getHistoryPage = (id,qureyData) => window.$axios({
        url: `${url}/history/page/${id}`,
        method: 'get',
        params:qureyData
    })
    const getHistoryList = (id,qureyData) => window.$axios({
        url: `${url}/historys/${id}`,
        method: 'get',
        params:qureyData
    })

    const getHistory = (id) => window.$axios({
        url: `${url}/history/${id}`,
        method: 'get'
    })

    const updateHistory = (id,schemeId) => window.$axios({
        url: `${url}/history/${id}`,
        method: 'put',
        params:{schemeId:schemeId}
    })


    const getDataPage = (mid,id,data) => window.$axios({
        url: `custmerform/data/page/${mid}/${id}`,
        method: 'post',
        data:data
    })
    const getDataList = (mid,id,data) => window.$axios({
        url: `custmerform/datas/${mid}/${id}`,
        method: 'post',
        data:data
    })

    const getData = (id,params) => window.$axios({
        url: `custmerform/data/${id}`,
        method: 'get',
        params:params
    })

    const getViewData = (id,params) => window.$axios({
        url: `custmerform/viewdata/${id}`,
        method: 'get',
        params:params
    })
    

    const saveData = (data) => window.$axios({
        url: `custmerform/data`,
        method: 'post',
        data:data
    })

    const removeData = (id,params) => window.$axios({
        url: `custmerform/data/${id}`,
        method: 'delete',
        params:params
    })

    const geColnames = (dbCode,sql) => window.$axios({
        url: `custmerform/sql/colnames/${dbCode}`,
        method: 'post',
        data:{sql}
    })


    return {
        ...crud,

        getInfo,
        updateState,
        
        getHistoryPage,
        getHistoryList,
        getHistory,
        updateHistory,
        
        saveData,
        getDataPage,
        getData,
        getViewData,
        getDataList,
        removeData,

        geColnames
    }
}

