export default {
    name: 'EXCEL模块',
    code: 'excel',
    version: '1.0.0',
    description: '配置EXCEL导出导入'
}