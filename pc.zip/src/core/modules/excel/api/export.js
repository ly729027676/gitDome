export default url => {
    const crud = window.$crud(url)
    crud.getList = (id) => window.$axios({
        url: `${url}s/${id}`,
        method: 'get',
    })

    const down = (data) => window.$axios({
        url: `${url}/file`,
        method: 'post',
        data
    })
    return {
        ...crud,
        down
    }
}