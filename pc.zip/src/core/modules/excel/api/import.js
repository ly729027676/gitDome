export default url => {
    const crud = window.$crud(url)
    crud.getList = (id) => window.$axios({
        url: `${url}s/${id}`,
        method: 'get',
    })
    const updateState = (id,state) => window.$axios({
        url: `${url}/state/${id}/${state}`,
        method: 'put'
    })
    const uploadEx = (classname,data) => window.$axios({
        url:`${url}/file/${classname}`,
        method: 'post',
        data:data
    })
    
    const upload = (templateId,data) => window.$axios({
        url:`${url}/${templateId}`,
        method: 'post',
        data:data
    })
    return {
        ...crud,
        updateState,
        uploadEx,
        upload
    }
}

