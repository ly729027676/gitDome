<template>
    <l-dialog
        title="Excel文件导入"

        :visible.sync="midVisible"
        :hasBtns="false"

        width="424px"
        @close="closeDialog"
        @opened="handleOpened"
        @ok="okDialog"
        >
        <div class="l-rblock" style="padding:8px 32px 0 32px;overflow: auto;" >
            <el-upload
                drag
                action
                :http-request="myChunkedUpload"
                multiple
                ref="myupload"
                accept=".xls,.xlsx"

                :data="param"
                >
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
            </el-upload>
        </div>
    </l-dialog>
</template>

<script>
import chunkedUpload from '../../../../util/chunkedUpload'
export default {
    name:'l-excel-import',
    props: {
        classname:String,
        visible:{
            type:Boolean,
            default:false
        }
    },
    data () {
        return {
            folderId:''
        };
    },
    created () {
        this.folderId = this.$uuid();
    },
    mounted () {
    },
    computed:{
        midVisible:{
            get(){
                return this.visible;
            },
            set(val){
                this.$emit('update:visible',val);
            }
        },
        param(){
            return {
                folderId: this.folderId
            };
        },
    },
    methods:{
        closeDialog() {
            this.$refs.myupload.clearFiles
        },
        handleOpened(){
        },
        okDialog(){
            this.midVisible =false;
        },
        myChunkedUpload(option){
            chunkedUpload(option,(data)=>{
                const api = window.$api.excel.import
                return api.uploadEx(this.classname,data);
            })
        }
    }
}
</script>
