export default {
    name: '工作流模块',
    code: 'workflow',
    version: '1.0.0',
    description: '流程设计，流程发起，流程处理，流程监控'
  }