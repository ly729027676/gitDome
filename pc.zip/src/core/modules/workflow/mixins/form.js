import Vue from 'vue'
const apiForm = window.$api.custmerForm.scheme

export default function () {
    return {
        data(){
            return {
                formSchemeLoding:false,

                currentNode:{},
                processId:'',
                
                formAuthFieldsMap:{},
                formRequiredMap:{},

                
                isUpdate:false,
                showForm:false,
                
                formType:'1',         // 1.自定义表单 2.系统表单
                formRelationId:'',    // 表单关联字段
                formRelationKey:'',   // 具体关联的表字段名
                formSchemeId:'',
                formInfo:null,
                sysFormComponent:'',

                hasWfForm:false
            }
        },
        methods:{
            async loadForm(currentNode,processId,params,isLoadFormData,readonly){    // 加载表单信息
                if(!currentNode){
                    return
                }
                this.showForm = false
                this.formSchemeLoding = true

                this.currentNode = currentNode
                const {formType,formVerison,formRelationId,formUrl,authFields} = currentNode

                this.formRelationId = formRelationId
                this.formType = formType
                
                this.processId = processId
                this.params = params

                this.hasWfForm = true

                

                if(formType == '1'){
                    // 自定义表单
                    const {f_Scheme} = await this.$awaitWraper(apiForm.getHistory(formVerison))
                    const formScheme = JSON.parse(f_Scheme)

                    this.formSchemeId = formVerison

                    const formAuthFieldsMap = {}
                    authFields.forEach(item=>{
                        if(readonly) item.isEdit = false
                        formAuthFieldsMap[item.prop] = item
                    })

                    const formInfo = formScheme.formInfo
                    formInfo.tabList.forEach(tab=>{    
                        tab.components.forEach(component=>{
                            if(!['gridtable'].includes(component.type)){
                                if(component.display){
                                    if(formAuthFieldsMap[component.prop]){
                                        component.required = formAuthFieldsMap[component.prop].required
                                    }
                                }
                            }
                            else{
                                component.children.forEach((cell)=>{
                                    if(formAuthFieldsMap[cell.prop]){
                                        cell.required = formAuthFieldsMap[cell.prop].required
                                    }
                                })
                            }

                            if(component.prop == this.formRelationId){
                                this.formRelationKey = component.field
                            }
                        })
                    })

                    this.formAuthFieldsMap = formAuthFieldsMap

                    this.formInfo = formInfo
                }
                else{
                    // 系统表单
                    const WFFormComponent = Vue.component(formUrl)
                    if(WFFormComponent == undefined){
                        this.hasWfForm = false
                        this.$message({
                            type: 'warning',
                            message: '无法加载系统表单，请查看流程配置是否正确!'
                        })
                    }
                    else{
                        this.sysFormComponent = formUrl

                        const formAuthFieldsMap = {}
                        authFields.forEach(item=>{

                            const propList = item.field.split('|')
                            let code = '3'
                            if(item.isLook || item.isEdit){
                                code = item.isEdit?'2':'1'
                            }

                            if(propList.length > 1){
                                // 表格
                                formAuthFieldsMap[propList[0].toLowerCase()] = formAuthFieldsMap[propList[0].toLowerCase()] || {}
                                formAuthFieldsMap[propList[0].toLowerCase()][propList[1].toLowerCase()] = code

                                if(item.isEdit){
                                    this.formRequiredMap[propList[0].toLowerCase()] = this.formRequiredMap[propList[0].toLowerCase()] || {}
                                    this.formRequiredMap[propList[0].toLowerCase()][propList[1].toLowerCase()] = item.required
                                }
                            }
                            else {
                                // 表单字段
                                formAuthFieldsMap[propList[0].toLowerCase()] = code
                                if(item.isEdit){
                                    this.formRequiredMap[propList[0].toLowerCase()] = item.required
                                }
                            }
                        })

                        this.formAuthFieldsMap = formAuthFieldsMap
                    }                    
                }


                this.showForm = true

                // 加载表单数据
                if(isLoadFormData && this.hasWfForm){
                    if(formType == '1'){
                        const data = await this.$awaitWraper(apiForm.getData(this.formSchemeId,{key:this.formRelationKey,keyValue:this.processId}))
                        if(data){
                            this.isUpdate = true
                            this.$nextTick(()=>{
                                this.$refs.wfForm.init(data)
                            })    
                        }
                        else{
                            this.isUpdate = false
                            this.$nextTick(()=>{
                                this.$refs.wfForm.init()
                            })
                        }
                        
                        this.formSchemeLoding = false
                    }
                    else{
                        this.loadSystemFormData()
                    }
                }
                else {
                    this.isUpdate = false
                    this.$nextTick(()=>{
                        this.$refs.wfForm.init()
                    })    
                    this.formSchemeLoding = false
                }
            },

            loadSystemFormData(){// 加载系统表单数据
                if(this.$refs.wfForm){
                    this.$nextTick(async ()=>{
                        this.isUpdate = await this.$refs.wfForm.loadFormData({keyValue:this.processId,params:this.params,node:this.currentNode})
                        this.formSchemeLoding = false         
                    })
                }
                else{
                    setTimeout(async ()=>{
                        this.loadSystemFormData()    
                    },100)
                }
            },

            resetWfForm(){
                this.isUpdate = false
                this.showForm = false
                this.hasWfForm = false
            },

            validateWfForm(){
                if(!this.hasWfForm){
                    return true
                }
                return this.$refs.wfForm.validateForm()
            },

            getWfForm(){// 获取表单信息
                const formData = this.$refs.wfForm.getForm()
                if(this.$validatenull(this.formRelationId)){
                    this.$message({
                        type: 'error',
                        message: this.$t('请设置表单和流程关联字段!')
                    })
                    return null
                }
                formData[this.formRelationId] = this.processId

                const postData = {
                    schemeId:this.formSchemeId,
                    isUpdate:this.isUpdate,
                    pkey:this.formRelationId,
                    pkeyValue:this.processId,
                    data:JSON.stringify(formData)
                }
                return postData
            },

            // 保存表单数据
            async saveWfForm(code){ 
                if(!this.hasWfForm){
                    return true
                }

                if(this.formType == '1'){// 自定义表单
                    const data = this.getWfForm()
                    if(data != null){
                        await apiForm.saveData(data)
                        this.isUpdate = true
                    }
                    else{
                        return false
                    }
                }
                else{
                    return this.$refs.wfForm.saveForm({keyValue:this.processId,isEdit:this.isUpdate,code,node:this.currentNode})
                }

                return true
            }
        }
    }
}