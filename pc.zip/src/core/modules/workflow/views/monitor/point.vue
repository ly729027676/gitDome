<template>
    <div class="l-from-body" style="padding:16px;" >
        <el-form :model="formData" size="mini"  ref="form" label-position="top">
            <el-col :span="24" v-for="(item,index) in nodeList" :key="index" >
                <el-form-item class="el-input--mini" :label="`${item.name}【当前】`" :prop="item.unitId">
                        <div class="el-input__inner" >
                            <l-user v-for="(userId,index2) in item.userIds"  :key="index2" :value="userId" ></l-user>
                        </div>
                     
                </el-form-item>
                <el-form-item :label="`${item.name}【设置】`" :prop="item.unitId">
                    <l-user-select multiple v-model="formData[item.unitId]" ></l-user-select>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            formData:{},
            nodeList:[]
        }
    },
    created () {
    },
    computed:{
    },
    methods:{
        resetForm(){
            this.formData = {}
        },
        setForm(nodeList){
            this.nodeList = nodeList
        },
        getForm(){
            return this.$deepClone(this.formData)
        }
    }
}
</script>