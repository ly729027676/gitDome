<template>
<l-drawer
    :title="`${$t('查看节点表单')}【${title}】`"
    :visible.sync="midVisible"
    :showOk="false"
    :showClose="false"
    size="800px"

    @closed="handleClosed"
    @opened="handleOpened"

    ref="formDialog"
    >
    <template v-if="showForm" >
        <l-form-viewer 
            v-if="formType == '1'"
            :formInfo="formInfo"
            :isWfForm="true"
            :authFieldsMap="formAuthFieldsMap"
            ref="wfForm"
        ></l-form-viewer>
        <component 
            ref="wfForm" 
            v-else 
            :requiredMap="formRequiredMap" 
            :authFieldsMap="formAuthFieldsMap" 
            :isWfForm="true" 
            :is="sysFormComponent">
        </component>
    </template>           
</l-drawer>
</template>

<script>
import mixin from '../../mixins/form'
export default {
    mixins:[mixin()],
    data () {
        return {
            currentNode:{},
            processId:'',
            midVisible:false,
            title:''
        }
    },
    methods:{
        open(title,currentNode,processId){
            this.title = title
            this.currentNode = currentNode
            this.processId = processId
            this.midVisible = true
        },
        close(){
            this.midVisible = false
        },
        async handleOpened(showLoading,hideLoading){
            showLoading('加载表单信息...')
            this.loadForm(this.currentNode,this.processId,{},true,true)
            hideLoading()
        },
        handleClosed(){            
            this.resetWfForm &&  this.resetWfForm()
        }
    }
}
</script>