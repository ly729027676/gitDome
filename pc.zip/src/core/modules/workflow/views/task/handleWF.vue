<template>
    <div>
        <audit-form 
            v-if="['look','audit','create'].includes(type)"
            ref="form" 
            :type="type == 'look'?'look':'audit'" 
            :isCreateAgain="isCreateAgain"
            :params="{taskId}" 
            :isLoadFormData="true" 
            :isToken="true"
            :title="title" 
            :visible.sync="visible"

            @refresh="refresh()"
        ></audit-form>
        <look-form
            v-else
            ref="form" 
            type="lookmy" 
            :params="{processId}" 
            :isLoadFormData="true" 
            :title="title" 
            :visible.sync="visible"
            >
        </look-form>
    </div>
</template>
<script>
import AuditForm from './process/audit'
import LookForm from './process/look.vue'
export default {
    components: {
        AuditForm,
        LookForm
    },
    data () {
        return {
            type:'',
            callback:null,
            isCreateAgain:false,
            taskId:'',
            processId:'',
            visible:false,
            title:''
        }
    },
    computed:{
    },
    mounted () {
    },
    methods:{
        open(item,callback){
            // 审核 查阅 提交（子流程） 重新提交
            // Token
            // 获取任务数据

            // 提醒
            // ProcessId
            this.callback = callback
            this.title = item.f_Content

            this.isCreateAgain = false
            if(item.f_Content.indexOf('【审核】') != -1){
                this.type = 'audit'
            }
            else if(item.f_Content.indexOf('【查阅】') != -1){
                this.type = 'look'
            }
            else  if(item.f_Content.indexOf('【重新提交】') != -1){
                this.type = 'create'
                this.isCreateAgain = true
            }
            else{
                this.type = 'lookmy'
                this.processId = item.f_ContentId
            }

            if(['look','audit','create'].includes(this.type)){
                // 加载流程数据
                this.taskId = item.f_ContentId
            }
            this.$nextTick(()=>{
                this.visible = true
            })
            
        },
        refresh(){
            this.callback && this.callback()
        }
    }
}
</script>