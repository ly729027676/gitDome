export default {
    wfName:'handleWF',
    name:'handleWF'
}