<template>
    <div class="l-from-body" >
        <el-form :model="formData" size="mini"  ref="form" label-width="64px" >
            <el-col :span="24">
                <el-form-item label="驳回到" prop="nodeId">
                    <l-select labelKey="name" valueKey="id" v-model="formData.nodeId" :options="nodeList" ></l-select>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    props:{
        nodeList:{
            type:Array,
            default:()=>[]
        }
    },
    data(){
        return {
            formData:{
                nodeId:''
            },
            rules:{
                nodeId: [
                    { required: true, message: '请选择流转节点' },
                ]
            },
        }
    },
    created () {
    },
    computed:{
    },
    methods:{
        resetForm(){
            this.$refs.form && this.$refs.form.resetFields()
        },
        validateForm(){
            return this.$refs.form.validate()
        },
        getForm(){
            return this.formData.nodeId
        }
    }
}
</script>