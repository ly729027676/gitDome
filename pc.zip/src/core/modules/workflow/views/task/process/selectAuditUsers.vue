<template>
    <div class="l-from-body" >
        <el-form :model="formData" size="mini"  ref="form" label-width="108px" >
            <el-col :span="24" v-for="(item,index) in nodeList" :key="index" >
                <el-form-item :label="item.name" :prop="item.id">
                    <l-select multiple v-model="formData[item.id]" :options="item.options" ></l-select>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    props:{
        nodeList:{
            type:Array,
            default:()=>[]
        }
    },
    data(){
        return {
            formData:{
            }
        }
    },
    created () {
    },
    computed:{
    },
    methods:{
        resetForm(){
            this.formData = {}
        },
        getForm(){
            return this.$deepClone(this.formData)
        }
    }
}
</script>