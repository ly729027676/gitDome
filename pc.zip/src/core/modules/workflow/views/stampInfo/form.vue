<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="88px" >
            <el-col :span="12">
                <el-form-item label="名称" prop="f_StampName">
                    <el-input v-model="formData.f_StampName"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="分类" prop="f_StampType">
                    <l-select v-model="formData.f_StampType" :options="lr_dataItemOptions(lr_dataItem['StampType'])">
                    </l-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="所属人员" prop="f_UserIds">
                    <l-user-select 
                        v-model="formData.f_UserIds"
                        :multiple="true"
                        >
                    </l-user-select>
                </el-form-item>
            </el-col>
            
            <el-col :span="12">
                <el-form-item label="填写密码" prop="f_IsNotPassword" >
                    <el-switch
                    :active-value="1"
                    :inactive-value="0"
                    v-model="formData.f_IsNotPassword"
                    >
                    </el-switch>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="状态" prop="f_EnabledMark" >
                    <el-switch
                    :active-value="1"
                    :inactive-value="0"
                    v-model="formData.f_EnabledMark"
                    >
                    </el-switch>
                </el-form-item>
            </el-col>
            <el-col :span="12" v-if="formData.f_IsNotPassword == 1">
                <el-form-item label="密码" prop="f_Password">
                    <el-input type="password" v-model="formData.f_Password"></el-input>
                </el-form-item>
            </el-col>
          
            <el-col :span="24">
                <el-form-item label="签章" prop="f_ImgFile"> 
                    <l-upload
                        v-model="formData.f_ImgFile"
                        listType="picture-card"
                        :chunkedUpload="lr_chunkedUpload"
                        :getFileList="lr_getFileList"
                        :deleteFile="lr_deleteFile"
                    >
                    </l-upload>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="描述" prop="f_Description">
                    <el-input type="textarea" v-model="formData.f_Description"></el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    props:{

    },
    data(){
        return {
            formData:{
                f_StampName:'',
                f_StampType: '',
                f_IsNotPassword: 0,
                f_Password:'',
                f_ImgFile:'',
                f_UserIds:'',    // 关联用户
                f_EnabledMark:1,
                f_Description:'' // 备注
            },
            rules: {
                f_StampName: [
                    { required: true, message: '请输入名称',trigger: 'blur' }
                ],
                f_StampType: [
                    { required: true, message: '请选择分类',trigger: 'change' }
                ],
                f_Password: [
                    { required: true, message: '请填写密码',trigger: 'blur' }
                ],
                f_ImgFile:[
                    { required: true, message: '请上传文件',trigger: 'blur'}
                ],
                f_UserIds:[
                    { required: true, message: '请选择人员',trigger: 'blur' }
                ],
            },
            password:''
        };
    },
    watch:{
        'formData.f_UserIds'(newval,old){
            console.log(newval,old,'watch')
        }
    },
    computed:{
    },
    created(){
    },
    methods:{
        // 重置表单
        resetForm(){
            this.formData.f_Password = ''
            this.password = ''
            this.$refs.form && this.$refs.form.resetFields()
        },
        // 校验表单
        validateForm(){
            return new Promise((resolve) => {
                this.$refs.form.validate((valid) => {
                    resolve(valid)
                })
            })
        },
        // 设置表单数据
        setForm(data){
            this.formData = this.$deepClone(data)
            console.log(this.formData)
            this.password = this.formData.f_Password
        },
        // 获取表单数据
        getForm(){
            let data = this.$deepClone(this.formData)
            if(data.f_IsNotPassword == 0){
                data.f_Password = ''
            }
            else if(data.f_Password != this.password){
                data.f_Password = this.$md5(data.f_Password)
            }
            return data
        }
    }
}
</script>