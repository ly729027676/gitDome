<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="120px" >
            <el-col :span="24">
                <el-form-item label="数据库" prop="dbCode">
                    <el-select v-model="formData.dbCode" placeholder="请选择">
                        <el-option-group
                        v-for="group in lr_dblinkTree"
                        :key="group.id"
                        :label="group.label">
                        <el-option
                            v-for="item in group.children"
                            :key="item.id"
                            :label="item.label"
                            :value="item.id">
                        </el-option>
                        </el-option-group>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="数据表" prop="table">
                    <l-dbtable-select 
                    @change="handleTableChange"
                    :dbCode="formData.dbCode" 
                    v-model="formData.table"></l-dbtable-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="关联流程字段" prop="rfield">
                    <l-select :options="columns" valueKey="name" labelKey="name" v-model="formData.rfield" >
                    </l-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="审核人字段" prop="auditorField">
                    <l-select :options="columns"  valueKey="name" labelKey="name" v-model="formData.auditorField" >
                    </l-select>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    name:'auditor-sql-form',
    props:{
    },
    data(){
        return {
            formData:{
                dbCode:'',
                table:'',
                rfield:'',
                auditorField:'',
                type:'6'
            },
            rules: {
                dbCode: [
                    { required: true, message: '请选择数据库' }
                ],
                table: [
                    { required: true, message: '请选择数据表' }
                ],
                rfield: [
                    { required: true, message: '请选择关联字段' }
                ],
                auditorField: [
                    { required: true, message: '请选择审核人字段' }
                ]
            },
            columns:[],
        };
    },
    computed:{
    },
    created () {
    },
    methods:{
        handleTableChange(table){
            this.columns = table.columns;
        },
        resetForm(){
            this.columns = [];
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        setForm(data){
            this.formData = this.$deepClone(data);
        },
        getForm(){
            let formData = this.$deepClone(this.formData);
            return formData;
        }
    }
}
</script>