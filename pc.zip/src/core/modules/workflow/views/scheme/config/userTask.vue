<!-- 开始节点配置 -->
<template>
 <el-form
        label-width="96px"
        label-position="left"
        size="mini"
    >
    <el-collapse v-model="activeNames" accordion>
        <el-collapse-item :title="$t('基础配置')" name="1">
            <div style="padding:0 16px;">
                <el-form-item label="节点标识">
                <el-input v-model="node.id" readonly ></el-input>
                </el-form-item>
                <el-form-item label="继承表单">
                    <el-switch :disabled="disabled" v-model="node.isInherit">
                    </el-switch>
                </el-form-item>
                <el-form-item label="允许加签">
                    <el-switch :disabled="disabled" v-model="node.isAddSign">
                    </el-switch>
                </el-form-item>
                <el-form-item label="允许转移">
                    <el-switch :disabled="disabled" v-model="node.isTransfer">
                    </el-switch>
                </el-form-item>
                <el-form-item label="允许批量审核">
                    <el-switch :disabled="disabled" v-model="node.isBatchAudit">
                    </el-switch>
                </el-form-item>
                <el-form-item label="自动同意规则">
                    <l-select multiple :disabled="disabled" v-model="node.autoAgree" :options="atuoAgreeOptions" >
                    </l-select>
                </el-form-item>
                <el-form-item label="无对应处理人">
                    <l-select :disabled="disabled" v-model="node.noAuditor" :options="noAuditorOptions" >
                    </l-select>
                </el-form-item>
                <el-form-item label="驳回策略">
                    <l-radio :disabled="disabled" v-model="node.rejectType" :options="[{value:'1',label:'驳回节点固定'},{value:'2',label:'能驳回到任何执行过节点'}]" >
                    </l-radio>
                </el-form-item>

                <el-form-item label="通知策略">
                    <l-checkbox :disabled="disabled" v-model="node.messageType" :options="[{value:'1',label:'短信'},{value:'2',label:'邮箱'},{value:'3',label:'微信'},{value:'4',label:'站内消息'}]" >
                    </l-checkbox>
                </el-form-item>
            </div>
            
        </el-collapse-item>
        <el-collapse-item :title="$t('审核人员设置')" name="2">
            <el-button-group style="padding:0 0 8px 8px" v-if="!disabled" >
                <el-button size="mini" @click="handlePostClick(false)" >{{$t('岗位')}}</el-button>
                <el-button size="mini" @click="handleRoleClick(false)" >{{$t('角色')}}</el-button>
                <el-button size="mini" @click="handleUserClick(false)" >{{$t('用户')}}</el-button>
                <el-button size="mini" @click="handleLevelClick(false)">{{$t('上下级')}}</el-button>
                <el-button size="mini" @click="handleNodeAuditorClick(false)">{{$t('节点执行人')}}</el-button>
                <el-button size="mini" @click="handleAuditorSqlClick(false)" >{{$t('表字段')}}</el-button>
            </el-button-group>
            <l-table height="notset" :isShowNum="false" :columns="userColumns" :dataSource="node.auditUsers" >
                <template v-slot:type="scope" >
                    {{typeFormat(scope.row.type)}}
                </template>
                <template  v-slot:condition="scope" >
                    <l-select :disabled="disabled" size="mini" v-if="scope.row.type == '2'" :options="conditionOptions" v-model="scope.row.condition" ></l-select>
                </template>
                <l-table-btns v-if="!disabled" :isFixed="false"  :btns="tableBtns" @click="handleTableBtnClick" ></l-table-btns>
            </l-table>
        </el-collapse-item>
         <el-collapse-item :title="$t('传阅人员设置')" name="3">
             <el-button-group style="padding:0 0 8px 8px" v-if="!disabled" >
                <el-button size="mini" @click="handlePostClick(true)" >{{$t('岗位')}}</el-button>
                <el-button size="mini" @click="handleRoleClick(true)">{{$t('角色')}}</el-button>
                <el-button size="mini" @click="handleUserClick(true)">{{$t('用户')}}</el-button>
                <el-button size="mini" @click="handleLevelClick(true)">{{$t('上下级')}}</el-button>
                <el-button size="mini" @click="handleNodeAuditorClick(true)">{{$t('节点执行人')}}</el-button>
                <el-button size="mini" @click="handleAuditorSqlClick(true)">{{$t('表字段')}}</el-button>
            </el-button-group>
            <l-table height="notset" :isShowNum="false" :columns="userColumns" :dataSource="node.lookUsers" >
                <template v-slot:type="scope" >
                    {{typeFormat(scope.row.type)}}
                </template>
                <template  v-slot:condition="scope" >
                    <l-select :disabled="disabled" size="mini" v-if="scope.row.type == '2'" :options="conditionOptions" v-model="scope.row.condition" ></l-select>
                </template>
                <l-table-btns v-if="!disabled" :isFixed="false"  :btns="tableBtns" @click="handleTableBtnClick2" ></l-table-btns>
            </l-table>
        </el-collapse-item>
        <el-collapse-item v-if="!node.isInherit" :title="$t('表单设置')" name="4">
            <div style="padding:0 16px;">
                <div style="text-align: center;margin-bottom:16px;" >
                    <el-radio-group :disabled="disabled" v-model="node.formType" size="mini" @change="handleFormTypeChange">
                        <el-radio-button label="1">自定义表单</el-radio-button>
                        <el-radio-button label="2">系统表单</el-radio-button>
                    </el-radio-group>
                </div>
                <div v-show="node.formType === '1'" >
                <el-form-item label-width="0px">
                    <l-custmerform-select
                        v-model="node.formCode"
                        @change="custmerformChange"

                        :disabled="disabled"
                        >
                    </l-custmerform-select>
                </el-form-item>
                <el-form-item label-width="0px">
                    <l-select
                        v-model="node.formVerison"
                        :disabled="disabled"
                        :options="formVerisons"
                        @change="custmerformVerisonChange"

                        placeholder="请选择表单版本"
                        >
                    </l-select>
                </el-form-item>
                <el-form-item label-width="0px">
                    <l-select
                        v-model="node.formRelationId"
                        :disabled="disabled"
                        :options="node.formRelations"
                        
                        placeholder="请选择流程关联字段"
                        >
                    </l-select>
                </el-form-item>

                </div>
                <div v-show="node.formType === '2'" >
                <el-form-item label-width="0px">
                    <el-input
                        v-model="node.formUrl"
                        placeholder="请输入PC端表单地址"

                        :readonly="disabled"
                        >
                    </el-input>
                </el-form-item>
                <el-form-item label-width="0px">
                    <el-input
                        v-model="node.formAppUrl"
                        placeholder="请输入APP端表单地址"

                        :readonly="disabled"
                        >
                    </el-input>
                </el-form-item>
                </div>
                <el-divider>表单字段权限</el-divider>
                <template v-if="node.formType === '1'">
                <l-table height="notset" :isShowNum="false" :columns="columns" :dataSource="node.authFields" ref="authField" >
                    <template v-slot:required="scope" >
                        <el-switch
                            v-model="scope.row.required"
                            :disabled="disabled || scope.row.type == 'grid'"
                            >
                        </el-switch>
                    </template>
                    <template v-slot:isEdit="scope" >
                        <el-switch
                            v-model="scope.row.isEdit"
                            :disabled="disabled || scope.row.type == 'gridrequired'"
                            >
                        </el-switch>
                    </template>
                    <template v-slot:isLook="scope" >
                        <el-switch
                            v-model="scope.row.isLook"
                            :disabled="disabled || scope.row.type == 'grid' || scope.row.type == 'gridrequired'"
                            >
                        </el-switch>
                    </template>
                </l-table>
                </template>
                <template v-else>
                <l-edit-table
                    addBtnText="添加字段"
                    :dataSource="node.authFields"

                    :isShowNum="false"

                    :isAddBtn="!disabled"
                    :isRemoveBtn="!disabled"

                    @addRow="handleAddAuthField"
                    @deleteRow="handleDeleteAuthField"
                    >
                    <el-table-column
                    prop="label"
                    label="名称"
                    minWidth="100">
                        <template slot-scope="scope">
                            <el-input :readonly="disabled" size="mini" v-model="scope.row.label" placeholder="请输入名称" ></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="field"
                        label="字段"
                        minWidth="100">
                        <template slot-scope="scope">
                            <el-input :readonly="disabled" size="mini" v-model="scope.row.field" placeholder="请输入字段"></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="required"
                        label="必填"
                        width="64">
                        <template slot-scope="scope">
                            <el-switch
                                v-model="scope.row.required"
                                :disabled="disabled"
                                >
                            </el-switch>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="isEdit"
                        label="编辑"
                        width="64">
                        <template slot-scope="scope">
                            <el-switch
                                v-model="scope.row.isEdit"
                                :disabled="disabled"
                                >
                            </el-switch>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="isLook"
                        label="查看"
                        width="64">
                        <template slot-scope="scope">
                            <el-switch
                                    v-model="scope.row.isLook"
                                    :disabled="disabled"
                                    >
                                </el-switch>
                        </template>
                    </el-table-column>
                </l-edit-table >
                </template>
            </div>
        </el-collapse-item>
        <el-collapse-item :title="$t('按钮设置')" name="5">
            <l-edit-table
                addBtnText="添加按钮"
                :dataSource="node.btnlist"
                :isShowNum="false"
                :hasDeleteBtn="hasBtnsDeleteBtn"

                :isAddBtn="!disabled"
                :isRemoveBtn="!disabled"

                @addRow="handleAddBtns"
                @deleteRow="handleDeleteBtns"
                
                >
                <el-table-column
                prop="name"
                label="名称"
                minWidth="100">
                    <template slot-scope="scope">
                        <el-input :readonly="disabled" v-if="!scope.row.isSys" size="mini" v-model="scope.row.name" placeholder="请输入名称" ></el-input>
                        <span v-else >{{scope.row.name}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="code"
                    label="编码"
                    minWidth="100">
                    <template slot-scope="scope">
                        <el-input :readonly="disabled" v-if="!scope.row.isSys" size="mini" v-model="scope.row.code" placeholder="请输入编码"></el-input>
                         <span v-else >{{scope.row.code}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    align="center"
                    prop="hidden"
                    label="隐藏"
                    width="64">
                    <template slot-scope="scope">
                        <el-switch
                            v-model="scope.row.hidden"
                            :disabled="disabled"
                            >
                        </el-switch>
                    </template>
                </el-table-column>
                <el-table-column
                    align="center"
                    prop="isSign"
                    label="签章"
                    width="64">
                    <template slot-scope="scope">
                        <el-switch
                            v-model="scope.row.isSign"
                            :disabled="disabled"
                            >
                        </el-switch>
                    </template>
                </el-table-column>
                <el-table-column
                    align="center"
                    prop="isNextAuditor"
                    label="下一审核人"
                    width="80">
                    <template slot-scope="scope">
                        <el-switch
                            v-if="scope.row.code != 'disagree'"
                            v-model="scope.row.isNextAuditor"
                            :disabled="disabled"
                            >
                        </el-switch>
                    </template>
                </el-table-column>
            </l-edit-table >
        </el-collapse-item>
        <el-collapse-item :title="$t('会签设置')" name="6">
            <div style="padding:0 16px" >
                <el-form-item label="是否会签">
                    <el-switch v-model="node.isCountersign" :disabled="disabled">
                    </el-switch>
                </el-form-item>
                <template v-if="node.isCountersign">
                    <el-form-item label="是否等待">
                        <el-switch v-model="node.isCountersignAll" :disabled="disabled">
                    </el-switch>
                    </el-form-item>
                    <el-form-item  v-if="node.isCountersignAll" label="通过百分比">
                        <el-input-number :disabled="disabled" :min="1" :max="100" v-model="node.countersignAllType">
                        </el-input-number>
                    </el-form-item>
                    <el-form-item label="审核方式">
                        <l-radio :disabled="disabled" v-model="node.countersignType" :options="[{value:'1',label:'并行'},{value:'2',label:'串行'}]" >
                        </l-radio>
                    </el-form-item>
                    <el-form-item label="再次审核">
                        <l-radio :disabled="disabled" v-model="node.countersignAgian" :options="[{value:'1',label:'已同意不需要审核'},{value:'2',label:'已同意需要审核'}]" >
                        </l-radio>
                    </el-form-item>
                </template>
                
            </div>
        </el-collapse-item>
        <el-collapse-item :title="$t('超时设置')" name="7">
            <div style="padding:0 16px" >
                <el-form-item label="超时通知">
                    <el-switch :disabled="disabled" v-model="node.isOvertimeMessage">
                    </el-switch>
                </el-form-item>
                <template v-if="node.isOvertimeMessage" >

                    <el-form-item  label="第一次通知(时)">
                        <el-input-number :disabled="disabled" :min="1" v-model="node.overtimeMessageStart">
                        </el-input-number>
                    </el-form-item>
                    <el-form-item  label="通知间隔(时)">
                        <el-input-number :disabled="disabled" :min="1" v-model="node.overtimeMessageInterval">
                        </el-input-number>
                    </el-form-item>
                    <el-form-item  label="超时流转时间(时)">
                        <el-input-number :disabled="disabled" :min="1" v-model="node.overtimeGo">
                        </el-input-number>
                    </el-form-item>
                    <el-form-item label="超时通知策略">
                        <l-checkbox :disabled="disabled" v-model="node.overtimeMessageType" :options="[{value:'1',label:'短信'},{value:'2',label:'邮箱'},{value:'3',label:'微信'},{value:'4',label:'站内消息'}]" >
                        </l-checkbox>
                    </el-form-item>
                </template>
                
            </div>
        </el-collapse-item>
    </el-collapse>


     <l-dialog
        :title="$t('添加岗位')"
        :visible.sync="selectPostVisible"
        :height="480"
        width="1024px"

        @ok="handlePostSelectOk"
        @closed="handlePostSelectClosed"
    >
        <l-post-select-panel ref="postSelectPanel" ></l-post-select-panel>
    </l-dialog>

    <l-dialog
        :title="$t('添加角色')"
        :visible.sync="selectRoleVisible"
        :height="480"
        width="800px"

        @ok="handleRoleSelectOk"
        @closed="handleRoleSelectClosed"
    >
        <l-role-select-panel ref="roleSelectPanel" ></l-role-select-panel>
    </l-dialog>


    <l-dialog
        :title="$t('添加用户')"
        :visible.sync="selectUserVisible"
        :height="480"
        width="1024px"

        @ok="handleUserSelectOk"
        @closed="handleUserSelectClosed"
    >
        <l-user-select-panel ref="userSelectPanel" ></l-user-select-panel>
    </l-dialog>

    <!--上下级选择-->
    <l-dialog
        :title="$t('上下级选择')"
        :visible.sync="levelVisible"
        :height="200"
        width="500px"

        @ok="handleLevelOk"
        @closed="handleLevelClosed"
    >
        <auditor-level-form ref="auditorLevelForm" ></auditor-level-form>
    </l-dialog>

    <!--流程节点选择-->
    <l-dialog
        :title="$t('流程节点选择')"
        :visible.sync="nodeAuditorVisible"
        :height="200"
        width="500px"

        @ok="handleNodeAuditorOk"
        @closed="handleNodeAuditorClosed"
        @opened="handleNodeAuditorOpened"
    >
        <node-auditor-form ref="nodeAuditorForm" ></node-auditor-form>
    </l-dialog>

    <!--流程节点选择-->
    <l-dialog
        :title="$t('数据表字段选择')"
        :visible.sync="auditorSqlVisible"
        width="500px"
        :height="300"

        @ok="handleAuditorSqlOk"
        @closed="handleAuditorSqlClosed"
    >
        <auditor-sql-form ref="auditorSqlForm" ></auditor-sql-form>
    </l-dialog>

 </el-form>
</template>

<script>

const apiForm = window.$api.custmerForm.scheme

import auditorLevelForm from './auditorLevel'
import nodeAuditorForm from './auditorNode'
import auditorSqlForm from './auditorSql'

export default {
    name:'user-task-option',
    props:{
      disabled:{
          type:Boolean,
          default:false
      }
    },
    components:{
        auditorLevelForm,
        nodeAuditorForm,
        auditorSqlForm
    },
    data () {
        return {
            activeNames: ['1'],
            columns:[
                {label:'名称',prop:'label',minWidth:'100'},
                {label:'字段',prop:'field',minWidth:'100'},
                {label:'必填',prop:'required',width:'64',align:'center'},
                {label:'编辑',prop:'isEdit',width:'64',align:'center'},
                {label:'查看',prop:'isLook',width:'64',align:'center'},
            ],
            tableBtns:[
                {prop:'Delete',label:'删除'}
            ],
            atuoAgreeOptions: [{ value: '1', label: '处理人就是提交人' }, { value: '2', label: '处理人和上一步的处理人相同' }, { value: '3', label: '处理人审批过' }],
            noAuditorOptions: [{ value: '1', label: '超级管理员处理' }, { value: '2', label: '跳过此步骤' }, { value: '3', label: '不能提交' }],
            userColumns:[
                {label:'类型',prop:'type',width:'64'},
                {label:'名称',prop:'name',minWidth:'100'},
                {label:'附加条件',prop:'condition',minWidth:'100'}
            ],

            conditionOptions:[{ value: '1', label: '同一个部门' }, { value: '2', label: '同一个公司' }, { value: '3', label: '发起人上级' }, { value: '4', label: '发起人下级' }],

            selectPostVisible:false,
            selectRoleVisible:false,
            selectUserVisible:false,
            levelVisible:false,
            nodeAuditorVisible:false,
            auditorSqlVisible:false,

            isLooker:false,

        }
    },
    asyncComputed:{
      formVerisons:{
        async get(){
            let res = []
            if(!this.$validatenull(this.node.formCode) && this.node.formType =='1'){
              res = await this.$awaitWraper(apiForm.getHistoryList(this.node.formCode))
            }
            return (res || []).map(t=>{return { label:this.lr_dateFormat(t.f_CreateDate),value:t.f_Id }})
        }
      }
    },
    computed: {
        node(){
          return this.wfdesign.currentWfNode;
        }
    },
    inject: ["wfdesign"],
    methods:{
        async custmerformChange(val){
            this.$set(this.node,'formRelationId','')
            if(val == null){
                this.node.authFields = [];
                this.node.formVerison = ''
                return;
            }
            if(this.$validatenull(this.wfdesign.custmerformSchemes[val.f_SchemeId])){
            const {f_SchemeInfoId,f_Scheme,f_Id} = (await this.$awaitWraper(apiForm.getHistory(val.f_SchemeId))) || {}
            this.wfdesign.custmerformSchemes[f_Id] = {f_Scheme}
            if(this.node.formCode == f_SchemeInfoId){
                this.loadFormScheme(f_Scheme)
            }
            }
            else{
                this.loadFormScheme(this.wfdesign.custmerformSchemes[val.f_SchemeId].f_Scheme);
            }
            this.node.formVerison = val.f_SchemeId
        },
        async custmerformVerisonChange(val){
            this.$set(this.node,'formRelationId','')
            if(this.$validatenull(val)){
                this.node.authFields = []
                return
            }
            if(this.$validatenull(this.wfdesign.custmerformSchemes[val.value])){
                const {f_Scheme,f_Id} = (await this.$awaitWraper(apiForm.getHistory(val.value))) || {}
                this.wfdesign.custmerformSchemes[f_Id] = {f_Scheme}
                if(this.node.formVerison == f_Id){
                    this.loadFormScheme(f_Scheme)
                }
            }
            else{
                this.loadFormScheme(this.wfdesign.custmerformSchemes[val.value].f_Scheme);
            }
        },
        loadFormScheme(strScheme){
            const scheme = JSON.parse(strScheme)
            const fields = []
            const rfields = []
            scheme.formInfo.tabList.forEach(tab => {
            tab.components.forEach(component =>{
                if(['guid'].includes(component.type)){
                    rfields.push({label:component.label,value:component.prop})
                }

                if(!['gridtable','divider'].includes(component.type) && component.display){
                    fields.push({
                        prop:component.prop,
                        field:component.field,
                        label:component.label,
                        table:component.table,
                        required:component.required,
                        isEdit:true,
                        isLook:true
                    })
                }
                else if(['gridtable'].includes(component.type)){
                    fields.push({
                        prop:`${component.prop}_add`,
                        label:`${component.label || '表格'}-添加按钮`,
                        required:false,
                        isEdit:true,
                        isLook:false,
                        type:'grid'
                    })
                    fields.push({
                        prop:`${component.prop}_remove`,
                        label:`${component.label || '表格'}-删除按钮`,
                        required:false,
                        isEdit:true,
                        isLook:false,
                        type:'grid'
                    })

                    fields.push({
                        prop:`${component.prop}_required`,
                        label:`${component.label || '表格'}-数据`,
                        required:component.required,
                        isEdit:false,
                        isLook:false,
                        type:'gridrequired'
                    })
                    fields.push(...component.children.filter(t=>t.display).map(t=>{
                        return {
                            gridprop:component.prop,
                            prop:t.prop,
                            field:t.field,
                            label:`${component.label || '表格'}-${t.label}`,
                            table:component.table,
                            required:t.required,
                            isEdit:true,
                            isLook:true
                        }
                    }))
                }
            })
            })
            this.node.formRelations = rfields
            this.node.authFields = fields
            
        },
        handleFormTypeChange(){
            this.node.formCode = ''
            this.node.formUrl = ''
            this.node.formAppUrl = ''
            this.node.authFields = []
            this.node.formRelations = []

            this.$set(this.node,'formRelationId','')
            
        },
        handleAddAuthField(){
            this.node.authFields.push({
            field:'',
            label:'',
            required:true,
            isEdit:true,
            isLook:true
            })
        },
        handleDeleteAuthField(row){
            this.node.authFields.splice(row.index,1);
        },

        handleTableBtnClick(btn){
            this.node.auditUsers.splice(btn.rowIndex,1);
        },
        handleTableBtnClick2(btn){
            this.node.lookUsers.splice(btn.rowIndex,1);
        },

        typeFormat(type){
            switch(type){
                case '1':
                    return '岗位'
                case '2':
                    return '角色'
                case '3':
                    return '用户'
                case '4':
                    return '上下级'
                case '5':
                    return '节点'
                case '6':
                    return '表字段'
            }
        },
        addTableData(selectData){
            if(this.isLooker){
                let addData2 = selectData.filter(t=>this.node.lookUsers.findIndex(t2=>t2.id == t.id && t2.type == t.type) == -1 );
                this.node.lookUsers = this.node.lookUsers.concat(addData2);
            }
            else{
                let addData = selectData.filter(t=>this.node.auditUsers.findIndex(t2=>t2.id == t.id && t2.type == t.type) == -1 );
                this.node.auditUsers = this.node.auditUsers.concat(addData);
            }
            
        },

        handlePostClick(isLooker){
            this.selectPostVisible = true;
            this.isLooker = isLooker;
        },
        handlePostSelectClosed(){
            this.$refs.postSelectPanel.resetForm();
        },
        handlePostSelectOk(){
            let selectData = this.$refs.postSelectPanel.getForm().map(t=>{return {type:'1',id:t.f_PostId,name:t.name}});
            this.addTableData(selectData);
            this.selectPostVisible = false;
        },

        handleRoleClick(isLooker){
            this.selectRoleVisible = true;
            this.isLooker = isLooker;
        },
        handleRoleSelectClosed(){
            this.$refs.roleSelectPanel.resetForm();
        },
        handleRoleSelectOk(){
            let selectData = this.$refs.roleSelectPanel.getForm().map(t=>{return {type:'2',id:t.f_RoleId,name:t.f_FullName,condition:''} });
            this.addTableData(selectData);
            this.selectRoleVisible = false;
        },

        handleUserClick(isLooker){
            this.selectUserVisible = true;
            this.isLooker = isLooker;
        },
        handleUserSelectClosed(){
            this.$refs.userSelectPanel.resetForm();
        },
        handleUserSelectOk(){
            let selectData = this.$refs.userSelectPanel.getForm().map(t=>{return {type:'3',id:t.f_UserId,name:t.name} });
            this.addTableData(selectData);
            this.selectUserVisible = false;
        },


        handleLevelClick(isLooker){
            this.levelVisible = true;
            this.isLooker = isLooker;
        },
        handleLevelClosed(){
            this.$refs.auditorLevelForm.resetForm();
        },
        handleLevelOk(){
            this.$refs.auditorLevelForm.validateForm(()=>{
                let data = this.$refs.auditorLevelForm.getForm();
                this.addTableData([data]);
                this.levelVisible = false;
            });
        },

        
        handleNodeAuditorClick(isLooker){
            this.nodeAuditorVisible = true;
            this.isLooker = isLooker;
        },
        handleNodeAuditorOk(){
            this.$refs.nodeAuditorForm.validateForm(()=>{
                let data = this.$refs.nodeAuditorForm.getForm();
                this.addTableData([data]);
                this.nodeAuditorVisible = false;
            });
        },
        handleNodeAuditorClosed(){
            this.$refs.nodeAuditorForm.resetForm();
        },
        handleNodeAuditorOpened(){
            let wfdata = this.wfdesign.handleGetWFData();
            this.$refs.nodeAuditorForm.setForm(wfdata.filter(t=>t.type = 'userTask' && t.id != this.node.id ));
        },


        handleAuditorSqlClick(isLooker){
            this.auditorSqlVisible = true;
            this.isLooker = isLooker;
        },
        handleAuditorSqlOk(){
            this.$refs.auditorSqlForm.validateForm(()=>{
                let data = this.$refs.auditorSqlForm.getForm();
                data.name = `${data.table}【${data.auditorField}】`
                this.addTableData([data]);
                this.auditorSqlVisible = false;
            });
        },
        handleAuditorSqlClosed(){
            this.$refs.auditorSqlForm.resetForm();
        },

        hasBtnsDeleteBtn(row){
            if(row.isSys){
                return false;
            }
            else{
                return true;
            }
        },
        handleAddBtns(){
            this.node.btnlist.push({code:'',name:'',hidden:false,isNextAuditor:false,isSign:false})
        },
        handleDeleteBtns(row){
            this.node.btnlist.splice(row.index,1);
        }

    }
    
}
</script>

<style>
</style>