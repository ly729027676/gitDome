<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="80px" >
            <el-col :span="24">
                <el-form-item label="上下级" prop="id">
                    <l-select v-model="formData.id" placeholder="请选择上下级" :options="options" @change="handleChange" ></l-select>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    name:'auditor-level-form',
    data(){
        return {
            formData:{
                name:'',
                type:'4',
                id:'',
            },
            rules: {
                id: [
                    { required: true, message: '请选择上下级' }
                ]
            },
            options: [
                { value: '1', label: '上一级' }, 
                { value: '2', label: '上二级' },
                { value: '3', label: '上三级' }, 
                { value: '4', label: '上四级' }, 
                { value: '5', label: '上五级' }, 
                { value: '6', label: '下一级' }, 
                { value: '7', label: '下二级' }, 
                { value: '8', label: '下三级' }, 
                { value: '9', label: '下四级' }, 
                { value: '10', label: '下五级' }]
        };
    },
    created () {
    },
    methods:{
        resetForm(){
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        setForm(data){
            this.formData = this.$deepClone(data);
           
        },
        getForm(){
            return this.$deepClone(this.formData);
        },
        handleChange(val){
            this.formData.name = val.label
        }
    }
}
</script>