<!-- 开始节点配置 -->
<template>
  <el-form
        class="l-form-config"
        label-width="88px"
        label-position="left"
        size="mini"
    >
    <el-form-item label="节点标识">
      <el-input v-model="node.id" readonly ></el-input>
    </el-form-item>
    <div style="padding:0 16px;">
        <el-alert
            title="并行网关说明"
            type="info"
            description="并行网关会等待所有分支汇入才往下执行，所有出口分支都会被执行"
            show-icon
            :closable="false"
            >
        </el-alert>
    </div>
  </el-form>
</template>

<script>
export default {
    name:'gateway-and-option',
    data () {
        return {
        }
    },
    computed: {
        node(){
          return this.wfdesign.currentWfNode;
        }
    },
    inject: ["wfdesign"]
}
</script>

<style>
</style>