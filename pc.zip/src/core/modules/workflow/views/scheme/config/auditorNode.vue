<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="80px" >
            <el-col :span="24">
                <el-form-item label="节点" prop="id">
                    <l-select v-model="formData.id" placeholder="请选择节点" valueKey="id" labelKey="name" :options="options" @change="handleChange" ></l-select>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    name:'node-auditor-form',
    data(){
        return {
            formData:{
                name:'',
                type:'5',
                id:'',
            },
            rules: {
                id: [
                    { required: true, message: '请选择节点' }
                ]
            },
            options: []
        };
    },
    created () {
    },
    methods:{
        resetForm(){
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        setForm(wfdata){
            //console.log(wfdata,'节点选择')
            this.options = wfdata.filter(t=>t.name);
        },
        getForm(){
            return this.$deepClone(this.formData);
        },
        handleChange(val){
            this.formData.name = this.options.find(t=>t.id == val).name;
        }
    }
}
</script>