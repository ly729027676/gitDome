<!-- 开始节点配置 -->
<template>
  <el-form
        class="l-form-config"
        label-width="88px"
        label-position="left"
        size="mini">
    <el-form-item label="节点标识">
      <el-input  v-model="node.id" readonly ></el-input>
    </el-form-item>
    <el-form-item label="是否异步">
      <el-switch :disabled="disabled" v-model="node.isAsync">
      </el-switch>
    </el-form-item>
    <el-form-item label="流程模版">
      <l-select :disabled="disabled"   v-model="node.wfschemeId" :options="list">
      </l-select>
    </el-form-item>
    <el-form-item label="流程版本">
      <l-select :disabled="disabled"   v-model="node.wfVersionId" :options="verisons">
      </l-select>
    </el-form-item>
  </el-form>
</template>

<script>
const api = window.$api.workflow.scheme

export default {
    name:'subprocess-option',
    props:{
      disabled:{
          type:Boolean,
          default:false
      }
    },
    data () {
        return {
        }
    },
    asyncComputed:{
      list:{
        async get(){
          const data = await this.$awaitWraper(api.getList())
          const res = data || []
          return res.filter(t=>t.f_Id != this.wfdesign.schemeinfoId).map(t=>{return {label:t.f_Name,value:t.f_Id}})
        }
      },
      verisons:{
        async get(){
            let res = []
            if(!this.$validatenull(this.node.wfschemeId)){
              res = await this.$awaitWraper(api.getHistoryList(this.node.wfschemeId))
            }
            return (res || []).map(t=>{return { label:this.lr_dateFormat(t.f_CreateDate),value:t.f_Id }})
        }
      }
    },
    computed: {
        node(){
          return this.wfdesign.currentWfNode;
        }
    },
    inject: ["wfdesign"]
}
</script>

<style>
</style>