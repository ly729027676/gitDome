<!-- 开始节点配置 -->
<template>
  <el-form
        class="l-form-config"
        label-width="88px"
        label-position="left"
        size="mini">
    <el-form-item label="节点标识">
      <el-input v-model="node.id" readonly ></el-input>
    </el-form-item>
    <el-form-item v-if="conditionsOptions && conditionsOptions.length >0" label="流转条件">
      <l-select 
        :disabled="disabled"

        v-model="value" 
        :options="conditionsOptions"
        
        labelKey="name"
        valueKey="code"
        :multiple="true"
        placeholder="不选择,默认流转条件为true"
         ></l-select>
    </el-form-item>

    
  </el-form>
</template>

<script>
export default {
    name:'line-option',
    props:{
      disabled:{
          type:Boolean,
          default:false
      }
    },
    data () {
        return {
          conditionsOptions:[],
          value2:''
        }
    },
    computed: {
        node(){
          return this.wfdesign.currentWfNode;
        },
        value:{
          get(){
            return this.value2;
          },
          set(val){
            this.value2 = val;
            this.node.lineConditions = val;
          }
        }
    },
    inject: ["wfdesign"],
    created(){   
      this.getConditions()
    },
    methods:{
      getConditions(){
        let wfdata = this.wfdesign.handleGetWFData();
        let fromNode = wfdata.find(t=>t.id == this.node.from);
        /**
         *  startEvent:'开始节点',
            endEvent:'结束节点',
            gatewayAnd:'并行网关',
            gatewayInclusive:'包含网关',
            gatewayXor:'排他网关',
            scriptTask:'脚本节点',
            userTask:'审核节点',
            subprocess:'子流程',
         */
        switch(fromNode.type){
          case 'startEvent':
          case 'endEvent':
          case 'gatewayAnd':
          case 'scriptTask':
          case 'subprocess':
            this.node.lineConditions = ''
            this.conditionsOptions = []
            break
          case 'gatewayInclusive':
          case 'gatewayXor':
            this.conditionsOptions = fromNode.conditions
            // 过滤掉没有的值
            this.filterValue()
            break
          case 'userTask':
            this.conditionsOptions = fromNode.btnlist.filter(t=>!t.hidden)
            
            

            // 过滤掉没有的值
            this.filterValue()
            break
        }



        this.value2 = this.node.lineConditions
      },
      filterValue(){
        const vlist = this.node.lineConditions.split(',')
        const res = []
        vlist.forEach(item => {
          if(this.conditionsOptions.findIndex(t=>t.code == item) != -1){
            res.push(item)
          }
        })
        this.node.lineConditions = String(res)
      }
    }
}
</script>

<style>
</style>