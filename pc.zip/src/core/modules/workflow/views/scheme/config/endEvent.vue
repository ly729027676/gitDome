<!-- 开始节点配置 -->
<template>
   <el-form
        class="l-form-config"
        label-width="88px"
        label-position="left"
        size="mini"
    >
    <el-form-item label="节点标识">
      <el-input v-model="node.id" readonly ></el-input>
    </el-form-item>
   </el-form>
</template>

<script>
export default {
    name:'end-event-option',
    data () {
        return {
        }
    },
    computed: {
        node(){
          return this.wfdesign.currentWfNode;
        }
    },
    inject: ["wfdesign"]
}
</script>

<style>
</style>