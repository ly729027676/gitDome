<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="120px" >
            <el-col :span="24">
                <el-form-item label="条件名称" prop="name">
                    <el-input  v-model="formData.name" >
                    </el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="数据库" prop="dbCode">
                    <el-select v-model="formData.dbCode" placeholder="请选择">
                        <el-option-group
                        v-for="group in lr_dblinkTree"
                        :key="group.id"
                        :label="group.label">
                        <el-option
                            v-for="item in group.children"
                            :key="item.id"
                            :label="item.label"
                            :value="item.id">
                        </el-option>
                        </el-option-group>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="数据表" prop="table">
                    <l-dbtable-select 
                    @change="handleTableChange"
                    :dbCode="formData.dbCode" 
                    v-model="formData.table"></l-dbtable-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="关联流程字段" prop="rfield">
                    <l-select :options="formData.columns" valueKey="name" labelKey="name" v-model="formData.rfield" >
                    </l-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="比较字段" prop="cfield">
                    <l-select :options="formData.columns"  valueKey="name" labelKey="name" v-model="formData.cfield" >
                    </l-select>
                </el-form-item>
            </el-col>
           <el-col :span="24">
                <el-form-item label="比较类型" prop="compareType">
                    <l-select :options="options"  v-model="formData.compareType" >
                    </l-select>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="数据值" prop="value">
                    <el-input  v-model="formData.value" >
                    </el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    name:'condition-formula',
    props:{
    },
    data(){
        return {
            formData:{
                dbCode:'',
                table:'',
                columns:[],
                rfield:'',
                cfield:'',
                compareType:'',
                value:'',
                name:''
            },
            rules: {
                dbCode: [
                    { required: true, message: '请选择数据库' }
                ],
                table: [
                    { required: true, message: '请选择数据表' }
                ],
                rfield: [
                    { required: true, message: '请选择关联字段' }
                ],
                cfield: [
                    { required: true, message: '请选择比较字段' }
                ],
                compareType: [
                    { required: true, message: '请选择比较类型' }
                ],
                value: [
                    { required: true, message: '请填写值' }
                ],
                name: [
                    { required: true, message: '请填写条件名称' }
                ]
            },
            options:[
                { value: '1', label: '等于' }, 
                { value: '2', label: '不等于' },
                { value: '3', label: '大于' }, 
                { value: '4', label: '大于等于' }, 
                { value: '5', label: '小于' }, 
                { value: '6', label: '小于等于' }, 
                { value: '7', label: '包含' }, 
                { value: '8', label: '不包含' }, 
                { value: '9', label: '包含于' },
                { value: '10', label: '不包含于' }]
        };
    },
    computed:{
    },
    created () {
    },
    methods:{
        handleTableChange(table){
            this.formData.columns = table.columns;
            console.log(table);
        },
        resetForm(){
            this.formData.columns = [];
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        setForm(data){
            this.formData = this.$deepClone(data);
        },
        getForm(){
            let formData = this.$deepClone(this.formData);
            return formData;
        }
    }
}
</script>