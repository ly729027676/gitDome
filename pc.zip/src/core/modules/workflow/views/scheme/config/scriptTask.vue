<!-- 开始节点配置 -->
<template>
  <el-form
        class="l-form-config"
        label-width="88px"
        label-position="left"
        size="mini">
    <el-form-item label="节点标识">
      <el-input v-model="node.id" readonly ></el-input>
    </el-form-item>
    <el-divider>执行操作</el-divider>
    <div style="text-align: center;margin-bottom:16px;" >
        <el-radio-group v-model="node.executeType" size="mini" :disabled="disabled">
            <el-radio-button label="1">执行SQL</el-radio-button>
            <el-radio-button label="2">.NET方法</el-radio-button>
            <el-radio-button label="3">第三方接口</el-radio-button>
        </el-radio-group>
    </div>
    <template v-if="node.executeType == '1'" >
      <div style="padding:0 0 16px 0;">
          <el-alert
              title="sql参数说明"
              type="info"
              description="参数有 @processId流程进程主键 @code上一步执行码 @userId流程发起人Id @userAccount流程发起人账号 @companyId流程发起人公司 @departmentId流程发起人部门;
              @userId2上一步审核人Id @userAccount2上一步审核人账号 @companyId2上一步审核人公司 @departmentId2上一步审核人部门;
              "
              show-icon
              :closable="false"
              >
          </el-alert>
      </div>
      <el-form-item label-width="0">
          <el-select v-model="node.sqlDb" placeholder="请选择执行SQL数据库" :disabled="disabled">
              <el-option-group
              v-for="group in lr_dblinkTree"
              :key="group.id"
              :label="group.label">
                  <el-option
                      v-for="item in group.children"
                      :key="item.id"
                      :label="item.label"
                      :value="item.id">
                  </el-option>
              </el-option-group>
          </el-select>
      </el-form-item>
      <el-form-item label-width="0">
          <el-input :readonly="disabled" type="textarea" v-model="node.sqlStr" rows="8" placeholder="请填写SQL语句" ></el-input>
      </el-form-item>
      <el-form-item label-width="0">
          <el-input :readonly="disabled" type="textarea" v-model="node.sqlStrRevoke" rows="8" placeholder="请填写SQL语句（撤销）" ></el-input>
      </el-form-item>
    </template>
    <template v-if="node.executeType == '2'" >
      <div style="padding:0 0 16px 0;">
          <el-alert
              title="IOC说明"
              type="info"
              description="注意：编写一个继承IWorkFlowMethod的类
              "
              show-icon
              :closable="false"
              >
          </el-alert>
      </div>
      <el-form-item label-width="0">
          <el-input :readonly="disabled" type="textarea" v-model="node.ioc" rows="4" placeholder="ioc名称" ></el-input>
      </el-form-item>
      <el-form-item label-width="0">
          <el-input :readonly="disabled" type="textarea" v-model="node.iocRevoke" rows="4" placeholder="ioc名称（撤销）" ></el-input>
      </el-form-item>
    </template>
    <template v-if="node.executeType == '3'" >
      <div style="padding:0 0 16px 0;">
          <el-alert
              title="接口参数说明"
              type="info"
              description="注意：配置支持Post方法的接口,json数据格式。{
                processId:'流程发起实例主键',userId:'流程发起人Id',userAccount:'流程发起人账号',companyId:'流程发起人公司',departmentId:'流程发起人部门',code:'上一步执行码',
                userId2:'上一步审核人Id',userAccount2:'上一步审核人账号',companyId2:'上一步审核人公司',departmentId2:'上一步审核人部门'
                }
              "
              show-icon
              :closable="false"
              >
          </el-alert>
      </div>
      <el-form-item label-width="0">
          <el-input :readonly="disabled" type="textarea" v-model="node.apiUrl" rows="4" placeholder="接口地址" ></el-input>
      </el-form-item>
      <el-form-item label-width="0">
          <el-input :readonly="disabled" type="textarea" v-model="node.apiUrlRevoke" rows="4" placeholder="接口地址（撤销）" ></el-input>
      </el-form-item>
    </template>

    
    
  </el-form>
</template>

<script>
export default {
    name:'script-task-option',
    props:{
      disabled:{
          type:Boolean,
          default:false
      }
    },
    data () {
        return {
        }
    },
    computed: {
        node(){
          return this.wfdesign.currentWfNode;
        }
    },
    inject: ["wfdesign"]
}
</script>

<style>
</style>