<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="120px" >
            <el-col :span="24">
                <el-form-item label="条件名称" prop="name">
                    <el-input  v-model="formData.name" >
                    </el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="数据库" prop="dbCode">
                    <el-select v-model="formData.dbCode" placeholder="请选择">
                        <el-option-group
                        v-for="group in lr_dblinkTree"
                        :key="group.id"
                        :label="group.label">
                        <el-option
                            v-for="item in group.children"
                            :key="item.id"
                            :label="item.label"
                            :value="item.id">
                        </el-option>
                        </el-option-group>
                    </el-select>
                </el-form-item>
            </el-col>
             <div style="padding:0 0 16px 120px;">
                <el-alert
                    title="sql语句说明"
                    type="warning"
                    description="请在开发人员指导下进行配置SQL语句（{processId}流程发起实例主键{userId}流程发起用户Id{userAccount}流程发起用户账号{companyId}流程发起用户公司{departmentId}流程发起用户部门）！"
                    show-icon
                    :closable="false"
                    >
                </el-alert>
            </div>
            <el-col :span="24">
                <el-form-item label="SQL语句" prop="sql">
                    <el-input  v-model="formData.sql" type="textarea"
                        :autosize="{ minRows: 8}" >
                    </el-input>
                </el-form-item>
            </el-col>
           
        </el-form>
    </div>
</template>
<script>
export default {
    name:'condition-sql',
    props:{
    },
    data(){
        return {
            formData:{
                dbCode:'',
                sql:'',
                name:''
            },
            rules: {
                dbCode: [
                    { required: true, message: '请选择数据库' }
                ],
                sql: [
                    { required: true, message: '请填写sql语句' }
                ],
                name: [
                    { required: true, message: '请填写条件名称' }
                ]
            },
        };
    },
    computed:{
    },
    created () {
    },
    methods:{
        resetForm(){
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        setForm(data){
            this.formData = this.$deepClone(data);
        },
        getForm(){
            let formData = this.$deepClone(this.formData);
            return formData;
        }
    }
}
</script>