export default url => {
    const crud = window.$crud(url)
    const updateState = (id,state) => window.$axios({
        url: `${url}/${id}/${state}`,
        method: 'put'
    })

    const getMyUserList = (code) => window.$axios({
        url: `${url}/users/${code}`,
        method: 'get'
    })
    return {
        ...crud,
        updateState,
        getMyUserList
    }
}