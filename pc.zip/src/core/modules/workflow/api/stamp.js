export default url => {
    const crud = window.$crud(url)
    const updateState = (id,state) => window.$axios({
        url: `workflow/stamp/${id}/${state}`,
        method: 'put'
    })
    
    
    const equalPassword = (id,password) => window.$axios({
        url: `workflow/stamp/${id}/${password}`,
        method: 'get'
    })

    crud.getList = (id) => window.$axios({
        url: `workflow/stamps/${id}`,
        method: 'get'
    })




    return {
        ...crud,
        updateState,
        equalPassword
    }
}