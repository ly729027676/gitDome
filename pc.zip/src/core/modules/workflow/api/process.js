


export default url => {
    
    const getPage = (qureyData) => window.$axios({
        url:`${url}/page`,
        method: 'get',
        params:qureyData
    })

    const getMyPage = (qureyData) => window.$axios({
        url:`${url}/mypage`,
        method: 'get',
        params:qureyData
    })

    const getMyDraftPage = (qureyData) => window.$axios({
        url:`${url}/mydraftpage`,
        method: 'get',
        params:qureyData
    })

    const getMyRecyclePage = (qureyData) => window.$axios({
        url:`${url}/myrecyclepage`,
        method: 'get',
        params:qureyData
    })

    const getUnCompletedMyPage = (params) => window.$axios({
        url:`${url}/uncompleted/mypage`,
        method: 'get',
        params:params
    })


    const getCompletedMyPage = (params) => window.$axios({
        url:`${url}/completed/mypage`,
        method: 'get',
        params:params
    })

    const getDelegateMyPage = (params) => window.$axios({
        url:`${url}/delegate/mypage`,
        method: 'get',
        params:params
    })

    

    const getReadMyPage = (params) => window.$axios({
        url:`${url}/read/mypage`,
        method: 'get',
        params:params
    })

    const getTask = (id) => window.$axios({
        url:`${url}/task/${id}`,
        method: 'get'
    })

    const GetTaskByToken = (id) => window.$axios({
        url:`${url}/task/token/${id}`,
        method: 'get'
    })

    const get = (id) => window.$axios({
        url:`${url}/${id}`,
        method: 'get'
    })


    const saveDraft = (data) => window.$axios({
        url:`${url}/draft`,
        method: 'post',
        data:data
    })

    const deleteDraft = (id) => window.$axios({
        url:`${url}/draft/${id}`,
        method: 'delete'
    })


    const getDraft = (id) => window.$axios({
        url:`${url}/draft/${id}`,
        method: 'get'
    })

    const create = (data) => window.$axios({
        url:`${url}/create`,
        method: 'post',
        data:data
    })

    const createAgain = (data) => window.$axios({
        url:`${url}/CreateAgain`,
        method: 'post',
        data:data
    })

    const revoke = (id) => window.$axios({
        url:`${url}/revoke/${id}`,
        method: 'put'
    })


    const revokeAudit = (id,taskId) => window.$axios({
        url:`${url}/audit/revoke/${id}`,
        method: 'put',
        params:{taskId}
    })


    const urge = (id) => window.$axios({
        url:`${url}/urge/${id}`,
        method: 'put'
    })

    const audit = (id,data) => window.$axios({
        url:`${url}/audit/${id}`,
        method: 'put',
        data
    })


    

    const getNextUsers = (params) => window.$axios({
        url:`${url}/nextusers`,
        method: 'get',
        params
    })

    const transferUser = (id,data) => window.$axios({
        url:`${url}/transfer/${id}`,
        method: 'put',
        data
    })

    const sign  = (id,data) => window.$axios({
        url:`${url}/sign/${id}`,
        method: 'put',
        data
    })

    const signAudit  = (id,data) => window.$axios({
        url:`${url}/signaudit/${id}`,
        method: 'put',
        data
    })

    const readAudit  = (id) => window.$axios({
        url:`${url}/read/${id}`,
        method: 'put'
    })


    const deleteProcess  = (id) => window.$axios({
        url:`${url}/${id}`,
        method: 'delete'
    })

    const pointProcess  = (id,data) => window.$axios({
        url:`${url}/point/${id}`,
        method: 'put',
        data
    })


    

    return {
        getPage,
        getMyPage,
        getMyDraftPage,
        getMyRecyclePage,
        getUnCompletedMyPage,
        getCompletedMyPage,
        getReadMyPage,
        getDelegateMyPage,
        get,
        getTask,
        GetTaskByToken,

        saveDraft,
        deleteDraft,
        getDraft,
        create,
        createAgain,
        revoke,
        revokeAudit,
        urge,
        audit,
        transferUser,
        sign,
        signAudit,
        getNextUsers,
        readAudit,
        deleteProcess,
        pointProcess
    }
}