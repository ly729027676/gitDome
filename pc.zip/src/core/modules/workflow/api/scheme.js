export default url => {
    const crud = window.$crud(url)
    const getMyList = () => window.$axios({
        url: `${url}/mylist`,
        method: 'get'
    })

    const updateState = (id,state) => window.$axios({
        url: `${url}/state/${id}/${state}`,
        method: 'put'
    })

    const getHistoryPage = (id,qureyData) => window.$axios({
        url: `${url}/history/page/${id}`,
        method: 'get',
        params:qureyData
    })
    const getHistoryList = (id) => window.$axios({
        url: `${url}/historys/${id}`,
        method: 'get'
    })


    const getHistory = (id) => window.$axios({
        url: `${url}/history/${id}`,
        method: 'get'
    })

    const updateHistory = (id,schemeId) => window.$axios({
        url: `${url}/history/${id}/${schemeId}`,
        method: 'put'
    })
    return {
        ...crud,
        getMyList,
        updateState,
    
        getHistoryPage,
        getHistoryList,
        getHistory,
        updateHistory,
    }
}