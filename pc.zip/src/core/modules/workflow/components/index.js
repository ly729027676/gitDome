let components = []
const requireComponent = require.context('./', true, /index\.vue$/)
requireComponent.keys().map(fileName => {
  components.push({
    name: `l-${fileName.split('/')[1]}`,
    component: requireComponent(fileName).default
  })
})

const wfComponent = require.context('../views', true, /wf\.js$/)
wfComponent.keys().map(fileName => {
    const nameList = fileName.split('/')
    if (nameList.length == 3 && nameList[2] == 'wf.js') {
        const wf = wfComponent(`${fileName}`).default
        if (wf) {
            components.push({
                name: `${wf.wfName}`,
                component: () => import(/* webpackChunkName: "[request]" */ `../views/${nameList[1]}/${wf.name}`)
            })
        }
    }
})

export default components