<template>
    <div class="l-wf-audit-info">  
        <div class="l-wf-audit-info--item" :key="item.id" v-for="item in data"  >
            <div class="l-wf-audit-info--header">{{item.name}}</div>
            <div class="l-wf-audit-info--body">
                <div style="position: relative;z-index:2;" >{{item.des}}</div>
                <div class="l-wf-audit-info--imgdiv" v-if="item.img" >
                    <img class="l-wf-audit-info--img" :src="`${apiUrl}system/stamp/wfimg/${item.img}?token=${token}` ">
                </div>
                
                <div class="l-wf-audit-info--user" >
                    <div class="l-wf-audit-info--name">
                        <span>签&nbsp;&nbsp;&nbsp;&nbsp;字:&nbsp;&nbsp;</span>
                        <span>{{item.user}}</span>
                    </div>
                    <div class="l-wf-audit-info--date">
                        <span>日&nbsp;&nbsp;&nbsp;&nbsp;期:&nbsp;&nbsp;</span>
                        <span>{{item.time}}</span>
                    </div>
                </div>
                
            </div>  
        </div> 
    </div>
</template>
<script>

export default {
    name:'l-wf-audit-info',
    props:{
        data:{
            type:Array,
            default:()=>[]
        }
    },
    data(){
        return {
        }
    },
    computed:{
    },
    methods:{
    }
}
</script>
<style lang="scss" scoped>
    .l-wf-audit-info{
        position: relative;
        box-sizing: border-box;
        width: 100%;
        &--item{
            position: relative;
            width: 100%;
            border: 1px solid #ccc;
            padding-left: 120px;
            border-top: 0;
            box-sizing: border-box;
            min-height: 88px;
        }

        &--item:first-child {
            border-top: 1px solid #ccc;
        }

        &--header {
            position: absolute;
            box-sizing: border-box;
            top: 0;
            left: 0;
            height: 100%;
            width: 120px;
            border-right: 1px solid #ccc;
            padding: 4px 0 0 4px;
        }

        &--body {
            position: relative;
            box-sizing: border-box;
            width: 100%;
            height: 100%;
            padding: 4px;
        }

        &--imgdiv {
            position: absolute;
            box-sizing: border-box;
            top: 0;
            right: 0;
            width: 80px;
        }
        &--img {
            width: 100%;
        }
        &--user{
            margin-top: 8px;
            position: relative;
            width: 100%;
            height: 42px;
            box-sizing: border-box;
        }

        &--name {
            position: absolute;
            bottom: 24px;
            right: 0;
            width: 180px;
            text-align: left;
            font-size:12px;
        }

        &--date{
            position: absolute;
            right: 0;
            width: 180px;
            text-align: left;
            bottom: 4px;
            font-size:12px;
        }
    }
</style>