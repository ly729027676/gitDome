<template>
   <el-button-group>
        <el-button @click="handleCreateFlow" type="primary" size="mini" >发起流程</el-button>
        <el-button @click="handleSaveDraft" size="mini">保存草稿</el-button>
    </el-button-group>
</template>
<script>

export default {
    name:'l-wf-btns',
    data(){
        return {
        }
    },
    computed:{
    },
    methods:{
    }
}
</script>