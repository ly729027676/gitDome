export default {
    name: '移动端管理',
    code: 'mapp',
    version: '1.0.0',
    description: '移动端功能，桌面管理'
}