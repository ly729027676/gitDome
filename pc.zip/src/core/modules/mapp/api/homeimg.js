export default url => {
    const crud = window.$crud(url)
    crud.updateState = (id,state) => window.$axios({
        url:`${url}/${id}/${state}`,
        method: 'put'
    })
    return {
        ...crud
    }
}