export default url => {
    const crud = window.$crud(url)

    const updateState = (id,state) => window.$axios({
        url: `${url}/${id}/${state}`,
        method: 'put'
    })

    const getChildren = (id,type) => window.$axios({
        url: `${url}/children/${type}/${id}`,
        method: 'get'
    })

    return {
        ...crud,
        updateState,
        getChildren
    }
}