<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="80px" >
            <el-col :span="24">
                <el-form-item label="说明" prop="f_Des">
                    <el-input v-model="formData.f_Des"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="排序" prop="f_SortCode">
                    <el-input-number v-model="formData.f_SortCode"  controls-position="right" :min="1" ></el-input-number>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="状态" >
                    <el-switch
                    :active-value="1"
                    :inactive-value="0"
                    v-model="formData.f_EnabledMark"
                    >
                    </el-switch>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="图片上传" prop="f_FileName"> 
                    <l-upload
                        v-model="formData.f_FileName"
                        listType="picture-card"
                        :chunkedUpload="lr_chunkedUpload"
                        :getFileList="lr_getFileList"
                        :deleteFile="lr_deleteFile"
                    >
                    </l-upload>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    name:'base-form',
    props:{
    },
    data(){
        return {
            formData:{
                f_FileName:'',
                f_Des: '',
                f_SortCode: '',
                f_EnabledMark:1,
            },
            rules: {
                f_Des: [
                    { required: true, message: '请输入说明' }
                ],
                f_FileName: [
                    { required: true, message: '请上传图片' }
                ]
            }
        };
    },
    computed:{
    },
    methods:{
        // 重置表单
        resetForm(){
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(callback){
            this.$refs.form.validate((valid) => {
                if(valid){
                    callback();
                }
            });
        },
        // 设置表单数据
        setForm(data){
            this.formData = this.$deepClone(data);
        },
        // 获取表单数据
        getForm(){
            return this.$deepClone(this.formData);
        }
    }
}
</script>