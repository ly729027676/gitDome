<template>
    <l-layout class="l-tab-page" v-show="!lr_loadPage" >
        <l-panel >
            <template #toolLeft >
                <div class="l-panel--item" >
                    <el-input :placeholder="$t('请输入要查询关键字')"  @keyup.enter.native="hanleSearch" v-model="searchWord" size="mini" >
                        <el-button @click="hanleSearch" slot="append" icon="el-icon-search"></el-button>
                    </el-input>
                </div>
            </template>
            <template #toolRight >
                <l-tool-btns @click="handleAdd()" >
                    <l-excel-btns></l-excel-btns>
                </l-tool-btns>
            </template>
            <l-table :columns="columns" :dataSource="tableShowData" :loading="loading" >
                <template v-slot:f_FileName="scope" >
                    <el-image
                        style="width: 280px;margin-top: 8px;"
                        :src="`${apiUrl}system/annexesfile/${scope.row.f_FileName}?token=${token}`"
                        fit="contain" lazy></el-image>
                </template>
                <template v-slot:f_EnabledMark="scope" >
                    <el-switch
                        :active-value="1"
                        :inactive-value="0"
                        v-model="scope.row.f_EnabledMark"
                        @change="handleEnableChange(scope.row)"
                        >
                    </el-switch>
                </template>
                <l-table-btns :btns="tableBtns" @click="lr_handleTableBtnClick" ></l-table-btns>
            </l-table>
        </l-panel>

        <l-dialog 
            :title="formTitle"
            :visible.sync="formVisible"
            @ok="handleSave"
            @close="handleCloseForm"
            @opened="handleOpenedForm"
            >
            <my-form ref="form" ></my-form>       
        </l-dialog>
    </l-layout>
</template>

<script>
const api = window.$api.mapp.homeimg
import MyForm from './form'
export default {
    components: {
        MyForm
    },
    data () {
        return {
            lr_isPage:true,
            // 左侧树形
            treeLoading:true,
            treeCategory:'',
            classifysVisible:false,

            //查询
            searchWord:'',
            searchTableData:null,

            loading:false,
            columns: [
                {label:'说明',prop:'f_Des',minWidth:'110'},
                {label:'图片',prop:'f_FileName',width:'304',align:'center'},
                {label:'排序',prop:'f_SortCode',width:'64',align:'center'},
                {label:'状态',prop:'f_EnabledMark',width:'64',align:'center'}
            ],
            tableBtns:[
                {prop:'Edit',label:'编辑'},
                {prop:'Delete',label:'删除'}
            ],
            tableData:[],
            tableShowData:[],

            formVisible:false,
            formTitle:'',
            formEditRow:null,
            formEdit:false
        };
    },
    computed:{
    },
    mounted () {
        this.loadTableData();
    },
    methods:{
        async loadTableData(){
            this.loading = true;
            this.searchWord = '';
            const data = await this.$awaitWraper(api.getList());
            this.loading = false;
            this.tableData = data || [];
            this.tableShowData = this.tableData;
        },
        hanleSearch(){
            if(this.$validatenull(this.searchWord)){
                this.tableShowData = this.tableData;
            }
            else{
                this.tableShowData = this.tableData.filter(t=>t.f_Name.indexOf(this.searchWord) != -1);
            }
        },
        async handleEnableChange(row){
            await api.updateState(row.f_Id,row.f_EnabledMark);
            this.$message({
                type: 'success',
                message: '更新成功!'
            })
        },
        handleAdd(){
            this.formEdit = false;
            this.showForm('新增移动功能');
        },
        handleEdit($index,row){
            this.formEdit = true;
            this.formEditRow = row;
            this.showForm('编辑移动功能');
        },
        handleDelete($index,row){
            this.$confirm(this.$t('此操作将永久删除该数据, 是否继续?'), this.$t('提示'), {
                confirmButtonText: this.$t('确定'),
                cancelButtonText: this.$t('取消'),
                type: 'warning'
            }).then(async () => {
                this.tableShowData.splice($index,1);
                let index = this.tableData.findIndex(t=>t.f_Id == row.f_Id);
                if(index != -1){
                    this.tableData.splice(index,1);
                }
                await api.remove(row.f_Id);
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                });
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });          
            });
        },
        handleSave(showLoading,hideLoading){
            this.$refs.form.validateForm(async ()=>{
                showLoading();
                const postData = this.$refs.form.getForm();
                if(this.formEdit){// 修改数据
                    if(await this.$awaitWraper(api.update(postData.f_Id,postData))){
                        this.$message({
                            type: 'success',
                            message: '更新成功!'
                        });
                        this.loadTableData();
                        this.formVisible = false;
                    }
                }
                else{// 新增数据
                    if(await this.$awaitWraper(api.add(postData))){
                        this.$message({
                            type: 'success',
                            message: '新增成功!'
                        });
                        this.loadTableData();
                        this.formVisible = false;
                    }
                }
                hideLoading();
            });
        },
        handleOpenedForm(){
            if(this.formEdit){
                this.$refs.form.setForm(this.formEditRow);
            }
        },
        handleCloseForm(){
            this.$refs.form.resetForm();
        },
        showForm(text){
            this.formTitle = text;
            this.formVisible = true;
        }
    }

}
</script>
