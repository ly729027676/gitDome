<template>
  <div>
    <div class="reg-item" :key="item.id" v-for="(item,index) in config.list" >
        <el-form-item label="图片上传" style="margin-bottom:8px;"> 
            <l-upload
                v-model="item.imgurl"
                listType="picture-card"
                :chunkedUpload="lr_chunkedUpload"
                :getFileList="lr_getFileList"
                :deleteFile="lr_deleteFile"
            >
            </l-upload>
        </el-form-item>
        <el-form-item label="跳转功能" style="margin-bottom:0;" >
            <l-tree-select :options="appTree"  v-model="item.moduleId" >
            </l-tree-select>
        </el-form-item>        
        <el-button title="删除"
                    v-if="config.list.length > 1"
                    @click="handleRemoveCol(index)"
                    class="reg-item-delete"
                    circle
                    plain
                    size="mini"
                    type="danger">
            <i class="el-icon-close"></i>
        </el-button>
    </div>
    <div class="mt-8">
        <el-button type="primary" size="mini" @click="handleAddCol" >添加数据项</el-button>
    </div>
  </div>
</template>
<script>
export default {
    props: ['data'],
    inject: ["appDesign"],
    computed:{
        config(){
            return this.data
        },
        appTree(){
            return this.appDesign.appTree || []
        }
    },
    created(){
        /*if(this.config.dataCode){
            this.lr_loadDataSourceColNames(this.config.dataCode)
        }*/
    },
    methods: {
        init(){

        },
        myColNameList(dataCode){
            if(this.lr_dataSourceCol && dataCode){
                const colNameList = this.lr_dataSourceCol[dataCode] || []
                return colNameList.map(t=>{return {value:t,label:t}})
            }
            else{
                return []
            }
        },
        handleDataSourceChange(item){
            const code = item.dataCode
            if(!this.$validatenull(code)){
                this.lr_loadDataSourceData(code)
                this.lr_loadDataSourceColNames(code)
            }

            item.dataValueKey = ''
        },
        handleAddCol(){
            this.config.list.push({
                id:this.$uuid(),
                moduleId:'',
                imgurl:''
            })
            
        },
        handleRemoveCol(index){
            if(this.config.list.length == 1){
                this.$message({
                    type: 'warning',
                    message: '必须保留一项'
                })  
            }
            else{
                this.config.list.splice(index,1)
            }
            
        }
    }
}
</script>

