<template>
    <div class="l-rblock" >
    <l-data-list 
        isApp
        :columns="columns"
        :isMore="!!data.moduleId" 
        :label="data.label"

        :data="dataSource"
         ></l-data-list>
    </div>
</template>
<script>
const apiScheme = window.$api.custmerForm.scheme
export default {
    props: ['data','isPreview'],
    data () {
        return {
        }
    },
    asyncComputed:{
      dataSource:{
        async get(){
            if(this.data.orderId && this.data.formVerison){
                const queryData = {
                    paginationInputDto:{
                        rows :this.data.limitRow == 1?this.data.maxRows:100000,
                        page : 1,
                        sidx : this.data.orderId
                    }
                }
                const data = (await this.$awaitWraper(apiScheme.getDataPage(this.data.moduleId,this.data.formVerison,queryData))) || {}
                return data.rows || []
            }
            else{
                return []
            }
        }
      }
    },
    computed:{
        columns(){
            const titleCol = this.data.titleOpt || {}
            titleCol.prop = this.data.titleKey
            titleCol.width = 70
            titleCol.align = 'left'

            const subTitleCol = this.data.subTitleOpt || {}
            subTitleCol.prop = this.data.subTitleKey
            subTitleCol.width = 30
            subTitleCol.align = 'right'

            return [titleCol,subTitleCol]
        }
    },
    methods:{
    }
}
</script>

