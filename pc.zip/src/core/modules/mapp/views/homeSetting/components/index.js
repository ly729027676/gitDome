export default [
    {
        title:'基础组件',
        list:[
            {
                type: 'app-databoard',
                label: '数据面板',
                icon: 'el-icon-price-tag',
                w: 12,
                h: 2,
                minW: 12,
                minH: 2,
                maxW: 12,
                maxH: 2,

                moduleId:'',
                list:[
                    {
                        id:'1',
                        name:'数据项',
                        dataCode:'',
                        dataValueKey:'',
                        moduleId:''
                    }
                ]
            }
            ,{
                type: 'app-datalist',
                label: '信息列表',
                icon: 'learun-icon-nav',

                w: 12,
                h: 3,
                minW: 12,
                minH: 3,
                maxW: 12,
                maxH: 3,

                viewForm:'',
                formVerison:'',
                orderId:'',
                limitRow:1,
                maxRows:5,

                titleKey:'',
                subTitleKey:'',
                titleOpt:{},
                subTitleOpt:{}
            }
            ,{
                type: 'app-imgswiper',
                label: '轮播图片',
                icon: 'learun-icon-pic',


                w: 12,
                h: 3,
                minW: 12,
                minH: 2,
                maxW: 12,
                maxH: 3,

                list:[
                    {
                        id:'1',
                        moduleId:'',
                        imgurl:''
                    }
                ]
            }
        ]
    }
    ,{
        title:'图表组件',
        list:[
            {
                type: 'app-chartbar',
                label: '柱状图',
                icon: 'el-icon-s-data',
                w: 12,
                h: 4,
                minW: 12,
                minH: 3,
                maxW: 12,
                maxH: 4,

                showBackground:false,
                backgroundColor:'',

                dataCode:'',
                dataType:'Y',
                YKey:'',
                XKey:'',

            }
            ,{
                type: 'app-chartline',
                label: '折线图',
                icon: 'learun-icon-histogram-m',
                w: 12,
                h: 4,
                minW: 12,
                minH: 3,
                maxW: 12,
                maxH: 4,

                dataCode:'',
                dataType:'Y',
                YKey:'',
                XKey:'',

            }
            ,{
                type: 'app-chartpie',
                label: '饼图',
                icon: 'el-icon-pie-chart',
                w: 12,
                h: 4,
                minW: 12,
                minH: 3,
                maxW: 12,
                maxH: 4,

                dataCode:'',
                nameKey:'',
                valueKey:'',

            }    
        ]
    }
    ,{
        title:'系统组件',
        list:[
            {
                type: 'app-mytask',
                label: '我的任务',
                icon: 'learun-icon-mine-m',

                w: 12,
                h: 2,
                minW: 12,
                minH: 2,
                maxW: 12,
                maxH: 2,
            }
            ,{
                type: 'app-mytasklist',
                label: '代办事项',
                icon: 'el-icon-s-order',

                w: 12,
                h: 3,
                minW: 12,
                minH: 3,
                maxW: 12,
                maxH: 3,
                maxRows:5
            }
        ]
    }
]