<template>
    <div>
        <el-form-item label="跳转功能">
            <l-tree-select :options="appTree"  v-model="config.moduleId" >
            </l-tree-select>
        </el-form-item>
    </div>
</template>
<script>
export default {
    inject: ["appDesign"],
    props: ['data'],
    data () {
        return {
        }
    },
    computed:{
        config(){
            return this.data
        },
        appTree(){
            return this.appDesign.appTree || []
        }
    },
    methods:{
    }
}
</script>

