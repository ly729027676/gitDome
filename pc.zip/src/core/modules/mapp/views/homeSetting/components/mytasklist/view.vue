<template>
<l-data-list
        isApp
        :isMore="true"

        :columns="columns"
        :label="data.label"
        :data="dataSource"
        ></l-data-list>
</template>
<script>
const api = window.$api.workflow.process
export default {
    props: ['data','isPreview'],
    data () {
        return {
            dataSource:[],
            columns:[
                {label:'标题',prop:'f_ProcessTitle',width:70},
                {label:'时间',prop:'f_CreateDate',width:30,dataType:'datetime',align:'right'}
            ]
        }
    },
    mounted(){
        this.loadData()
    },
    methods:{
        async loadData(){
            const queryData = {
                rows:this.data.maxRows,
                page:1,
                sidx:'F_CreateDate DESC'
            }
            // 加载代办任务
            const unCompletedData = await this.$awaitWraper(api.getUnCompletedMyPage(queryData))
            this.dataSource = unCompletedData.rows

        },
    }
}
</script>

