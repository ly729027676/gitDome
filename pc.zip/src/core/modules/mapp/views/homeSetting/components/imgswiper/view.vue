<template>
    <div class="l-img-swiper" >
        <el-carousel height="100%" >
            <el-carousel-item v-for="item in data.list" :key="item.id">
                <el-image
                    class="learun-image__error"
                    style="height:100%;width:100%;"
                    :src="item.imgurl?`${apiUrl}system/annexesfile/${item.imgurl}?token=${token}`:''"
                    fit="cover" >
                        <div slot="error" class="image-slot">
                            <i class="el-icon-picture-outline"></i>
                        </div>
                    </el-image>
            </el-carousel-item>
        </el-carousel>
    </div>
    
</template>
<script>
export default {
    props: ['data','isPreview'],
    data () {
        return {
        }
    },
    computed:{
    },

    mounted(){
    },
    
    methods:{
    }
}
</script>
<style lang="scss" scoped>
    .l-img-swiper{
        height: 100%;
        width: 100%;
        position: relative;
        overflow: hidden;
        border-radius: 8px;
        .el-carousel{
            height: 100%;
            width: 100%;
        }

        .el-carousel__item:nth-child(2n) {
            background-color: #99a9bf;
        }
            
        .el-carousel__item:nth-child(2n+1) {
            background-color: #d3dce6;
        }
    }
</style>

