<template>
    <l-data-panel 
        :label="data.label"
        isApp
        >
        <l-echarts ref="main" :option="option" ></l-echarts>
    </l-data-panel>
</template>
<script>
export default {
    props: ['data','isPreview','isShow'],
    data () {
        return {
            option:{
                xAxis: {
                    type: 'category',
                    data: []
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    data: [],
                    type: 'line'
                }]
            },
            timer:null
        }
    },
    watch:{
        isShow(){
            setTimeout(() => {
                this.$refs.main.updateChart()
            }, 100);
        },
        data:{
            handler(){
                this.refresh()
            },
            deep: true
        }        
        
    },
    mounted(){
        this.refresh()
    },
    methods:{
        async getOption(){
            if(this.data.dataType == 'Y'){
                this.option.xAxis = {
                    type: 'category',
                    data: []
                }
                this.option.yAxis = {
                    type: 'value'
                }
            }
            else{
                this.option.xAxis = {
                    type: 'value'
                }
                this.option.yAxis = {
                    type: 'category',
                    data: []
                }
            }
            
            // 加载数据
            if(this.data.dataCode){
                await this.lr_loadDataSourceData(this.data.dataCode,!!this.isPreview)
            }
           
            const data = this.lr_dataSourceData[this.data.dataCode] || []

            if(this.data.XKey && this.data.YKey){
                const xList = []
                const yList = []
                
                data.forEach(item=>{
                    xList.push(item[this.data.XKey])
                    yList.push(item[this.data.YKey])
                })

                if(this.data.dataType == 'Y'){
                    this.option.series[0].data = yList
                    this.option.xAxis.data = xList
                }
                else{
                    this.option.series[0].data = xList
                    this.option.yAxis.data = yList
                }

            }
            return this.option
        },
        refresh(){
            if(this.timer == null){
                this.timer = setTimeout(async ()=>{
                    const option = await this.getOption()
                    this.$refs.main.updateChart(option)
                    this.timer = null
                },100)
            }
        }
    }
}
</script>

