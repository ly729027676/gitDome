import Vue from 'vue'
const msg = {
    namespaced: true,
    state:{
        map:{}
    },
    actions:{
    },
    mutations:{
        add: (state, payload) => {
            if(!state.map[payload.f_SendUserId]){
                Vue.set(state.map,payload.f_SendUserId,[])
            }
            state.map[payload.f_SendUserId].push(payload)

        }
    }
};

export default msg;