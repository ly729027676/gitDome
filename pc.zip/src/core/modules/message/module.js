export default {
    name: '消息模块',
    code: 'message',
    version: '1.0.0',
    description: '消息注册，消息策略'
  }