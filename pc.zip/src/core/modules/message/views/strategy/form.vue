<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="80px" >
            <el-col :span="24">
                <el-form-item label="名称" prop="f_StrategyName">
                    <el-input v-model="formData.f_StrategyName"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="编码" prop="f_StrategyCode">
                    <el-input v-model="formData.f_StrategyCode"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="类型" prop="f_MessageType">
                     <l-checkbox :options="options" v-model="formData.f_MessageType" ></l-checkbox>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="说明" prop="f_Description">
                    <el-input type="textarea" v-model="formData.f_Description"></el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            formData:{
                f_StrategyName:'',
                f_StrategyCode:'',
                f_MessageType:'',
                f_Description:''
            },
            rules: {
                f_StrategyName: [
                    { required: true, message: '请输入名称' }
                ],
                f_StrategyCode: [
                    { required: true, message: '请输入编码' },
                    { validator: this.lr_existDbFiled,tableName:'lr_ms_strategyinfo',keyName:'f_Id',trigger: 'null'}
                ],
            },
            options:[
                {value:'1',label:'邮件'},
                {value:'2',label:'微信'},
                {value:'3',label:'短信'},
                {value:'4',label:'站内消息'}
            ],
            testLoading:false
        };
    },
    computed:{
    },
    created () {
    },
    methods:{
        resetForm(){
            this.formData.f_Id = ''
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(){
            return this.$formValidateWraper(this.$refs.form)
        },
        setForm(data){
            this.formData = this.$deepClone(data)
        },
        getForm(){
            return this.$deepClone(this.formData)
        }
    }
}
</script>