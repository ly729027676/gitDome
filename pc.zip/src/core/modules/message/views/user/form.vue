<template>
    <div class="l-from-body" >
        <el-form :model="formData" :rules="rules" size="mini"  ref="form" label-width="88px" >
            <el-col :span="12">
                <el-form-item label="用户编码" prop="f_Code">
                    <el-input v-model="formData.f_Code"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="用户名称" prop="f_Name">
                    <el-input v-model="formData.f_Name"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="图标" prop="f_Icon">
                    <l-input-icon :iconList="lr_icons"  v-model="formData.f_Icon" >
                    </l-input-icon>
                </el-form-item>
            </el-col>
            <el-col :span="12">
                <el-form-item label="颜色"  prop="f_Colour" >
                    <l-input-color v-model="formData.f_Colour"
                            placeholder="请输入"></l-input-color>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="pc链接" prop="f_Url">
                    <el-input v-model="formData.f_Url"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="移动连接" prop="f_AppUrl">
                    <el-input v-model="formData.f_AppUrl"></el-input>
                </el-form-item>
            </el-col>
            <el-col :span="24">
                <el-form-item label="说明" prop="f_Description">
                    <el-input type="textarea" v-model="formData.f_Description"></el-input>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>
<script>
export default {
    data(){
        return {
            formData:{
                f_Code:'',
                f_Name:'',
                f_Icon:'',
                f_Colour:'#409eff',
                f_Url:'',
                f_AppUrl:'',
                f_Description:''
            },
            rules: {
                f_Code: [
                    { required: true, message: '请输入编码' },
                    { validator: this.lr_existDbFiled,keyValue:() => { return this.formData.f_Id },tableName:'lr_im_sysuser',keyName:'f_Id',trigger: 'null'}
                ],
                f_Name: [
                    { required: true, message: '请输入名称' }
                ],
                f_Icon: [
                    { required: true, message: '请选择图标' }
                ],
                f_Colour: [
                    { required: true, message: '请选择颜色' }
                ]
            }
        };
    },
    computed:{
    },
    created () {
    },
    methods:{
        resetForm(){
            this.formData.f_Id = '';
            this.$refs.form && this.$refs.form.resetFields();
        },
        // 校验表单
        validateForm(){
            return this.$formValidateWraper(this.$refs.form)
        },
        setForm(data){
            this.formData = this.$deepClone(data)
        },
        getForm(){
            let formData = this.$deepClone(this.formData)
            return formData
        }
    }
}
</script>