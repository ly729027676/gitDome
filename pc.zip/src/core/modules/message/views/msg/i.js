export default {
    isNotMenu:true
}