export default url => {
    const crud = window.$crud(url)
    crud.addList = (data) => window.$axios({
        url: `${url}s`,
        method: 'post',
        data
    })

    crud.updateState = (id) => window.$axios({
        url: `${url}/state/${id}`,
        method: 'put'
    })
    return {
        ...crud
    }
}