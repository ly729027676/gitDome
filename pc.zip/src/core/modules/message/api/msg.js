export default url => {
    const crud = window.$crud(url)

    const getSysPage = (params) => window.$axios({
        url: `${url}/sys/page`,
        method: 'get',
        params
    })

    const getSysNum = () => window.$axios({
        url: `${url}/sys/num`,
        method: 'get'
    })

    const clear= () => window.$axios({
        url: `${url}/clear`,
        method: 'delete'
    })

    const virtualDelete = (ids) => window.$axios({
        url: `${url}/virtual/${ids}`,
        method: 'delete'
    })

    const read = (id) => window.$axios({
        url: `${url}/read/${id}`,
        method: 'put'
    })

    return {
        ...crud,
        getSysPage,
        getSysNum,
        clear,
        virtualDelete,
        read
    }
}