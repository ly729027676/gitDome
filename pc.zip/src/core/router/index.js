/**
 * 全站路由配置
 *
 * meta参数说明
 * keepAlive是否缓冲页面
 * isTab是否加入到tag导航
 * isAuth是否需要授权
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
import { rootUrl } from '@/config/env'

import PageRouter from './page'
import lrRouter from './lr-router'
import i18n from '../lang' // Internationalization


// 视图路由
const routes = []


const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
Vue.use(VueRouter)

let Router

//创建路由
export const createRouter = () => new VueRouter({
  mode: 'history',
  base: rootUrl,
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      if (from.meta.keepAlive) {
        from.meta.savedPosition = document.body.scrollTop
      }
      return {
        x: 0,
        y: to.meta.savedPosition || 0
      }
    }
  },
  routes: [...PageRouter, ...routes],
})

export default {
  use:({views,store})=>{
    routes.push(...views)
    Router = createRouter()
    lrRouter.install(Vue, {
      router: Router,
      store: store,
      i18n: i18n,
      keepAlive: false,
    })
    return Router
  }
}

