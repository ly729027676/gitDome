
let RouterPlugin = function () {
  this.$router = null;
  this.$store = null;
}
RouterPlugin.install = function (vue, option = {}) {
  this.$router = option.router;
  this.$store = option.store;
  this.$vue = new vue({ i18n: option.i18n });
  function isURL (s) {
    if (s.includes('html')) return true;
    return /^http[s]?:\/\/.*/.test(s)
  }
  function objToform (obj) {
    let result = [];
    Object.keys(obj).forEach(ele => {
      result.push(`${ele}=${obj[ele]}`);
    })
    return result.join('&');
  }
  this.$router.$lrRouter = {
    //全局配置
    routerList: [],
    safe: this,
    // 设置标题
    setTitle: (title) => {
      const defaultTitle = this.$store.getters.appConfig.title;
      title = title ? `${this.$vue.$t(title)} - ${defaultTitle}` : defaultTitle;
      document.title = title;


      //console.log(this.$vue,'vue')
    },
    closeTag: (value) => {
      let tag = value || this.$store.getters.tag;
      if (typeof value === 'string') {
        tag = this.$store.getters.tagList.filter(ele => ele.value === value)[0]
      }
      this.$store.commit('DEL_TAG', tag)
    },
    generateTitle: (title) => {
      return this.$vue.$t(title);
    },
    // 路由跳转
    goto(to){
      if(to.f_Target == 'view'){
        if(isURL(to.f_UrlAddress || '')){
          this.safe.$router.push({
            path: this.getPath({
              name: to.f_FullName,
              src: to.f_UrlAddress
            }),
            query: {
              src:to.f_UrlAddress
            }
          })
        }
        else this.safe.$router.push({
          path: this.getPath({
            name: to.f_FullName,
            src: to.f_UrlAddress
          })
        })
      }
      else if(to.f_Target == 'custmerForm' || to.f_Target == 'desktop0' || to.f_Target == 'desktop1'){
        this.safe.$router.push({
          path: this.getPath({
            target:to.f_Target,
            name: to.f_FullName,
            src: to.f_UrlAddress
          }),
          query: {
            src:to.f_UrlAddress,
            close:to.f_Target == 'desktop1'?false:undefined
          }
        })
      }
    },

    // 处理路由
    getPath: function (params = {}, meta = {}) {
      let { src,target } = params;
      let result = src || '/';
      if (isURL(src)) {
        result = `/myiframe/urlPath?${objToform(Object.assign(meta, params))}`;
      }
      else if(target == 'custmerForm'){
        result = `/mycustmerform/module?${objToform(Object.assign(meta, params))}`
      }
      else if(target == 'desktop1' || target == 'desktop0' ){
        result = `/myDesktopHome/module?${objToform(Object.assign(meta, params))}`
      }
      return result;
    },
    //正则处理路由
    vaildPath: function (list, path) {
      let result = false;
      list.forEach(ele => {
        if (new RegExp("^" + ele + ".*", "g").test(path)) {
          result = true
        }

      })
      return result;
    },
    //设置路由值
    getValue: function (route) {
      console.log(route,'--------------*')
      let value = "";
      if (route.query.src) {
        value = route.query.src;
      } else {
        value = route.path;
      }
      return value;
    }
  }
}
export default RouterPlugin