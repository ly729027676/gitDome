import Layout from '../../page/index'

export default [{
    path: '/login',
    name: '登录页',
    component: () => import( /* webpackChunkName: "pagelogin" */ '../../page/login/index'),
    meta: {
        keepAlive: true,
        isTab: false,
        isAuth: false
    }
},
{
    path: '/404',
    component: () =>import( /* webpackChunkName: "page404" */ '../../components/error-page/404'),
      name: '404',
      meta: {
          keepAlive: true,
          isTab: false,
          isAuth: false
    }
},
{
    path: '/403',
    component: () => import( /* webpackChunkName: "page403" */ '../../components/error-page/403'),
    name: '403',
    meta: {
        keepAlive: true,
        isTab: false,
        isAuth: false
    }
},
{
    path: '/500',
    component: () =>import( /* webpackChunkName: "page500" */ '../../components/error-page/500'),
    name: '500',
    meta: {
        keepAlive: true,
        isTab: false,
        isAuth: false
    }
},
{
    path: '/',
    name: '主页',
    redirect: '/system/home'
},
{
    path: '/myiframe',
    component: Layout,
    redirect: '/myiframe',
    children: [{
        path: ":routerPath",
        name: 'iframe',
        component: () =>import( /* webpackChunkName: "pageiframe" */ '../../components/iframe/main'),
        props: true
    }]
},
{
    path: '/mycustmerForm',
    component: Layout,
    redirect: '/mycustmerForm',
    children: [{
        path: ":routerPath",
        name: 'mycustmerForm',
        component: () =>import( /* webpackChunkName: "mycustmerForm" */ `../../modules/custmerForm/views/module/custmerDynamic`),
        props: true
    }]
},
{
    path: '/myDesktopHome',
    component: Layout,
    redirect: '/myDesktopHome',
    children: [{
        path: ":routerPath",
        name: 'myDesktopHome',
        component: () =>import( /* webpackChunkName: "mycustmerForm" */ `../../modules/desktop/views/setting/homeDynamic`),
        props: true
    }]
},
{
    path: '*',
    redirect: '/404'
},
]