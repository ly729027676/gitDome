export default {
  namespaced: true,
  state: {
    // 系统信息
    system:{},
    modules:[],
    isFirstLoad:true,
    isCollapse: false,
    isFullScren: false,
    screen: -1,
    
    pageAuth:{

    },

    request:[] // 用来保存最近20次请求参数和请求地址
  },
  actions: {
    init({ commit }, { system } ) {
      commit('init', system)
    },

    setPageAuth({ commit },data){
      commit('setPageAuth', data)
    },
    addRequest({ commit },data){
      commit('SET_REQUEST', data)
    }
  },
  mutations: {
    init:(state,system)=>{
      system.webconfig.language.type = window.$getStore({ name: 'language' }) || system.webconfig.language.type
      system.webconfig.theme.nav = window.$getStore({ name: 'theme-nav' }) || system.webconfig.theme.nav
      state.system = system.webconfig
      state.modules = system.modules
    },
    setPageAuth:(state,data)=>{
      state.pageAuth = data
    },

    SET_LANGUAGE: (state, language) => {
      state.system.language.type = language
      window.$setStore({
        name: 'language',
        content: language
      })
    },
    SET_THEME_NAV: (state, themeNav) => {
      state.system.theme.nav = themeNav
      window.$setStore({
        name: 'theme-nav',
        content: themeNav
      })
    },
    SET_COLLAPSE: (state) => {
      state.isCollapse = !state.isCollapse;
    },
    SET_FULLSCREN: (state) => {
      state.isFullScren = !state.isFullScren;
    },
    SET_SCREEN: (state,screen) => {
      state.screen = screen;
    },
    SET_ISFIRSTLOAD: (state,isFirstLoad) => {
      state.isFirstLoad = isFirstLoad;
    },

    SET_REQUEST:(state,data)=>{
      if(state.request.length == 20){
        state.request.splice(0,1)
      }
      state.request.push(data)
    }
  }
}