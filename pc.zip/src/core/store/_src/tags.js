import { diff } from '../../util/util'
const tagObj = {
  label: '', //标题名称
  value: '', //标题的路径
  params: '', //标题的路径参数
  query: '', //标题的参数
  meta: {},//额外参数
  group: [], //分组
}
const navs = {
  state: {
    tagList: window.$getStore({ name: 'tagList' }) || [],
    tag: window.$getStore({ name: 'tag' }) || tagObj,
    tagWel: {},
    dynamicHome:undefined,
    loading:true
  },
  actions: {

  },
  mutations: {
    SET_TAGWEL(state,tagWel){
      state.tagWel = tagWel
    },
    ADD_TAG: (state, action) => {
      state.tag = action;
      window.$setStore({ name: 'tag', content: state.tag })
      if (state.tagList.some(ele => diff(ele, action))) return
      state.tagList.push(action)
      window.$setStore({ name: 'tagList', content: state.tagList })
    },
    DEL_TAG: (state, action) => {
      state.tagList = state.tagList.filter(item => {
        return !diff(item, action);
      })
      window.$setStore({ name: 'tagList', content: state.tagList })
    },
    DEL_ALL_TAG: (state) => {
      state.tagList = []
      window.$setStore({ name: 'tagList', content: state.tagList })
    },
    DEL_ALL_TAG_CLOSED: (state) => { 
      state.tagList = state.tagList.filter(item => {
        if (item.meta.close == false || item.query.close == "false") {
          return true;
        }
      })
      window.$setStore({ name: 'tagList', content: state.tagList })
    },
    DEL_TAG_OTHER: (state) => {
      state.tagList = state.tagList.filter(item => {
        if (item.value === state.tag.value) {
          return true;
        } else if (item.meta.close == false || item.query.close == "false") {
          return true;
        }
      })
      window.$setStore({ name: 'tagList', content: state.tagList })
    },
    SET_TAG_LIST (state, tagList) {
      state.tagList = tagList;
      window.$setStore({ name: 'tagList', content: state.tagList })
    },
    SET_TAG_LOADING(state,loading){
      state.loading = loading
    },
    SET_TAG_DYNAMICHOME(state,dynamicHome){
      state.dynamicHome = dynamicHome
    },
  }
}
export default navs