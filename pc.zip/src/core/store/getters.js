
function get_menuTree(data,menuTree){
  data = data || [];
  var res = [];
  data.forEach(item => {
      var point = {
          id:item.f_ModuleId,
          label:item.f_FullName,
          icon:item.f_Icon
      };
      if(menuTree[item.f_ModuleId] && menuTree[item.f_ModuleId].length > 0){
          point.children = get_menuTree(menuTree[item.f_ModuleId],menuTree);
      }

      res.push(point);
  });
  return res;
}
function get_menuExpandTree(data,menuTree){
  data = data || [];
  var res = [];
  data.forEach(item => {
      if(item.f_Target == 'expand'){
        var point = {
            id:item.f_ModuleId,
            value:item.f_ModuleId,
            label:item.f_FullName,
            icon:item.f_Icon
        };
        if(menuTree[item.f_ModuleId] && menuTree[item.f_ModuleId].length > 0){
            point.children = get_menuExpandTree(menuTree[item.f_ModuleId],menuTree);
        }

        res.push(point);
      }
  });
  return res;
}

const getters = {
  appConfig:state => state.app.system,
  isCollapse: state => state.app.isCollapse,
  isFullScren: state => state.app.isFullScren,
  screen:state => state.app.screen,

  tag: state => state.tags.tag,
  tagList: state => state.tags.tagList,
  tagWel: state => state.tags.tagWel,
  tagLoading:state =>state.tags.loading,
  tagDynamicHome: state => state.tags.dynamicHome,

  token: state => state.organization.user.token,
  loginInfo:state => state.organization.user.loginInfo,

  menu: state => state.system.module.menu,
  modules: state=> state.system.module.list,
  modulesGroup:state => state.system.module.group,
  modulesTree: state =>{
    return get_menuTree(state.system.module.group[0],state.system.module.group);
  },
  modulesExpandTree: state =>{
    return get_menuExpandTree(state.system.module.group[0],state.system.module.group);
  },

  lr_pageAuthInfo:state => state.app.pageAuth
}
export default getters