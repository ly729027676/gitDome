import Vue from 'vue'
import Vuex from 'vuex'
import tags from './_src/tags'
import app from './_src/app'
import getters from './getters'

Vue.use(Vuex)
// 状态实例
let store
// 状态配置项
let storeOptions = {
  modules: {
    tags,
    app
  },
  getters
}

export default () => {
  store = new Vuex.Store(storeOptions)
}

export { store, storeOptions }