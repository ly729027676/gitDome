const dbtype = [
    'string',
    'text',
    'int',
    'decimal',
    'DateTime',
    'bool',
    'long',
    'short',
    'double',
    'float',
    'TimeSpan'
]

export default dbtype