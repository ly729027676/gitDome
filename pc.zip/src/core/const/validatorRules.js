/* eslint-disable */
const validatorRules = [
    {
        name:'数字',
        reg:'/^-?[0-9]+$/'
    },
    {
        name:'英文字符或数字',
        reg:'/^[a-z,A-Z,0-9]+$/'
    },
    {
        name:'英文字符',
        reg:'/^[a-z,A-Z]+$/'
    },
    {
        name:'中文',
        reg:'/^[\u0391-\uFFE5]+$/'
    },
    {
        name:'邮箱',
        reg:'/^\w{3,}@\w+(\.\w+)+$/'
    },
    {
        name:'电话号',
        reg:'/^0\d{2,3}-?\d{7,8}$/'
    },
    {
        name:'手机号',
        reg:'/^1[3456789]\d{9}$/'
    },
    {
        name:'电话/手机号',
        reg:'/^1[3456789]\d{9}$|^0\d{2,3}-?\d{7,8}$/'
    },
    {
        name:'邮编',
        reg:/^\d{6}$/
    },
    {
        name:'身份证',
        reg:/^\d{15}(\d{2}[A-Za-z0-9;])?$/
    }
];

export default validatorRules;