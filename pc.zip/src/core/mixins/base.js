import { mapGetters } from "vuex"
import iconList from '../const/icons'
import validatorRules from '../const/validatorRules'
import chunkedUpload from '../util/chunkedUpload'
import dbtype from '../const/dbtype'

/**
 * 基础数据方法
 * 以下定义的所有方法、计算属性，均会被挂载到所有 .vue 页面的 this 上
 */
export default function () {
    return{
        props:{
            isWfForm:{
                type:Boolean,
                default:false
            },
            authFieldsMap:{
                type:Object,
                default:()=>{
                    return {}
                }
            },
            requiredMap:{
                type:Object,
                default:()=>{
                    return {}
                }
            },
        },

        data(){
            return {
                lr_dbFields:{},
                lr_pageLoadedCompanyIds:{},
                lr_pageLoadedUserName:{},

                lr_isPage:false,
                lr_isCustmerFormPage:false,
                lr_isAuth:true,
                lr_loadPage:true,


                dataSourceCache:{} // 数据源缓存
            }
        },
        computed:{
            lr_icons(){
                return iconList
            },
            lr_dbtype(){
                console.log('lr_dbtype')
                return dbtype
            },
            lr_validatorRules(){
                return validatorRules
            },
            // 登录者信息
            ...mapGetters(["loginInfo","appConfig","lr_pageAuthInfo","token"]),
            // 
            lr_dblinkList(){
                let list = [
                    {
                        f_DBName:'lrsystemdb',
                        f_DBAlias:'系统数据库',
                        f_Description:'系统数据库,appsettings中设置,无法删除'
                    }
                ]
                return list.concat(this.$store.state.data.dblink.list || [])
            },
            lr_dblinkTree(){
                let list = this.lr_dblinkList;
                let res = [];
                let map = {};
                list.forEach(item =>{
                    let point = {};
                    if(item.f_DBName == 'lrsystemdb'){
                        point = {
                            id:'1',
                            label:'常用数据库',
                            children:[
                                {
                                    id:item.f_DBName,
                                    label:item.f_DBAlias,
                                    icon:'fa fa-database'
                                }
                            ]
                        }
                        res.push(point);
                    }
                    else{
                        if(!map[item.f_ServerAddress]){
                            point.id = item.f_ServerAddress;
                            point.label = item.f_ServerAddress;

                            map[item.f_ServerAddress] = [];
                            point.children = map[item.f_ServerAddress];
                            res.push(point);
                        }

                        let cpoint = {
                            id:item.f_DBName,
                            label:'('+ item.f_DBName +')'+item.f_DBAlias,
                            icon:'fa fa-database'
                        };

                        map[item.f_ServerAddress].push(cpoint);

                    }
                })
                return res
            },
            lr_dblinkLazyTree(){
                let list = this.lr_dblinkList;
                let res = [];
                let map = {};
                list.forEach(item =>{
                    let point = {};
                    if(item.f_DBName == 'lrsystemdb'){
                        point = {
                            id:'1',
                            label:'常用数据库',
                            children:[
                                {
                                    id:item.f_DBName,
                                    label:item.f_DBAlias,
                                    icon:'fa fa-database'
                                }
                            ]
                        }
                        res.push(point);
                    }
                    else{
                        if(!map[item.f_ServerAddress]){
                            point.id = item.f_ServerAddress;
                            point.label = item.f_ServerAddress;

                            map[item.f_ServerAddress] = [];
                            point.children = map[item.f_ServerAddress];
                            res.push(point);
                        }

                        let cpoint = {
                            id:item.f_DBName,
                            label:'('+ item.f_DBName +')'+item.f_DBAlias,
                            icon:'fa fa-database'
                        };

                        map[item.f_ServerAddress].push(cpoint);

                    }
                })
                return res
            },
            // 数据字典
            lr_dataItem(){
                return this.$store.state.data.dataItem.details
            },
            lr_dataItemClassifys(){
                const list = this.$store.state.data.dataItem.classifys
                const res = list.filter(item => {
                    return item.f_EnabledMark == 1
                })
                return res
            },
            lr_dataItemClassifysTree(){
                return this.$toTree(this.lr_dataItemClassifys,"f_ItemId","f_ParentId","f_ItemCode","f_ItemName")
            },

            // 数据源列表
            lr_dataSource(){
                return this.$store.state.data.dbsource.list
            },
            lr_dataSourceCol(){
                return this.$store.state.data.dbsource.colNameGroup
            },
            lr_dataSourceData(){
                return this.$store.state.data.dbsource.dataGroup
            },
            lr_dataSourceDataByParamter(){
                
                return this.$store.state.data.dbsource.dataByParamterGroup
            },
            //单据编码列表
            lr_codeList(){
                return this.$store.state.data.coderule.list
            },

            // 行政区域信息
            lr_areas(){
                return this.$store.state.data.area.map
            },
            

            // 公司信息
            lr_companyList(){
                return this.$store.state.organization.company.list
            },
            lr_companyTree(){
                return this.$toTree(this.lr_companyList,"f_CompanyId","f_ParentId","f_CompanyId","f_FullName")
            },
            // 部门数据
            lr_departments(){
                return this.$store.state.organization.department.map
            },
            lr_department(){
                return this.$store.state.organization.department.one
            },
            // 岗位信息
            lr_posts(){
                return this.$store.state.organization.post.map
            },
            lr_post(){
                return this.$store.state.organization.post.one
            },
            // 角色信息
            lr_role(){
                return this.$store.state.organization.role.map
            },
            lr_roles(){
                return this.$store.state.organization.role.list
            },
            // 人员
            lr_users(){
                return this.$store.state.organization.user.map
            }
        },
        created () {
            if(this.lr_isPage && !this.lr_isCustmerFormPage){
                this.lr_loadPageAuth() // 加载页面权限
            }
            else{
                this.lr_loadPage = false
            }

            if(this.isWfForm){ // 设置流程字段必填项
                for(let key in this.requiredMap){
                    if(this.requiredMap[key] == true){
                        if(!this.rules[key]){
                            this.rules[key] = [{ required: true, message: '请输入' }]
                        }
                        else if(this.rules[key].findIndex(t=>t.required == true) == -1){
                            this.rules[key].push({ required: true, message: '请输入' })
                        }
                    }
                    else if(this.requiredMap[key] == false && this.rules[key].findIndex(t=>t.required == true) > -1){
                        this.rules[key].splice( this.rules[key].findIndex(t=>t.required == true),1)
                    }
                }
            }

        },
        methods:{
            // 基础方法
            lr_dateFormat(date,format = 'yyyy-MM-dd hh:mm:ss'){
                return this.$formatDate(date,format);
            },
            lr_displayTimerange(value,format = 'yyyy-MM-dd hh:mm:ss'){
                if(!this.$validatenull(value))
                {
                    let valueList = value.split(',')
                    return `${this.$formatDate(valueList[0],format)}-${this.$formatDate(valueList[1],format)}`
                }
                else{
                    return ''
                }
            },
            lr_formatValue(value,list,valueKey,labelKey){
                list = list || []
                valueKey = valueKey || 'value'
                labelKey = labelKey || 'label'

                if(typeof value == 'string'){
                    let valueList = value.split(',')
                    const lableList = []
                    valueList.forEach(valueItem=>{
                        let item = list.find(t=>t[valueKey] == valueItem)
                        if(item && item[labelKey]){
                            lableList.push(item[labelKey])
                        }
                    })
                    return String(lableList)
                }
                else{
                    let item = list.find(t=>t[valueKey] == value)
                    if(item){
                        return item[labelKey] || ''
                    }
                    else{
                        return ''
                    }
                }
            },

            lr_tableColumnsByToLabel(tableColumns){
                return tableColumns.filter(t=>['icon','rate','switch','slider','color','file','img'].includes(t.dataType))
            },
        
            // 数据库
            lr_loadDblink(isCache = true){
                return this.$store.dispatch("data/dblink/load",isCache)
            },

            // 表单校验
            lr_existDbFiled(rule, value, callback){
                const params = {}
                if(typeof rule.keyValue == 'function'){
                    params.keyValue= rule.keyValue()
                }
                else{
                    params.keyValue = this.formData[rule.keyName]
                }

                if(rule.isEditIgnore && !this.$validatenull(params.keyValue)){
                    callback()
                    return
                }
               

                params.tableName= rule.tableName
                params.keyName = rule.keyName

                const fileds = rule.filedsJson ||  {}
                fileds[rule.fieldName || rule.field] = value
                params.filedsJson = JSON.stringify(fileds)   

                console.log(rule)
                
                window.$api.data.dbTable.existFiled(params).then(res => {
                    if(res.data.code == 200){
                        if(res.data.data){
                            callback()
                        }
                        else{
                            callback(new Error('数值重复'))
                        }
                    }
                    else{
                        callback(new Error(`检测接口异常-${res.data.info}`))
                    }
                })
            },

            // 数据字典
            lr_loadDataItem(code,isCache = true){
                return this.$store.dispatch("data/dataItem/loadDetails",{code,isCache})
            },
            lr_dataItemName(data,value){
                data = data || []
                if(data.length == 0){
                    return ''
                }

                value = (value || '') + ''
                const valueList = value.split(',')
                const list = []
                valueList.forEach(vitem => {
                    const item = data.find(item=>{ return item.f_ItemValue == vitem })
                    if(item){
                        list.push(item.f_ItemName)
                    }
                })
                return String(list)
            },
            lr_dataItemTree(data){
                data = data || []
                return this.$toTree(data.filter(t => {
                    return t.f_EnabledMark == 1
                }),"f_ItemDetailId","f_ParentId","f_ItemValue","f_ItemName")
            },
            lr_dataItemOptions(data){
                data = data || []
                return data.filter(t => {
                    return t.f_EnabledMark == 1
                }).map(t=>{return {...t,value:t.f_ItemValue,label:t.f_ItemName}})
            },
            lr_loadDataItemClassifys(isCache = true){
                return this.$store.dispatch("data/dataItem/loadClassifys",isCache)
            },


            // 数据源
            lr_loadDataSourceList(isCache = true){
                return this.$store.dispatch("data/dbsource/loadList",isCache)
            },
            lr_loadDataSourceData(code,isCache = true){
                return this.$store.dispatch("data/dbsource/loadDataList",{code,isCache})
            },
            lr_loadDataSourceDataByParamter(code,param,isCache = true){
                return this.$store.dispatch("data/dbsource/loadDataListByParamter",{code,param,isCache})
            },
            
            lr_DataSourceOptions(data,valueKey,labelKey){
                const list = data || []
                return list.map(t=>{return {...t,value:t[valueKey],label:t[labelKey]}})
            },
            lr_DataSourceTree(data,id,pid,valueKey,labelKey){
                const list = data || []
                const res = this.$toTree(list,id,pid,valueKey,labelKey)
                return res
            },
            lr_dataSourceName(data,value,valueKey,labelKey){
                data = data || []
                if(data.length == 0){
                    return ''
                }

                value = (value || '') + ''

                if(this.dataSourceCache[value]){
                    return this.dataSourceCache[value] 
                }


                const valueList = value.split(',')
                const list = []
                
                valueList.forEach(vitem => {
                    const item = data.find(item=>{ return item[valueKey] == vitem })
                    if(item){
                        list.push(item[labelKey])
                    }
                })
                this.dataSourceCache[value] = String(list)

                return this.dataSourceCache[value] 
            },
            lr_dataSourceName2(code,value,valueKey,labelKey){
                value = (value || '') + ''
                if(this.dataSourceCache[value]){
                    return this.dataSourceCache[value] 
                }
                const valueList = value.split(',')
                const list = []

                const data = this.lr_dataSourceData[code] || []
                valueList.forEach(vitem => {
                    const item = data.find(item=>{ return item[valueKey] == vitem })
                    if(item){
                        list.push(item[labelKey])
                    }
                })
                this.dataSourceCache[value] = String(list)

                return this.dataSourceCache[value] 
            },

            lr_loadDataSourceColNames(code,isCache = true){
                return this.$store.dispatch("data/dbsource/loadDataCol",{code,isCache})
            },

            

            // 单据编码
            lr_getCode(code){
                const apiCoderule= window.$api.data.coderule
                return this.$awaitWraper(apiCoderule.get(code))
            },
            lr_loadCodeList(isCache = true){
                return this.$store.dispatch("data/coderule/loadList",isCache)
            },

            // 公司信息
            lr_loadCompanys(isCache = true){
                return this.$store.dispatch("organization/company/load",isCache)
            },
            lr_loadCompanyName(values){
                if(this.$validatenull(values)){
                    return ''
                }
                const valueList = values.split(',')
                const names= []
                valueList.forEach(value => {
                    const item = this.lr_companyList.find(item=>{ return item.f_CompanyId == value })
                    if(item && item.f_FullName ){
                        names.push(item.f_FullName )
                    }
                })
                return String(names)
            },

            // 部门方法
            lr_loadDepartments(companyId,isCache = true){
                return this.$store.dispatch("organization/department/loadList",{companyId,isCache})
            },
            lr_loadDepartment(departmentId,isNotTime = false){
                return this.$store.dispatch("organization/department/load",{departmentId,isNotTime})
            },
            lr_departmentTree(data){
                data = data || []
                return this.$toTree(data,"f_DepartmentId","f_ParentId","f_DepartmentId","f_FullName")
            },
            lr_departmentName(list,value){
                list = list || []
                let item = list.find(item=>{ return item.f_DepartmentId == value }) || {}
                return item.f_FullName || ''
            },
            lr_departmentNameByOne(values,labelKey){
                if(this.$validatenull(values)){
                    return ''
                }
                const valueList = values.split(',')
                const names= []
                valueList.forEach(value => {
                    this.lr_loadDepartment(value)
                    const item = this.lr_department[value]
                    if(item && item[labelKey || 'f_FullName']){
                        names.push(item[labelKey || 'f_FullName'])
                    }
                })
                return String(names)
            },

            // 岗位
            lr_loadPosts(companyId,isCache = true){
                return this.$store.dispatch("organization/post/getList",{companyId,isCache})
            },
            lr_postTree(data){
                return this.$toTree(data,"f_PostId","f_ParentId","f_PostId","f_Name")
            },
            lr_loadPost(postIds,isCache = true){
                postIds = postIds || ''
                return this.$store.dispatch("organization/post/load",{postIds:postIds.split(','),isCache})
            },

            lr_postName(postIds){
                if(this.$validatenull(postIds)){
                    return ''
                }
                this.lr_loadPost(postIds)
                const postIdList = postIds.split(',')
                
                const names= []
                postIdList.forEach(postId => {
                    if(this.$store.state.organization.post.one[postId]){
                        names.push(this.$store.state.organization.post.one[postId].f_Name)
                    }
                })
                return String(names)    
            },


            // 角色
            lr_loadRole(roleId,isCache = true){
                return this.$store.dispatch("organization/role/load",{roleId,isCache})
            },
            lr_loadRoles(isCache = true){
                return this.$store.dispatch("organization/role/loadList",isCache)
            },
            lr_roleOptions(data){
                data = data || []
                return data.filter(t=>t.f_DeleteMark == 0 && t.f_EnabledMark == 1).map(t=>{ return {...t,label:t.f_FullName,value:t.f_RoleId} })
            },
            lr_roleName(roleIds){
                if(this.$validatenull(roleIds)){
                    return ''
                }
                this.lr_loadRoles()
                const roleIdList = roleIds.split(',')
                const list = this.$store.state.organization.role.list.filter(t=>roleIdList.indexOf(t.f_RoleId) != -1 )
                return String(list.map(t=>t.f_FullName))
            },

            // 用户信息
            lr_loadUsers(userIds,isCache = true){
                userIds = userIds || ''
                const userIdList = userIds.split(',')
                this.$store.dispatch("organization/user/load",{userIds:userIdList,isCache})
            },
            lr_userName(userIds){
                if(this.$validatenull(userIds)){
                    return ''
                }
                this.lr_loadUsers(userIds)
                const userIdList = userIds.split(',')
                const names= []
                userIdList.forEach(userId => {
                    if(this.lr_users[userId]){
                        names.push(this.lr_users[userId].f_RealName)
                    }
                })
                return String(names)                
            },
            async lr_getUserPage(params){
                const apiUser = window.$api.organization.user
                params.enabledMark = 1
                const data = await this.$awaitWraper(apiUser.getPage(params))
                if(data){
                    data.rows.forEach(item=>{
                        this.$store.dispatch("organization/user/update",item)
                    })
                }

                return data
            },

            // 行政区域数据
            lr_loadAreas(pid,isCache = true){
                return this.$store.dispatch("data/area/load",{pid,isCache})
            },
            lr_areasName(value){
                if(this.$validatenull(value)){
                    return ''
                }
                const areaList = value.split(',')
                if(areaList.length == 3){
                    const names= []
                    const one = this.lr_areas['0'] || []
                    const one1 = one.find(t=>t.f_AreaCode == areaList[0])
                    if(one1){
                        names.push(one1.f_AreaName)
                    }
                    const two = this.lr_areas[areaList[0]] || []
                    const two2 = two.find(t=>t.f_AreaCode == areaList[1])
                    if(two2){
                        names.push(two2.f_AreaName)
                    }
                    const three = this.lr_areas[areaList[1]] || []
                    const three3 = three.find(t=>t.f_AreaCode == areaList[2])
                    if(three3){
                        names.push(three3.f_AreaName)
                    }

                    return String(names)  
                }
                return ''
            },

            // 自定义表单
            lr_loadCustmerFormScheme(id,isCache = true){
                this.$store.dispatch("custmerForm/scheme/load",{id,isCache})
            },
            
            // 附件上传
            lr_chunkedUpload(option){
                chunkedUpload(option)
            },
            async lr_getFileList(val){// 获取附件列表
                const api = window.$api.system.annexesFile
                const data = (await this.$awaitWraper(api.getList(val))) || []
                return data.map(t=>{return { name:t.f_FileName,url:`${this.apiUrl}system/annexesfile/${t.f_Id}?token=${this.token}`,id:t.f_Id }})
            },
            lr_deleteFile(val){// 文件删除
                const api = window.$api.system.annexesFile
                api.remove(val)
            },
            lr_openFilePreview(){ // 打开预览文件列表

            },

            // 文件下载
            async lr_downFile(url,name,data){
                const loading = this.$loading({
                    lock: true,
                    text: '文件导出中',
                    spinner: 'el-icon-loading',
                    background: 'rgba(0, 0, 0, 0.7)'
                })

                const id = await this.$awaitWraper(window.$axios({
                    url: url,
                    method: 'post',
                    data:data
                }))

                if(id){
                    // 导出成功
                    this.$downFile(`${this.apiUrl}excel/export/file/${name}/${id}?token=${this.token}`)
                }
                else{
                    this.$message({
                        type: 'error',
                        message: '导出失败'
                    })    
                }

                loading.close()
            },

            // 页面权限控制
            async lr_loadPageAuth(){
                if(this.lr_isAuth && this.loginInfo.f_SecurityLevel != 1){
                    this.$store.dispatch('app/setPageAuth',{isAuth:true})
                    const apiAuthorize = window.$api.permission.module
                    this.lr_loadPage = true
                    const url = this.$router.$lrRouter.getValue(this.$route)
                    const module = this.$store.getters.modules.find(t=>t.f_UrlAddress == url)
                    const res = await this.$awaitWraper(apiAuthorize.get(module.f_ModuleId))
                    const forms = res.forms || []
                    const formMap = {}
                    forms.forEach(item=>{
                        const itemList = item.split(',')
                        const propList = itemList[0].split('|')
                        if(propList.length > 1){
                            // 表格
                            formMap[propList[0].toLowerCase()] = formMap[propList[0].toLowerCase()] || {}
                            formMap[propList[0].toLowerCase()][propList[1].toLowerCase()] = itemList[1]
                        }
                        else {
                            // 表单字段
                            formMap[itemList[0].toLowerCase()] = itemList[1]
                        }
                    }) // 对表单权限数据进行处理

                    res.formMap = formMap
                    res.columns = res.columns.map(t=>t.toLowerCase())
                    
                    this.$store.dispatch('app/setPageAuth',{isAuth:true,data:res})
                }
                else{
                    this.$store.dispatch('app/setPageAuth',{isAuth:false})
                }
                this.lr_loadPage = false
            },
            lr_getPageColumns(columns,pageName = ''){
                if(!this.lr_pageAuthInfo.isAuth){
                    return columns
                }
                else if(this.lr_pageAuthInfo.data  && this.lr_pageAuthInfo.data.columns){
                     

                    return columns.filter(t=>{
                        const col = (`${pageName}${t.prop}`).toLowerCase()
                        return this.lr_pageAuthInfo.data.columns.indexOf(col) > -1

                    })
                }
                return []
            },
            lr_hasPageAuth(id,type){
                type = type || 'forms'
                if(!this.lr_pageAuthInfo.isAuth){
                    return true
                }
                else if(this.lr_pageAuthInfo.data  && this.lr_pageAuthInfo.data[type]){
                    if(type == 'forms'){
                        return this.lr_formLookAuth(id)
                    }
                    return this.lr_pageAuthInfo.data[type].indexOf(id) > -1
                }
                return false
            },
            lr_hasPageAuths(list,prop,type){
                return list.filter(t=> this.lr_hasPageAuth(t[prop||'prop'],type))
            },

            lr_formLookAuth(id){
                if(this.isWfForm){
                    if(this.authFieldsMap[id.toLowerCase()] == '3'){
                        return false
                    }
                    return true
                }
                else{
                    if(!this.lr_pageAuthInfo.isAuth){
                        return true
                    }
                    else if(this.lr_pageAuthInfo.data  && this.lr_pageAuthInfo.data.formMap){
                        if(this.lr_pageAuthInfo.data.formMap[id.toLowerCase()]){
                            return true
                        }
                    }
                    return false
                }

                
            },
            lr_formEditAuth(id){
                if(this.isWfForm){
                    if(!this.authFieldsMap[id.toLowerCase()] || this.authFieldsMap[id.toLowerCase()] == '2'){
                        return true
                    }
                    return false
                }
                else{
                    if(!this.lr_pageAuthInfo.isAuth){
                        return true
                    }
                    else if(this.lr_pageAuthInfo.data  && this.lr_pageAuthInfo.data.formMap){
                        if(this.lr_pageAuthInfo.data.formMap[id.toLowerCase()] == '2'){
                            return true
                        }
                    }
                    return false
                }

                
            },
            lr_formTableAuth(id,columns){
                if(this.isWfForm){
                    if(this.authFieldsMap[id.toLowerCase()]){
                        const list = this.authFieldsMap[id.toLowerCase()]
                        columns.forEach(col=>{
                            if(list[col.prop.toLowerCase()] == '3'){
                                col.isHidden = true
                            }
                        })
                    }

                    if(this.requiredMap[id.toLowerCase()]){
                        const requiredMap = this.requiredMap[id.toLowerCase()]
                        columns.forEach(col=>{
                            if(requiredMap[col.prop.toLowerCase()]){
                                col.required = requiredMap[col.prop.toLowerCase()]
                            }
                        })
                    }

                    return columns
                }
                else{
                    if(!this.lr_pageAuthInfo.isAuth){
                        return columns
                    }
                    else if(this.lr_pageAuthInfo.data  && this.lr_pageAuthInfo.data.formMap){
                        const list = this.lr_pageAuthInfo.data.formMap[id.toLowerCase()]
                        columns.forEach(col=>{
                            if(!list[col.prop.toLowerCase()]){
                                col.isHidden = true
                            }
                        })
                    }
                    return columns
                }
                
            },
            lr_formTableEditAuth(pid,id){
                if(this.isWfForm){
                    if(this.authFieldsMap[id.toLowerCase()]){
                        const list = this.authFieldsMap[pid.toLowerCase()]
                        if(!list[id.toLowerCase()] || list[id.toLowerCase()] == '2'){
                            return true
                        }
                        return false
                    }
                    else{
                        return true
                    }
                }
                else{
                    if(!this.lr_pageAuthInfo.isAuth){
                        return true
                    }
                    else if(this.lr_pageAuthInfo.data  && this.lr_pageAuthInfo.data.formMap){
                        const list = this.lr_pageAuthInfo.data.formMap[pid.toLowerCase()]
                        if(list[id.toLowerCase()] == '2'){
                            return true
                        }
                    }
                    return false
                }
                
            },
            
            // 表格按钮点击事件
            lr_handleTableBtnClick(btn){
                let handle = this['handle' + btn.type]
                handle && handle(btn.rowIndex,btn.row)
            },

            lr_handleSettingTable(){
                this.$refs.mainTable.openColumnsSetting()
            }
        }
    }
}

