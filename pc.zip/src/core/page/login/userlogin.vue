<template>
  <el-form class="login-form"
           status-icon
           :rules="loginRules"
           ref="loginForm"
           :model="loginForm"
           label-width="0">
    <el-form-item prop="account">
      <el-input size="small"
                @keyup.enter.native="handleLogin"
                v-model="loginForm.account"
                auto-complete="off"
                :placeholder="$t('请输入账号')"
                :disabled = "disabled"
                ref="account"
                >
        <i slot="prefix"
           class="el-icon-user"></i>
      </el-input>
    </el-form-item>
    <el-form-item prop="password">
      <el-input size="small"
                @keyup.enter.native="handleLogin"
                :type="passwordType"
                v-model="loginForm.password"
                auto-complete="off"
                :placeholder="$t('请输入密码')"
                :disabled = "disabled"
                ref="password"
                >
        <i class="el-icon-view el-input__icon"
           slot="suffix"
           @click="showPassword"></i>
        <i slot="prefix"
           class="el-icon-lock"></i>
      </el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary"
                 @click.native.prevent="handleLogin"
                 :loading="isLoading"
                 class="login-submit">{{submitName}}</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import { mapGetters } from "vuex"
export default {
  name: "userlogin",
  data() {
    return {
      loginForm: {
        account: "",
        password: ""
      },
      loginRules: {
        account: [
          { required: true, message: "请输入用户名", trigger: "blur" }
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 4, message: "密码长度最少为4位", trigger: "blur" }
        ]
      },
      passwordType: "password",
      isLoading:false,
      disabled : false,
      submitName: this.$t('登录')
    }
  },
  created() {
  },
  mounted() {
  },
  computed: {
    ...mapGetters(["tagWel"])
  },
  props: [],
  methods: {
    showPassword() {
      this.passwordType == ""
        ? (this.passwordType = "password")
        : (this.passwordType = "")
    },
    loading(flag){
      if(flag){
          this.submitName = this.$t('登录中...')
          this.isLoading = true
          this.disabled = true
      }
      else{
            this.submitName = this.$t('登录')
            this.isLoading = false
            this.disabled = false
      }
    },
    handleLogin() {
      this.$refs.loginForm.validate((valid,object) => {
        if (valid) {
          this.loading(true)
          this.$store.dispatch("organization/user/login", this.loginForm).then(() => {
            this.$store.commit('app/SET_ISFIRSTLOAD',true)
            this.$router.push({ path: this.tagWel.value })
          }).catch(()=>{
            this.loading(false)
          })
        }
        else{
          const id = object.password ? 'password' :'account'
          this.$refs[id].focus()
        }
      })
    }
  }
}
</script>
