<template>
<div class="login-page" >
  <bgbubbles></bgbubbles>
  <topLang></topLang>
  <div class="login-body" >
    <div class="login-logo">
      <img  class="login-logo__img" :src="`${rootUrl}img/login/learuninfo.png`" />
    </div>
    <!-- <div class="login-sub-title">
      {{$t('开发框架让开发变的如此简单快速')}}
    </div> -->
    <div class="login-form" >
      <userLogin></userLogin>
    </div>
  </div>
  <div class="login-footer" >Copyright 2020  深圳市中孚恒升科技有限公司</div>
</div>
</template>
<script>
import bgbubbles from "./bgbubbles"
import userLogin from "./userlogin"
import topLang from "../index/top/top-lang"

export default {
  name: "login",
  components: {
    userLogin,
    topLang,
    bgbubbles
  },
  data () {
    return {
    };
  },
  created () {
  },
  mounted () { },
  computed: {
  },
  props: [],
  methods: {
  }
};
</script>

<style lang="scss">
@import "../../styles/login.scss";
</style>