<template>
    <div class="top-bar__logo" >
        <div class="top-bar__logobox" >  
            <img class="top-bar__logo_img" :src="logoimg" />
            <!-- <img class="top-bar__logo_img" :src="logoimg" >
            <p v-if="!isCollapse || this.appConfig.theme.nav != 'side'" class="top-bar__logo--title-text" >{{appConfig.title}}</p> -->
        </div>
    </div>
</template>
<script>
import { mapGetters } from "vuex"
export default {
  name: "top-logo",
  data () {
    return {};
  },
  created () {
  },
  mounted () { },
  computed: {...mapGetters(["isCollapse"]),
    logoimg(){
        return `${this.rootUrl}img/admin/logo1.png`
    }
  },
  props: [],
  methods: {
  }
};
</script>

<style lang="scss" scoped>
.top-bar__logo--title-text {
    height: 32px;
    line-height: 32px;
    vertical-align: middle;
    margin: 0 0 0 12px;
    color: #fff;
    font-weight: 600;
    font-size: 18px;
}
</style>
