<template>
  <div class="lr-sidebar">
    <top-logo v-if="appConfig.theme.nav == 'side'" ref="topLogo"></top-logo>
    <div class="lr-sidebar-menu" >
      <el-menu unique-opened
               :default-active="nowTagValue"
               mode="vertical"
               :collapse-transition="true"
               :collapse="isCollapse">
        <sidebar-item :menu="myMenu"
                      first
                      :collapse="isCollapse"></sidebar-item>
      </el-menu>
    </div>
    <div class="lr-sidebar--collapse" @click="setCollapse" >
      <i :class="isCollapse?'el-icon-s-unfold':'el-icon-s-fold'" ></i>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex"
import sidebarItem from "./sidebarItem"
import topLogo from "../top/top-logo"

export default {
  name: "sidebar",
  components: { sidebarItem,topLogo},
  data () {
    return {}
  },
  created () {

  },
  computed: {
    ...mapGetters(["modules","menu", "tag", "isCollapse"]),
    myMenu(){
      const res = this.menu.filter(item =>{
        if(item.f_EnabledMark == 1 && item.f_IsMenu == 1){
          if(this.loginInfo.f_SecurityLevel == 1){
            return true
          }
          else{
            const moduleAuthIds = this.loginInfo.moduleAuthIds || []
            if(moduleAuthIds.indexOf(item.f_ModuleId) > -1){
              return true
            }
            else{
              return false
            }
          }
        }
      })
      return res
    },
    nowTagValue: function () {
      //console.log(this.$router.$lrRouter.getValue(this.$route))
      const url = this.$router.$lrRouter.getValue(this.$route)
      const module = this.modules.find(t=>t.f_UrlAddress == url)
      console.log(module)
      if(module){
        return module.f_ModuleId
      }
      else{
        return ''
      }
      
    }
  },
  mounted () { },
  methods: {
    setCollapse () {
      this.$store.commit("app/SET_COLLAPSE")
    },
  }
}
</script>


