const components = []
const requireComponent = require.context('./', true, /index\.vue$/)
requireComponent.keys().map(fileName => {
  if(fileName.split('/')[1] != 'iframe' && fileName.split('/')[1] != 'error-page'){
    components.push({
      name: `l-${fileName.split('/')[1]}`,
      component: requireComponent(fileName).default
    })
  }
  
})
const installs = {
}

const install = function (Vue) {
    if (install.installed) {
      return
    }
    Object.values(components).map(component => {
      Vue.component(component.name,component.component)
    })

    Object.values(installs).map(component => {
      Vue.use(component)
    })
}

export default {
    install,
    ...components
}

export {
  components
}