<template>
    <div>
        <el-button-group>
            <el-button v-if="hasRefresh" size="mini" icon="el-icon-refresh-left" @click="handleRefresh" ></el-button>
            <el-button v-if="hasTableSetting" size="mini" icon="el-icon-setting" @click="handleTableSetting" ></el-button>
        </el-button-group>
        <slot></slot>
        <el-button-group v-if="isAdd" >
            <el-button type="primary" size="mini" :icon="btnIcon"
                @click="handleClick()"
            >{{$t(btnText)}}</el-button>
        </el-button-group>
    </div>
</template>

<script>
export default {
    name:'l-tool-btns',
    inject: ["admin"],
    props: {
        id:{
            type:String,
            default:'Index'
        },
        btnText:{
            type:String,
            default:'新增'
        },
        btnId:{
            type:String,
            default:'Add'
        },
        btnIcon:{
            type:String,
            default:'el-icon-plus'
        },
        hasAdd:{
            type:Boolean,
            default:true
        },
        hasTableSetting:{
            type:Boolean,
            default:false
        },
        hasRefresh:{
            type:Boolean,
            default:true
        },
        refreshClick:Function
    },
    data () {
        return {
        }
    },
    computed:{
        isAdd(){
            return this.hasAdd && (!this.lr_pageAuthInfo.isAuth || (this.lr_pageAuthInfo.data  && this.lr_pageAuthInfo.data.buttons && this.lr_pageAuthInfo.data.buttons.indexOf(this.btnId) != -1))
        }
    },
    methods:{
        handleRefresh(){
            if(this.refreshClick){
                this.refreshClick()
            }
            else{
                this.admin.reload()
            }
        },
        handleClick(){
            this.$emit('click')
        },
        // 对主表格的设置
        handleTableSetting(){
            this.$emit('setting')
        },
    }
}
</script>