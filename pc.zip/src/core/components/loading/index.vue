<template>
    <div class="l-spin l-spin-spinning">
        <span class="l-spin-dot">
            <i class="l-spin-dot-item"></i>
            <i class="l-spin-dot-item"></i>
            <i class="l-spin-dot-item"></i>
            <i class="l-spin-dot-item"></i>
        </span>
    </div>
</template>

<script>
export default {
    name:'l-loading',
    data () {
        return {
        }
    },
    computed:{
    },
    methods:{
    }
}
</script>