// 基础路径 注意发布之前要先修改这里
const BASE_URL = process.env.NODE_ENV === 'production'
  ? process.env.VUE_APP_ROOT_URL
  : '/'

const cdn = process.env.NODE_ENV === 'production' ?{  
  // 通过cdn方式使用123456
  js: [
    '//lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/vue/2.6.14/vue.min.js',
    '//lf9-cdn-tos.bytecdntp.com/cdn/expire-3-M/vuex/3.6.2/vuex.min.js',
    '//lf26-cdn-tos.bytecdntp.com/cdn/expire-3-M/vue-router/3.5.1/vue-router.min.js',
    '//lf3-cdn-tos.bytecdntp.com/cdn/expire-3-M/axios/0.21.1/axios.min.js',
    '//lf26-cdn-tos.bytecdntp.com/cdn/expire-3-M/Sortable/1.13.0/Sortable.min.js',

    '//cdn.staticfile.org/element-ui/2.15.5/index.min.js',
    '//cdn.staticfile.org/echarts/5.1.2/echarts.min.js',
    '//cdn.staticfile.org/html2canvas/1.3.2/html2canvas.min.js',
  ],
  css: [
    //'//cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.min.css',
    '//cdn.staticfile.org/element-ui/2.15.5/theme-chalk/index.min.css'
  ]
}:{
  js:[
    '/cdn/vue/2.6.14/vue.js',
    '/cdn/vuex/3.6.2/vuex.min.js',
    '/cdn/vue-router/3.5.1/vue-router.min.js',
    '/cdn/axios/0.21.1/axios.min.js',
    '/cdn/element-ui/2.15.5/index.js',
    '/cdn/sortable/sortable.js',
    '/cdn/echarts/echarts.min.js',
    '/cdn/html2canvas/html2canvas.min.js'
  ],
  css:[
    //'/font/css/font-awesome.min.css',
    '/cdn/element-ui/2.15.5/theme-chalk/index.css'
  ]
}


// const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
module.exports = {
  publicPath: BASE_URL, // 根据你的实际情况更改这里
  lintOnSave: process.env.NODE_ENV === 'development',
  productionSourceMap: false,
  
  configureWebpack:config =>{
    if (process.env.NODE_ENV !== 'development') {
      return {
          performance: {
          hints: false,
          maxEntrypointSize: 512000,
          maxAssetSize: 512000
        }
      }
    }
  },
  // configureWebpack: config => {
  //     if (process.env.NODE_ENV === 'production') {
  //         return {
  //             plugins: [
  //                 new BundleAnalyzerPlugin()
  //             ]
  //         }
  //     }
  // },
  chainWebpack: (config) => {
    config.plugins.delete('preload') 
    config.plugins.delete('prefetch') 
    // 配置cdn引入
    config.plugin('html').tap((args) => {
      args[0].cdn = cdn;
      return args
    }) 

    //忽略的打包文件
    config.externals({
      'vue': 'Vue',
      'vue-router': 'VueRouter',
      'vuex': 'Vuex',
      'axios': 'axios',
      'element-ui': 'ELEMENT',
    })
    const entry = config.entry('app')
    entry
      .add('babel-polyfill')
      .end()
    entry
      .add('classlist-polyfill')
      .end()
    /*entry
      .add('@/mock')
      .end()*/
  }
}